#!/usr/bin/env node
/* ================================================================
 * marp-deck.mjs  —  共通テーマ用 デッキ雛形生成 / エクスポート（エンジン）
 *
 * クロスプラットフォーム（Mac/Windows/Linux）。Node だけで動く。
 * CLI からも、ローカルWeb GUI（studio/server.mjs）からも共用する関数を export する。
 *
 * CLI:
 *   node marp-deck.mjs new <作成先フォルダ> "タイトル" ["サブタイトル"]
 *   node marp-deck.mjs export <デッキ.md>
 *
 * 設計方針（場所に依存させない）:
 *   - テーマは `theme: <ブランド既定>`（既定 base／.marp-studio.json の brand で上書き。CLI/GUIは --theme-set を自動付与）
 *   - ロゴはテーマに data URI 埋め込み済み（参照不要）
 *   - デッキは「自己完結フォルダ」: 図やカバー画像は各デッキの assets/ に置く
 *   - 作成物は out/ の PDF（画像埋め込み・自己完結）
 *   - export 時に assets/*.mmd を自動でSVG化（手動 mmdc 不要）
 * ================================================================ */
import { mkdirSync, writeFileSync, copyFileSync, existsSync, readdirSync, readFileSync, rmSync, statSync } from 'node:fs';
import { resolve, dirname, join, basename, sep } from 'node:path';
import { tmpdir } from 'node:os';
import { pathToFileURL } from 'node:url';
import { execSync, exec } from 'node:child_process';
import { createHash } from 'node:crypto';
import { deflateRawSync } from 'node:zlib';

/** ブランド既定（顧客非依存・中立）。
 *  顧客名・自社名は含めない（製品=社内アセットにこのエンジンがそのまま入るため）。
 *  各リポは .marp-studio.json の "brand" で上書きする
 *  （例: defaultTheme:"acme", projectLabel:"... プロジェクト", footer:"© 2026 自社名"）。 */
const NEUTRAL_BRAND = {
  defaultTheme: 'base',                 // 新規デッキの frontmatter theme:
  projectLabel: '',                     // 表紙の ### 行（プロジェクト/顧客名）。空なら出さない
  customer: '',                         // 顧客ラベル（例 Acme）。Marp Studio のホーム副題に表示。空なら出さない
  footer: '© 2026',                     // 右下フッター（中立。自社名は .marp-studio.json で付与）
};

/** デッキ位置から親をたどって .marp-studio.json を探し brand を返す（無ければ中立）。 */
export function loadBrand(startDir) {
  let d = resolve(startDir);
  for (;;) {
    const p = join(d, '.marp-studio.json');
    if (existsSync(p)) {
      try { const c = JSON.parse(readFileSync(p, 'utf8')); return { ...NEUTRAL_BRAND, ...(c.brand || {}) }; }
      catch { /* 壊れた設定は無視して中立にフォールバック */ }
    }
    const parent = dirname(d);
    if (parent === d) return { ...NEUTRAL_BRAND };
    d = parent;
  }
}

/** デッキ位置から親をたどって 00_common/assets/marp を探す（場所非依存の肝） */
export function findThemeDir(startDir) {
  let d = resolve(startDir);
  for (;;) {
    if (existsSync(join(d, '00_common/assets/marp'))) {   // テーマCSSのファイル名に依存しない
      return join(d, '00_common/assets/marp');
    }
    const parent = dirname(d);
    if (parent === d) return null;
    d = parent;
  }
}

/** Mermaid: assets/*.mmd を .svg に再生成（無ければ何もしない）。
 *  marp の ![]() 用に width/height を明示（width="100%" だと高さが潰れるため）。
 *  キャッシュ: .svg が .mmd より新しければ mmdc（ヘッドレスChrome）を起動しない＝再描画スキップ。 */
export function renderMermaid(assetsDir, log = console.log, errors = [], fast = false) {
  if (fast) return;   // 速いプレビュー: assets/*.mmd の再SVG化（重い mmdc）はしない＝既存svgのまま
  if (!existsSync(assetsDir)) return;
  const mmds = readdirSync(assetsDir).filter((f) => f.toLowerCase().endsWith('.mmd'));
  if (mmds.length === 0) return;
  // 変更があった .mmd だけを対象にする（未変更なら mmdc を呼ばない）。
  const stale = mmds.filter((f) => {
    const outPath = join(assetsDir, f.replace(/\.mmd$/i, '.svg'));
    try { return !existsSync(outPath) || statSync(outPath).mtimeMs < statSync(join(assetsDir, f)).mtimeMs; }
    catch { return true; }
  });
  if (stale.length === 0) return;   // 全てキャッシュ済み
  log(`Mermaid: ${stale.length}/${mmds.length} 件を SVG 化します（初回は mmdc 取得で時間がかかります）…`);
  for (const f of stale) {
    const inPath = join(assetsDir, f);
    const outPath = join(assetsDir, f.replace(/\.mmd$/i, '.svg'));
    try {
      execSync(`${mmdcCmd()} -i "${inPath}" -o "${outPath}" -b transparent`, { stdio: 'pipe', env: mmdcEnv(), maxBuffer: MMDC_MAX_BUFFER });
      fixSvgSize(outPath);
      log(`  ${f} → ${basename(outPath)}`);
    } catch (e) {
      const detail = (e.stderr && e.stderr.toString().trim()) || (e.stdout && e.stdout.toString().trim()) || e.message;
      errors.push({ file: f, detail });
      log(`  [警告] mmdc 実行に失敗: ${f} — ${detail}`);
    }
  }
}

/** width="100%"（高さ潰れの原因）を viewBox 由来の固定 px に直す。max-width:...px も除去。
 *  viewBox は「外側の<svg>タグ」限定で探すこと（文書全体を探すと矢印マーカーの
 *  viewBox="0 0 10 10"のような小さい定義に先にマッチし、幅高さが10x10に化ける）。
 *  外側のviewBoxは "0 0 ..." に限らず負のオフセット（例: "-3.25 0 480 398"）も取り得るため
 *  x/y は問わず末尾2つ（幅・高さ）だけを取り出す。 */
function fixSvgSizeStr(s) {
  const openTagEnd = s.indexOf('>');
  const openTag = openTagEnd === -1 ? s : s.slice(0, openTagEnd + 1);
  const vb = openTag.match(/viewBox="[-\d.]+ [-\d.]+ ([\d.]+) ([\d.]+)"/);
  if (vb && /width="100%"/.test(openTag)) {
    const fixedOpenTag = openTag.replace(/width="100%"/, `width="${Math.round(parseFloat(vb[1]))}" height="${Math.round(parseFloat(vb[2]))}"`);
    s = fixedOpenTag + s.slice(openTag.length);
  }
  return s.replace(/max-width:\s*[\d.]+px;?/g, '');
}
function fixSvgSize(svgPath) {
  if (!existsSync(svgPath)) return;
  writeFileSync(svgPath, fixSvgSizeStr(readFileSync(svgPath, 'utf8')));
}

/** Mermaid のコード文字列を mmdc で PNG ファイルに変換（PPTX埋め込み用＝多くのビューアで確実に描画される）。
 *  SVG は PowerPoint/Keynote で描画されず空箱になりがちなので、PPTX ではラスタPNGを使う。 */
export function mermaidCodeToPng(code, outPath) {
  const base = join(tmpdir(), `marp-mmpng-${process.pid}-${_mmFenceSeq++}`);
  const inPath = base + '.mmd';
  writeFileSync(inPath, code);
  try {
    execSync(`${mmdcCmd()} -i "${inPath}" -o "${outPath}" -b white -s 2`, { stdio: 'pipe', env: mmdcEnv(), maxBuffer: MMDC_MAX_BUFFER });
  } catch (e) {
    const detail = (e.stderr && e.stderr.toString().trim()) || (e.stdout && e.stdout.toString().trim()) || e.message;
    const err = new Error(detail); err.detail = detail; throw err;
  } finally {
    try { rmSync(inPath, { force: true }); } catch {}
  }
  return outPath;
}

/** Mermaid のコード文字列を「htmlLabels無効」のSVGファイルに変換（PPTX埋め込み用）。
 *  htmlLabels:false にするとラベルが <foreignObject>(HTML) ではなく <text> になり、
 *  PowerPoint がSVGの文字を拾える＝表示OK＋グループ解除で「矢印＋テキスト入りBox」に分解できる。 */
export function mermaidCodeToSvgFile(code, outPath) {
  const base = join(tmpdir(), `marp-mmsvg-${process.pid}-${_mmFenceSeq++}`);
  const inPath = base + '.mmd', cfgPath = base + '.mmconf.json';
  writeFileSync(inPath, code);
  writeFileSync(cfgPath, JSON.stringify({ htmlLabels: false, flowchart: { htmlLabels: false } }));
  try {
    execSync(`${mmdcCmd()} -i "${inPath}" -o "${outPath}" -c "${cfgPath}" -b transparent`, { stdio: 'pipe', env: mmdcEnv(), maxBuffer: MMDC_MAX_BUFFER });
    writeFileSync(outPath, fixSvgSizeStr(readFileSync(outPath, 'utf8')));   // width/height を明示（埋め込み時に潰れない）
  } catch (e) {
    const detail = (e.stderr && e.stderr.toString().trim()) || (e.stdout && e.stdout.toString().trim()) || e.message;
    const err = new Error(detail); err.detail = detail; throw err;
  } finally {
    try { rmSync(inPath, { force: true }); } catch {}
    try { rmSync(cfgPath, { force: true }); } catch {}
  }
  return outPath;
}

/** mmdc/Puppeteerはごく稀に width="10" height="10" のような潰れたSVGをエラー無しで返す
 *  （Chromiumのレイアウト計測が競合する既知の不安定さ）。気づかず配布すると図が消える。 */
function isDegenerateSvg(svg) {
  const m = svg.match(/<svg[^>]*\bwidth="(\d+(?:\.\d+)?)"[^>]*\bheight="(\d+(?:\.\d+)?)"/);
  return !!m && parseFloat(m[1]) <= 10 && parseFloat(m[2]) <= 10;
}

/** 常駐中の（ユーザーが実際に使っている）システムChromeを毎回のヘッドレス起動先に使うと、
 *  シングルインスタンス動作で既存ウインドウに描画が引き寄せられ、稀に計測前のレイアウトを
 *  そのままSVGサイズに固定してしまう（潰れたSVGの主因）。まずmmdc/Puppeteer既定のブラウザで
 *  試し、失敗した時だけシステムChromeへフォールバックする（社内プロキシでDL不可な環境向け）。 */
function mmdcEnvDefault() {
  const env = { ...process.env };
  delete env.PUPPETEER_EXECUTABLE_PATH;
  return env;
}

/** システム高負荷（CPU/メモリ競合）下ではヘッドレスChromeのレイアウト計測が完了前に
 *  打ち切られ、10x10の潰れたSVGを返すことがある。指数バックオフで間を空けて再試行する。 */
function sleepSync(ms) {
  try { execSync(`sleep ${(ms / 1000).toFixed(1)}`, { stdio: 'ignore' }); } catch {}
}
const MMDC_MAX_ATTEMPTS = 8;

/** Mermaid のコード文字列を mmdc で SVG 文字列に変換（一時ファイル経由・後始末する）。
 *  潰れたSVGが返ったら（isDegenerateSvg）ブラウザの選び方を切り替えつつ数回まで再試行する。 */
let _mmFenceSeq = 0;
export function mermaidCodeToSvg(code, attempt = 1) {
  const base = join(tmpdir(), `marp-mmfence-${process.pid}-${_mmFenceSeq++}`);
  const inPath = base + '.mmd', outPath = base + '.svg';
  writeFileSync(inPath, code);
  const env = attempt % 2 === 1 ? mmdcEnvDefault() : mmdcEnv();
  try {
    execSync(`${mmdcCmd()} -i "${inPath}" -o "${outPath}" -b transparent`, { stdio: 'pipe', env, maxBuffer: MMDC_MAX_BUFFER });
    const svg = fixSvgSizeStr(readFileSync(outPath, 'utf8'));
    if (isDegenerateSvg(svg) && attempt < MMDC_MAX_ATTEMPTS) { sleepSync(1000 * attempt); return mermaidCodeToSvg(code, attempt + 1); }
    if (isDegenerateSvg(svg)) throw Object.assign(new Error(`mmdc が潰れたSVG(10x10)を返し続けた（${MMDC_MAX_ATTEMPTS}回試行）`), { detail: `mmdc が潰れたSVG(10x10)を返し続けた（${MMDC_MAX_ATTEMPTS}回試行）` });
    return svg;
  } catch (e) {
    if (e.detail) throw e;
    if (attempt < MMDC_MAX_ATTEMPTS) { sleepSync(1000 * attempt); return mermaidCodeToSvg(code, attempt + 1); }
    // execSync の失敗は stderr に mmdc/puppeteer/Chromium の実エラーが入る（「図が出ない」原因の本体）。
    // e.message（コマンド＋終了コード）だけだと原因が分からないので stderr/stdout を detail に載せて投げ直す。
    const detail = (e.stderr && e.stderr.toString().trim()) || (e.stdout && e.stdout.toString().trim()) || e.message;
    const err = new Error(detail); err.detail = detail; throw err;
  } finally {
    try { rmSync(inPath, { force: true }); } catch {}
    try { rmSync(outPath, { force: true }); } catch {}
  }
}

/** md 内の ```mermaid フェンスを抽出し、各々を SVG 化→assets/.fences/fence-N.svg へ書き出し、
 *  そのファイルを相対参照する ![opts](assets/.fences/fence-N.svg) に置換した「一時md」を
 *  deckDir 直下に生成して返す（元 md は不変）。フェンスが無ければ null。
 *  フェンスの info string（例: ```mermaid h:440）は marp 画像オプションとして引き継ぐ。
 *  ＝ソースは md の ```mermaid 1か所（genAI直読）、描画はビルド時のみ画像化（PDF安定）。 */
export function inlineMermaidFences(mdPath, log = console.log, errors = [], fast = false, deferred = []) {
  const src = readFileSync(mdPath, 'utf8');
  const re = /^([ \t]*)```mermaid[ \t]*([^\n]*)\n([\s\S]*?)\n[ \t]*```[ \t]*$/gm;
  const deckDir = dirname(mdPath);
  const fdir = join(deckDir, 'assets', '.fences');   // フェンス由来svgの置き場（生成物・gitignore）
  // フェンスはコード内容のハッシュでキャッシュ＝未変更フェンスは mmdc（Chrome）を呼ばず既存svgを再利用。
  let total = 0, built = 0; const used = new Set();
  const out = src.replace(re, (m, indent, opts, code) => {
    total++;
    const hash = createHash('sha1').update(code).digest('hex').slice(0, 16);
    const fname = `fence-${hash}.svg`;
    const fpath = join(fdir, fname);
    const ref = `${indent}![${(opts || '').trim()}](assets/.fences/${fname})`;
    if (existsSync(fpath)) { used.add(fname); return ref; }   // キャッシュヒット＝そのまま描画
    // 速いプレビュー(fast): 未キャッシュの重い図は描かず、元のフェンス(コード)のまま残す＝保存時に描画。
    if (fast) { deferred.push({}); return m; }
    try {                                             // 通常(保存/PDF): キャッシュミスを mmdc で描画
      mkdirSync(fdir, { recursive: true });
      writeFileSync(fpath, mermaidCodeToSvg(code));
      built++; used.add(fname);
      // marp(markdown-it) は data:image/svg+xml を弾く（validateLink）。相対svgファイル参照で描画する。
      return ref;
    } catch (e) {
      const detail = e.detail || e.message;
      errors.push({ detail });
      log(`  [警告] mermaid フェンスの描画に失敗（コードブロックのまま）: ${detail}`);
      return m;
    }
  });
  if (total === 0) return null;
  // 使われなくなった古いフェンスsvgを掃除（キャッシュの肥大化防止）。fastでは消さない＝キャッシュ温存（保存時の再描画を減らす）。
  if (!fast) { try { for (const f of readdirSync(fdir)) { if (f.endsWith('.svg') && !used.has(f)) rmSync(join(fdir, f), { force: true }); } } catch {} }
  log(`Mermaid: フェンス ${total} 件（再描画 ${built} / キャッシュ ${total - built}${deferred.length ? ' / 保存時に描画 ' + deferred.length : ''}）`);
  const tmp = join(deckDir, `.${basename(mdPath, '.md')}.mmfence.tmp.md`);
  writeFileSync(tmp, out);
  return tmp;
}

/** 新規デッキ（自己完結フォルダ）を作成。{ mdPath, deckDir } を返す。 */
export function createDeck({ targetDir, title, subtitle, brand }) {
  const deckDir = resolve(targetDir);
  const b = { ...NEUTRAL_BRAND, ...(brand || loadBrand(deckDir)) };
  const themeDir = findThemeDir(deckDir) || findThemeDir(process.cwd());
  if (!themeDir) throw new Error('00_common/assets/marp が見つかりません（リポジトリ配下で実行してください）');

  const name = basename(deckDir);
  const mdPath = join(deckDir, `${name}.md`);
  if (existsSync(mdPath)) throw new Error(`既に存在します: ${mdPath}`);

  mkdirSync(join(deckDir, 'assets'), { recursive: true });
  mkdirSync(join(deckDir, 'out'), { recursive: true });

  // 表紙背景はテーマが提供（--title-bg）。MDで ![bg] は指定しない（指定するとテーマ表紙を上書きするため）。
  // 個別にカバー画像を貼りたい場合のみ assets/ に置いて ![bg](assets/xxx) を手書きする。
  const coverLine = '<!-- 表紙背景はテーマが提供（--title-bg）。個別指定したいときだけ ![bg](assets/xxx) を書く -->';

  // 結びページ: 中立な表紙レイアウトのクローズ（顧客非依存）。
  const closing = '<!-- _class: closing -->\n<!-- _paginate: false -->';

  const sub = subtitle || 'サブタイトル';
  const projectLine = b.projectLabel ? `### ${b.projectLabel}\n` : '';
  const md = `---
marp: true
theme: ${b.defaultTheme}
paginate: true
footer: '${b.footer}'
---

<!-- _class: cover -->
<!-- _paginate: false -->
<!-- doc-id: TODO -->
<!-- ↑ 正本マップ decks/_common/doc-map.mmd のノードID に置き換える -->

${coverLine}

# ${title}
## ${sub}
${projectLine}
---

<!-- _class: section -->

# 本書について

---

# 本書の位置づけ

<div class="lead-area">本書はプロジェクト管理ドキュメント群の一冊。全体の中での位置は下表のとおり。</div>

<!-- 〔プロジェクト管理ガイド系の場合〕doc-id を宣言し  node 00_common/tools/marp/marp-deck.mjs catalog <この.md>  を実行すると下表が生成される。 -->
<!-- ※プロジェクト管理ガイド系でなければ、この「本書の位置づけ」スライドと表紙の doc-id 行は削除してよい -->
<!-- catalog:start -->
<!-- catalog:end -->


---

# 本書の役割（目的・ゴール）

<div class="lead-area">本書が<strong>定義すること</strong>と、読み終えて<strong>分かること</strong>。</div>

<div class="columns">
<div>

**本書が定義する**
- （この文書が定める内容）

</div>
<div>

**読み終えると（ゴール）**
- （読者が理解・実行できること）

</div>
</div>

> **スコープ外**：（この文書が扱わない範囲）

---

# 目次

| 章 | テーマ | 状態（完成後削除） |
|---|---|:---:|
| 1. （章名） | （テーマ） | 骨組み |
| 2. （章名） | （テーマ） | 骨組み |

---

# 用語・凡例

<div class="lead-area">本書で頻出する用語と凡例。先に押さえてから読み進める。</div>

| 用語 | 意味 |
|---|---|
| （用語） | （説明） |

> **凡例**：（色・記号の意味）

---

<!-- _class: section -->

# 1. （セクション名）
## （サブタイトル）

---

# 1-1. （タイトルとコンテンツ）

- ここから本文。
- **図は md に \`\`\`mermaid フェンスで直接書く**（ビルド時に画像化＝PDF安定・genAIは構造を直読）。下が例。
- 位置やサイズ微調整が要る図は \`![](assets/xxx.svg)\` 参照も可。レイアウトは 00_common/assets/marp/README.md 参照。

\`\`\`mermaid
flowchart LR
  A[開始] --> B[処理] --> C[完了]
\`\`\`

---

${closing}
`;
  writeFileSync(mdPath, md);
  return { mdPath, deckDir };
}

/** marp CLI を解決：グローバル `marp` があればそれを、無ければ `npx -y @marp-team/marp-cli`。
 *  （Mac=グローバル導入で高速 / Windows等=未導入でも npx 取得で動く。mermaid と同じ方針） */
let _marpCmd = null;
function marpBin() {
  if (_marpCmd) return _marpCmd;
  try { execSync('marp --version', { stdio: 'pipe' }); _marpCmd = 'marp'; }
  catch { _marpCmd = 'npx -y @marp-team/marp-cli'; }
  return _marpCmd;
}
/** mmdc（mermaid-cli）を解決：グローバル `mmdc` があればそれを、無ければ `npx -y @mermaid-js/mermaid-cli`。
 *  1回だけ解決して使い回す（npx の都度パッケージ解決コストを避ける）。 */
let _mmdcCmd = null;
function mmdcCmd() {
  if (_mmdcCmd) return _mmdcCmd;
  try { execSync('mmdc --version', { stdio: 'pipe' }); _mmdcCmd = 'mmdc'; }
  catch { _mmdcCmd = 'npx -y @mermaid-js/mermaid-cli'; }
  return _mmdcCmd;
}
/** システムに入っている Chrome/Edge/Chromium/Brave を探す（見つからなければ null）。1回だけ解決。 */
let _sysChrome;
export function findSystemChrome() {
  if (_sysChrome !== undefined) return _sysChrome;
  const cands = process.platform === 'darwin' ? [
    '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',
    '/Applications/Chromium.app/Contents/MacOS/Chromium',
    '/Applications/Brave Browser.app/Contents/MacOS/Brave Browser',
  ] : process.platform === 'win32' ? [
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    process.env.LOCALAPPDATA ? join(process.env.LOCALAPPDATA, 'Google\\Chrome\\Application\\chrome.exe') : '',
  ] : [
    '/usr/bin/google-chrome', '/usr/bin/google-chrome-stable',
    '/usr/bin/chromium-browser', '/usr/bin/chromium', '/usr/bin/microsoft-edge',
  ];
  _sysChrome = cands.find((p) => p && existsSync(p)) || null;
  return _sysChrome;
}
/** mmdc(=Puppeteer) 用の環境変数。PUPPETEER_EXECUTABLE_PATH 未設定なら、見つけたシステムChrome/Edgeを使わせる。
 *  npx経由のmmdcは Chromium 未取得（社内プロキシでDL不可など）だと起動に失敗しがち。既存ブラウザで回避する＝「一人だけ図が出ない」対策。 */
function mmdcEnv() {
  const env = { ...process.env };
  if (!env.PUPPETEER_EXECUTABLE_PATH) { const c = findSystemChrome(); if (c) env.PUPPETEER_EXECUTABLE_PATH = c; }
  return env;
}
// execSyncの既定maxBuffer(1MB)だとmmdc/Puppeteerの出力で溢れ、SVGが幅高さ10pxの壊れた状態のまま
// 静かに完了することがある（エラーにならず気づきにくい）。図の取りこぼしを防ぐため大きめに確保する。
const MMDC_MAX_BUFFER = 1024 * 1024 * 32;

/** デッキを PDF/HTML 出力。{ out } を返す。fmt: 'pdf' | 'html'。
 *  outPath を渡すとその場所に出力（プレビューHTMLはデッキ直下に置くと assets/ 相対が解決できる）。 */
export function exportDeck(mdPath, { fmt = 'pdf', outPath = null, log = console.log, fast = false } = {}) {
  mdPath = resolve(mdPath);
  if (!existsSync(mdPath)) throw new Error(`not found: ${mdPath}`);
  const deckDir = dirname(mdPath);
  const themeDir = findThemeDir(deckDir);
  if (!themeDir) throw new Error('00_common/assets/marp が見つかりません');

  // Mermaid描画の失敗を集約（呼び出し側＝Studioが「N件の図が描けません: 〇〇」を画面表示できるように）。
  // fast=true（自動プレビュー）では未キャッシュの図を描かず deferred に積む＝「保存で反映」をUIに出せる。
  const mermaidErrors = [], mermaidDeferred = [];

  // 5-2 を内包: assets/*.mmd を SVG 化してから marp（手動 mmdc 不要・PDFが壊れない）
  renderMermaid(join(deckDir, 'assets'), log, mermaidErrors, fast);

  // ```mermaid フェンスがあれば SVG ファイル(assets/.fences/) 参照に差し替えた一時 md を使う（元 md は不変）
  const tmpMd = inlineMermaidFences(mdPath, log, mermaidErrors, fast, mermaidDeferred);
  const inputMd = tmpMd || mdPath;

  // marp/ 内の全テーマCSS（/* @theme x */ 付き）を登録 → デッキの frontmatter theme: で選択
  const themeCss = readdirSync(themeDir).filter((f) => f.toLowerCase().endsWith('.css')).map((f) => join(themeDir, f));
  const ext = fmt === 'html' ? 'html' : 'pdf';
  let out = outPath;
  if (!out) {
    mkdirSync(join(deckDir, 'out'), { recursive: true });
    out = join(deckDir, 'out', basename(mdPath).replace(/\.md$/, `.${ext}`));
  }

  const q = (s) => `"${s}"`;
  const flag = fmt === 'html' ? '--html' : '--html --pdf';
  const themeArgs = themeCss.map((t) => `--theme-set ${q(t)}`).join(' ');
  const cmd = `${marpBin()} ${q(inputMd)} ${themeArgs} ${flag} --allow-local-files -o ${q(out)}`;
  log(cmd);
  try {
    execSync(cmd, { stdio: 'pipe' });
  } finally {
    if (tmpMd) { try { rmSync(tmpMd, { force: true }); } catch {} }
  }
  return { out, mermaidErrors, mermaidDeferred };
}

/** デッキを 1ページ=1PNG に書き出す（PPTX変換の画像フォールバック用）。
 *  exportDeck と同じ mermaid 前処理・テーマ登録を通し、生成PNGの絶対パス配列を昇順で返す。 */
export function exportImages(mdPath, { outDir = null, log = console.log } = {}) {
  mdPath = resolve(mdPath);
  if (!existsSync(mdPath)) throw new Error(`not found: ${mdPath}`);
  const deckDir = dirname(mdPath);
  const themeDir = findThemeDir(deckDir);
  if (!themeDir) throw new Error('00_common/assets/marp が見つかりません');
  const mermaidErrors = [];
  renderMermaid(join(deckDir, 'assets'), log, mermaidErrors, false);
  const tmpMd = inlineMermaidFences(mdPath, log, mermaidErrors, false, []);
  const inputMd = tmpMd || mdPath;
  const themeCss = readdirSync(themeDir).filter((f) => f.toLowerCase().endsWith('.css')).map((f) => join(themeDir, f));
  outDir = outDir || join(deckDir, 'out', '.pptx-img');
  mkdirSync(outDir, { recursive: true });
  for (const f of readdirSync(outDir)) { if (/^slide\.\d+\.png$/i.test(f)) { try { rmSync(join(outDir, f)); } catch {} } }
  const q = (s) => `"${s}"`;
  const themeArgs = themeCss.map((t) => `--theme-set ${q(t)}`).join(' ');
  const outBase = join(outDir, 'slide.png');
  const cmd = `${marpBin()} ${q(inputMd)} ${themeArgs} --images png --allow-local-files -o ${q(outBase)}`;
  log(cmd);
  try { execSync(cmd, { stdio: 'pipe' }); }
  finally { if (tmpMd) { try { rmSync(tmpMd, { force: true }); } catch {} } }
  const images = readdirSync(outDir).filter((f) => /^slide\.\d+\.png$/i.test(f))
    .sort((a, b) => a.localeCompare(b, undefined, { numeric: true })).map((f) => join(outDir, f));
  return { images, mermaidErrors };
}

/** dir 配下のファイルを再帰的に列挙し、dir 起点の相対パス（常に / 区切り）を返す。
 *  zip エントリ名は仕様上 / 区切りが必須（Windowsの \ 対策）。 */
function listFilesRecursive(dir) {
  const out = [];
  const walk = (d) => {
    for (const f of readdirSync(d)) {
      const p = join(d, f);
      if (statSync(p).isDirectory()) walk(p);
      else out.push(p.slice(dir.length + 1).split(sep).join('/'));
    }
  };
  walk(dir);
  return out;
}

/** ZIP書き出し（UTF-8フラグ付き / deflate、依存ライブラリ無し）。
 *  make-dist.mjs の emitZip() と同じ手書きZIP実装（配布ビルドで実績あり）。 */
function writeZipFile(entries, outPath) {
  const CRCT = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
  const crc32 = (b) => { let c = 0xFFFFFFFF; for (let i = 0; i < b.length; i++) c = CRCT[(c ^ b[i]) & 0xff] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; };
  const FLAG = 0x0800, METHOD = 8, DOSDATE = 0x0021, DOSTIME = 0;
  const parts = [], central = []; let offset = 0;
  for (const e of entries) {
    const nameBuf = Buffer.from(e.name, 'utf8');
    const comp = deflateRawSync(e.data); const crc = crc32(e.data);
    const lh = Buffer.alloc(30);
    lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(FLAG, 6); lh.writeUInt16LE(METHOD, 8);
    lh.writeUInt16LE(DOSTIME, 10); lh.writeUInt16LE(DOSDATE, 12); lh.writeUInt32LE(crc, 14);
    lh.writeUInt32LE(comp.length, 18); lh.writeUInt32LE(e.data.length, 22); lh.writeUInt16LE(nameBuf.length, 26); lh.writeUInt16LE(0, 28);
    parts.push(lh, nameBuf, comp);
    const cd = Buffer.alloc(46);
    cd.writeUInt32LE(0x02014b50, 0); cd.writeUInt16LE((3 << 8) | 20, 4); cd.writeUInt16LE(20, 6); cd.writeUInt16LE(FLAG, 8);
    cd.writeUInt16LE(METHOD, 10); cd.writeUInt16LE(DOSTIME, 12); cd.writeUInt16LE(DOSDATE, 14); cd.writeUInt32LE(crc, 16);
    cd.writeUInt32LE(comp.length, 20); cd.writeUInt32LE(e.data.length, 24); cd.writeUInt16LE(nameBuf.length, 28);
    cd.writeUInt16LE(0, 30); cd.writeUInt16LE(0, 32); cd.writeUInt16LE(0, 34); cd.writeUInt16LE(0, 36);
    cd.writeUInt32LE(((0o100644) << 16) >>> 0, 38); cd.writeUInt32LE(offset, 42);
    central.push(cd, nameBuf); offset += lh.length + nameBuf.length + comp.length;
  }
  const cdBuf = Buffer.concat(central); const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0); eocd.writeUInt16LE(entries.length, 8); eocd.writeUInt16LE(entries.length, 10);
  eocd.writeUInt32LE(cdBuf.length, 12); eocd.writeUInt32LE(offset, 16);
  writeFileSync(outPath, Buffer.concat([...parts, cdBuf, eocd]));
}

/** デッキを「画像込みで自己完結するHTML」として配布できる形にする：
 *  HTML化(fmt:'html')した上で、参照している assets/ 一式を同梱した zip を out/ に書き出す。
 *  HTML単体だとスライド内画像・Mermaid由来SVGが相対パス参照のままリンク切れになるため。 */
export function exportHtmlZip(mdPath, { outPath = null, log = console.log } = {}) {
  mdPath = resolve(mdPath);
  const deckDir = dirname(mdPath);
  const stem = basename(mdPath, '.md');
  mkdirSync(join(deckDir, 'out'), { recursive: true });
  const htmlPath = join(deckDir, 'out', `${stem}.html`);
  const { mermaidErrors, mermaidDeferred } = exportDeck(mdPath, { fmt: 'html', outPath: htmlPath, log });
  const entries = [{ name: `${stem}.html`, data: readFileSync(htmlPath) }];
  const assetsDir = join(deckDir, 'assets');
  if (existsSync(assetsDir)) {
    for (const relPath of listFilesRecursive(assetsDir)) {
      entries.push({ name: `assets/${relPath}`, data: readFileSync(join(assetsDir, relPath)) });
    }
  }
  const out = outPath || join(deckDir, 'out', `${stem}.zip`);
  writeZipFile(entries, out);
  return { out, mermaidErrors, mermaidDeferred };
}

/** 環境セルフチェック: Node / marp / mermaid(mmdc) が実際に動くか確認して結果を返す。
 *  mermaid は小さな図を実描画して、失敗時は mmdc/Chromium の実エラーを detail に載せる
 *  （「一人だけ図が出ない」の原因切り分け用）。システムChrome使用時はその旨も返す。 */
export function checkEnvironment() {
  const r = {};
  r.node = { ok: true, detail: process.version };
  try { r.marp = { ok: true, detail: execSync('marp --version', { stdio: 'pipe' }).toString().trim() + '（グローバル）' }; }
  catch { r.marp = { ok: true, detail: 'グローバル未導入。npx で自動取得します（初回はネット接続が必要）' }; }
  const chrome = findSystemChrome();
  try {
    const svg = mermaidCodeToSvg('flowchart LR\n  A-->B');
    const via = (_mmdcCmd === 'mmdc' ? 'mmdc(グローバル)' : 'npx 取得') + (chrome ? ` / ブラウザ: ${chrome}` : ' / Puppeteer同梱Chromium');
    r.mermaid = { ok: /<svg[\s>]/.test(svg), detail: '描画OK（' + via + '）' };
  } catch (e) {
    r.mermaid = { ok: false, detail: (e.detail || e.message || '不明なエラー').slice(0, 4000),
      hint: chrome ? `検出済みブラウザ(${chrome})でも失敗。エラー全文を共有してください。`
                   : 'Chrome/Edge が見つかりません。Google Chrome か Microsoft Edge を入れると直ることが多いです。' };
  }
  return r;
}

/** 図ツール(mmdc)をバックグラウンドで先読み（起動時に1回）。npx のパッケージ取得や Chromium 起動を
 *  ユーザーが待つ前に済ませておく＝「初回の図描画だけ1分近く固まる」体験をなくす。非ブロッキング・失敗は無視。 */
let _warmed = false;
export function warmupMermaid(log = () => {}) {
  if (_warmed) return; _warmed = true;
  try {
    const base = join(tmpdir(), `marp-warm-${process.pid}`);
    const inPath = base + '.mmd', outPath = base + '.svg';
    writeFileSync(inPath, 'flowchart LR\n  A-->B');
    log('Mermaid: 図ツールを準備しています（初回のみ・バックグラウンド）…');
    exec(`${mmdcCmd()} -i "${inPath}" -o "${outPath}" -b transparent`, { env: mmdcEnv() }, (err) => {
      try { rmSync(inPath, { force: true }); } catch {}
      try { rmSync(outPath, { force: true }); } catch {}
      log(err ? 'Mermaid: 図ツールの先読みに失敗（保存時に通常どおり実行します）' : 'Mermaid: 図ツールの準備が完了しました');
    });
  } catch { /* 先読み失敗は無視（本番の描画時に通常フローで実行） */ }
}

/** doc-map（プロジェクト管理ドキュメントの関係図）を「正本1枚」から各デッキへ配布。
 *  正本: <decksRoot>/_common/doc-map.mmd（中立・ハイライト無し）
 *  各デッキ .md の `<!-- doc-id: X -->` を読み、ノード X を緑ハイライトした
 *  <deck>/assets/doc-map.mmd を生成（SVG化は export に委譲＝自己完結を維持）。
 *  deckMd を渡せばその1本、渡さなければ decksRoot 配下の全デッキを同期。 */
export function syncDocMap({ deckMd = null, decksRoot = null, log = console.log } = {}) {
  const root = decksRoot ? resolve(decksRoot) : (deckMd ? dirname(dirname(resolve(deckMd))) : null);
  if (!root) throw new Error('usage: docmap <デッキ.md>  または  docmap --all <decksフォルダ>');
  const canonical = join(root, '_common', 'doc-map.mmd');
  if (!existsSync(canonical)) throw new Error(`正本が見つかりません: ${canonical}`);
  const base = readFileSync(canonical, 'utf8').replace(/\s+$/, '');

  const decks = deckMd
    ? [resolve(deckMd)]
    : readdirSync(root)
        .filter((n) => !n.startsWith('_') && !n.startsWith('.'))
        .map((n) => join(root, n, `${n}.md`))
        .filter((p) => existsSync(p));

  let done = 0, warned = 0;
  for (const md of decks) {
    const m = readFileSync(md, 'utf8').match(/<!--\s*doc-id:\s*([A-Za-z0-9_-]+)\s*-->/);
    if (!m) { log(`WARN: doc-id 未宣言（スキップ）: ${md}`); warned++; continue; }
    const id = m[1];
    if (!new RegExp(`(^|\\n)\\s*${id}\\b`).test(base)) {
      log(`WARN: doc-id "${id}" が正本に存在しない（スキップ）: ${md}`); warned++; continue;
    }
    const deckDir = dirname(md);
    mkdirSync(join(deckDir, 'assets'), { recursive: true });
    const outMmd = join(deckDir, 'assets', 'doc-map.mmd');
    writeFileSync(outMmd, `${base}\n  class ${id} this;\n`);
    log(`OK: ${outMmd}  (doc-id=${id})`);
    done++;
  }
  return { done, warned };
}

/** ドキュメント・カタログ表を「正本TSV1枚」から各デッキへ配布。
 *  正本: <decksRoot>/_common/doc-catalog.tsv（または catalogPath 明示）。列は
 *  doc-id / 短名 / 記載内容 / 必須度 / 順 / 所在 / PMBOK（TAB区切り・# と空行は無視）。
 *  必須度=対象外 は「別途定義」注記へ、=内包 は「独立文書なし」の表外コメントへ回す。
 *  各デッキ .md の `<!-- doc-id: X -->` を読み、<!-- catalog:start --> 〜 <!-- catalog:end -->
 *  の間を、doc-id 一致行を緑強調したHTML表で置換する（markdown内HTML＝SVG生成不要）。
 *  deckMd 単体、または decksRoot 配下の再帰探索（マーカー付きmdだけ対象＝1/2階層どちらもOK）。 */
export function syncCatalog({ deckMd = null, decksRoot = null, catalogPath = null, log = console.log } = {}) {
  const root = decksRoot ? resolve(decksRoot) : (deckMd ? dirname(dirname(resolve(deckMd))) : null);
  const tsv = catalogPath ? resolve(catalogPath) : (root ? join(root, '_common', 'doc-catalog.tsv') : null);
  if (!tsv) throw new Error('usage: catalog <デッキ.md> | catalog --all <フォルダ> [--catalog <tsv>]');
  if (!existsSync(tsv)) throw new Error(`カタログ正本が見つかりません: ${tsv}（--catalog で明示可）`);

  const rows = readFileSync(tsv, 'utf8').split(/\r?\n/)
    .map((l) => l.replace(/\s+$/, ''))
    .filter((l) => l && !l.startsWith('#'))
    .map((l) => l.split('\t'))
    .filter((c) => c.length >= 4)
    .map((c) => ({ id: c[0].trim(), name: c[1].trim(), desc: c[2].trim(), need: c[3].trim(), order: (c[4] || '').trim(), loc: (c[5] || '').trim(), pmbok: (c[6] || '').trim() }));
  if (rows.length === 0) throw new Error(`カタログに有効な行がありません: ${tsv}`);

  const weight = (need) => need.startsWith('必読') ? 0 : need.startsWith('推奨') ? 1 : need.startsWith('随時') ? 2 : 3;
  const ordNum = (o) => { const n = parseInt(o, 10); return Number.isFinite(n) ? n : 99; };
  // 作成状況(済/中/未)は所在から自動算出（別列を持たず値のズレを防ぐ）。
  const docStatus = (loc) => loc === '未作成' ? '未' : loc.startsWith('decks/') ? '中' : '済';
  rows.sort((a, b) => weight(a.need) - weight(b.need) || ordNum(a.order) - ordNum(b.order));
  const esc = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

  const buildTable = (hereId) => {
    // Marp Studio衛生ルール準拠: 生<table>とセル背景色は使わず、Markdownの表で出す。
    // 本書の強調は「テーマ非追従の緑背景」ではなく ★ + 行全体を太字 で表す（テーマ変更に追従・機械可読・小さい表でも埋もれない）。
    const mesc = (s) => String(s == null ? '' : s).replace(/\|/g, '\\|').replace(/\r?\n/g, ' ');  // セル内| をエスケープ
    // need=対象外/内包 は主表から除外し、下段の注記/コメントへ回す。作成状況(status列)は表内・別表分割はしない。
    const isExcluded = (r) => r.need === '対象外';   // 資料は存在するが本一覧の対象外(別途定義)
    const isIncluded = (r) => r.need === '内包';     // 独立文書を設けずPMBOK領域を他文書に内包
    const core = rows.filter((r) => !isExcluded(r) && !isIncluded(r));
    const excluded = rows.filter(isExcluded);
    const included = rows.filter(isIncluded);
    const bodyRow = (r) => {
      const here = r.id === hereId;
      const need = r.need.startsWith('必読') && ordNum(r.order) !== 99 ? `${r.need} ${r.order}` : r.need;
      const cells = [here ? `★ ${mesc(r.name)}` : mesc(r.name), mesc(r.id), mesc(r.loc), mesc(r.desc), mesc(r.pmbok || '―'), mesc(need), docStatus(r.loc)];
      return `| ${cells.map((c) => here ? `**${c}**` : c).join(' | ')} |`;
    };
    let out = `| 文書 | ID | 所在 | 記載内容 | PMBOK知識エリア | 必須度・順 | 作成 |\n`
      + `|---|---|---|---|---|---|---|\n`
      + `${core.map(bodyRow).join('\n')}\n\n`
      + `<div style="color:#6f6f6f;margin-top:6px;"><b>★・行の強調</b>＝本書 ／ <b>作成</b>=済(共有docsリポジトリへ共有化済)・中(decks配下で作成中)・未(未着手) ／ <b>必読</b>=まず1→2→3（2は並行） ／ <b>推奨</b>=必読ではないが読むと理解が深まる背景・詳細 ／ <b>所在</b>=docsリポジトリ内パス</div>`;
    if (included.length) {
      // 内包＝独立文書を設けないPMBOK領域。表外コメント（矢印でなく「Xに含める」で表現）。
      const inc = included.map((r) => `${mesc(r.name)}は${mesc(r.loc)}に含める`).join(' ／ ');
      out += `\n\n<div style="color:#525252;margin-top:8px;">※ PMBOK知識エリアのうち独立文書を設けない領域: ${inc}</div>`;
    }
    if (excluded.length) {
      // 対象外＝資料は存在するが本一覧の対象外(別途定義)・将来削除予定。
      // 縦を圧迫しないよう本文フローに置かず、付箋(.fusen)で右下に貼る（消せる補足）。
      const eLine = (r) => `・${mesc(r.name)}（${mesc(r.loc)}）`;
      out += `\n\n<div class="fusen yellow small" style="right:24px; bottom:52px; max-width:64%; text-align:left;">`
        + `<b>※ 本一覧の対象外（別途定義・将来削除）</b><br>`
        + excluded.map(eLine).join('<br>')
        + `</div>`;
    }
    // 3表＋注記を1スライドに収めるため全体を縮小（tableのfont-sizeはここで一括制御）。
    return `<div style="font-size:0.72em">\n\n${out}\n\n</div>`;
  };

  const START = '<!-- catalog:start -->', END = '<!-- catalog:end -->';
  const collect = (dir) => {
    const found = [];
    const walk = (d) => {
      for (const n of readdirSync(d)) {
        if (n.startsWith('.') || n.startsWith('_') || n === 'node_modules' || n === 'out' || n === 'assets') continue;
        const p = join(d, n);
        let st; try { st = statSync(p); } catch { continue; }
        if (st.isDirectory()) walk(p);
        else if (n.toLowerCase().endsWith('.md')) found.push(p);
      }
    };
    walk(dir);
    return found;
  };

  const decks = deckMd ? [resolve(deckMd)] : collect(root);
  let done = 0, warned = 0;
  for (const md of decks) {
    let src = readFileSync(md, 'utf8');
    if (!src.includes(START) || !src.includes(END)) {
      if (deckMd) { log(`WARN: catalog マーカー(<!-- catalog:start/end -->)が無い: ${md}`); warned++; }
      continue; // --all ではマーカー付きmdだけ対象＝静かにスキップ
    }
    const m = src.match(/<!--\s*doc-id:\s*([A-Za-z0-9_-]+)\s*-->/);
    const id = m ? m[1] : null;
    if (!id) { log(`WARN: doc-id 未宣言（強調なしで配布）: ${md}`); warned++; }
    else if (!rows.some((r) => r.id === id)) { log(`WARN: doc-id "${id}" はカタログ未登録（強調なしで配布）: ${md}`); warned++; }
    const re = new RegExp(`${START}[\\s\\S]*?${END}`);
    src = src.replace(re, `${START}\n\n${buildTable(id)}\n\n${END}`);
    writeFileSync(md, src);
    log(`OK: ${md}  (doc-id=${id || '—'})`);
    done++;
  }
  return { done, warned };
}

/* ----------------------------- CLI（直接実行時のみ） ----------------------------- */
function die(msg) { console.error('ERROR: ' + msg); process.exit(1); }
const isMain = process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href;
const [sub, ...rest] = isMain ? process.argv.slice(2) : [false];
if (!isMain) {
  // import 時はCLIを実行しない（studio から関数だけ使う）
} else if (sub === 'new') {
  const [targetDir, title, subtitle] = rest;
  if (!targetDir || !title) die('usage: new <作成先フォルダ> "タイトル" ["サブタイトル"]');
  try {
    const { mdPath } = createDeck({ targetDir, title, subtitle });
    console.log(`OK: created ${mdPath}`);
    console.log(`  PDF出力: node ${process.argv[1]} export "${mdPath}"`);
  } catch (e) { die(e.message); }
} else if (sub === 'export') {
  const [mdArg] = rest;
  if (!mdArg) die('usage: export <デッキ.md>');
  try {
    const { out } = exportDeck(mdArg);
    console.log(`OK: ${out}`);
  } catch (e) { die(e.message); }
} else if (sub === 'docmap') {
  const [arg, arg2] = rest;
  try {
    let r;
    if (arg === '--all') r = syncDocMap({ decksRoot: arg2 || '.' });
    else if (arg) r = syncDocMap({ deckMd: arg });
    else die('usage: docmap <デッキ.md>  |  docmap --all <decksフォルダ>');
    console.log(`OK: ${r.done} デッキ更新 / ${r.warned} 警告`);
    console.log('  ※ doc-map.svg は export 時に生成されます');
  } catch (e) { die(e.message); }
} else if (sub === 'catalog') {
  // catalog <デッキ.md> [--catalog <tsv>]  |  catalog --all <フォルダ> [--catalog <tsv>]
  let catalogPath = null, all = null, one = null;
  for (let i = 0; i < rest.length; i++) {
    if (rest[i] === '--catalog') catalogPath = rest[++i];
    else if (rest[i] === '--all') all = rest[++i];
    else if (!one) one = rest[i];
  }
  try {
    let r;
    if (all) r = syncCatalog({ decksRoot: all, catalogPath });
    else if (one) r = syncCatalog({ deckMd: one, catalogPath });
    else die('usage: catalog <デッキ.md> | catalog --all <フォルダ> [--catalog <tsv>]');
    console.log(`OK: ${r.done} デッキ更新 / ${r.warned} 警告`);
  } catch (e) { die(e.message); }
} else if (sub === undefined) {
  console.log('marp-deck.mjs — デッキ雛形生成/エクスポート');
  console.log('  node marp-deck.mjs new <フォルダ> "タイトル" ["サブタイトル"]');
  console.log('  node marp-deck.mjs export <デッキ.md>');
  console.log('  node marp-deck.mjs docmap <デッキ.md> | --all <decksフォルダ>');
  console.log('  node marp-deck.mjs catalog <デッキ.md> | --all <フォルダ> [--catalog <tsv>]');
} else {
  die(`unknown command: ${sub}`);
}
