#!/usr/bin/env node
/* ================================================================
 * marp-deck.mjs  —  共通テーマ用 デッキ雛形生成 / エクスポート（エンジン）
 *
 * クロスプラットフォーム（Mac/Windows/Linux）。Node だけで動く。
 * CLI からも、ローカルWeb GUI（studio/server.mjs）からも共用する関数を export する。
 *
 * CLI:
 *   node marp-deck.mjs new <作成先フォルダ> "タイトル" ["サブタイトル"]
 *   node marp-deck.mjs export <デッキ.md>
 *
 * 設計方針（場所に依存させない）:
 *   - テーマは `theme: <ブランド既定>`（既定 base／.marp-studio.json の brand で上書き。CLI/GUIは --theme-set を自動付与）
 *   - ロゴはテーマに data URI 埋め込み済み（参照不要）
 *   - デッキは「自己完結フォルダ」: 図やカバー画像は各デッキの assets/ に置く
 *   - 作成物は out/ の PDF（画像埋め込み・自己完結）
 *   - export 時に assets/*.mmd を自動でSVG化（手動 mmdc 不要）
 * ================================================================ */
import { mkdirSync, writeFileSync, copyFileSync, existsSync, readdirSync, readFileSync, rmSync, statSync } from 'node:fs';
import { resolve, dirname, join, basename } from 'node:path';
import { tmpdir } from 'node:os';
import { pathToFileURL } from 'node:url';
import { execSync, exec } from 'node:child_process';
import { createHash } from 'node:crypto';

/** ブランド既定（顧客非依存・中立）。
 *  顧客名・自社名は含めない（製品=社内アセットにこのエンジンがそのまま入るため）。
 *  各リポは .marp-studio.json の "brand" で上書きする
 *  （例: defaultTheme:"acme", projectLabel:"... プロジェクト", footer:"© 2026 自社名"）。 */
const NEUTRAL_BRAND = {
  defaultTheme: 'base',                 // 新規デッキの frontmatter theme:
  projectLabel: '',                     // 表紙の ### 行（プロジェクト/顧客名）。空なら出さない
  customer: '',                         // 顧客ラベル（例 Acme）。Marp Studio のホーム副題に表示。空なら出さない
  footer: '© 2026',                     // 右下フッター（中立。自社名は .marp-studio.json で付与）
};

/** デッキ位置から親をたどって .marp-studio.json を探し brand を返す（無ければ中立）。 */
export function loadBrand(startDir) {
  let d = resolve(startDir);
  for (;;) {
    const p = join(d, '.marp-studio.json');
    if (existsSync(p)) {
      try { const c = JSON.parse(readFileSync(p, 'utf8')); return { ...NEUTRAL_BRAND, ...(c.brand || {}) }; }
      catch { /* 壊れた設定は無視して中立にフォールバック */ }
    }
    const parent = dirname(d);
    if (parent === d) return { ...NEUTRAL_BRAND };
    d = parent;
  }
}

/** デッキ位置から親をたどって 00_common/assets/marp を探す（場所非依存の肝） */
export function findThemeDir(startDir) {
  let d = resolve(startDir);
  for (;;) {
    if (existsSync(join(d, '00_common/assets/marp'))) {   // テーマCSSのファイル名に依存しない
      return join(d, '00_common/assets/marp');
    }
    const parent = dirname(d);
    if (parent === d) return null;
    d = parent;
  }
}

/** Mermaid: assets/*.mmd を .svg に再生成（無ければ何もしない）。
 *  marp の ![]() 用に width/height を明示（width="100%" だと高さが潰れるため）。
 *  キャッシュ: .svg が .mmd より新しければ mmdc（ヘッドレスChrome）を起動しない＝再描画スキップ。 */
export function renderMermaid(assetsDir, log = console.log, errors = [], fast = false) {
  if (fast) return;   // 速いプレビュー: assets/*.mmd の再SVG化（重い mmdc）はしない＝既存svgのまま
  if (!existsSync(assetsDir)) return;
  const mmds = readdirSync(assetsDir).filter((f) => f.toLowerCase().endsWith('.mmd'));
  if (mmds.length === 0) return;
  // 変更があった .mmd だけを対象にする（未変更なら mmdc を呼ばない）。
  const stale = mmds.filter((f) => {
    const outPath = join(assetsDir, f.replace(/\.mmd$/i, '.svg'));
    try { return !existsSync(outPath) || statSync(outPath).mtimeMs < statSync(join(assetsDir, f)).mtimeMs; }
    catch { return true; }
  });
  if (stale.length === 0) return;   // 全てキャッシュ済み
  log(`Mermaid: ${stale.length}/${mmds.length} 件を SVG 化します（初回は mmdc 取得で時間がかかります）…`);
  for (const f of stale) {
    const inPath = join(assetsDir, f);
    const outPath = join(assetsDir, f.replace(/\.mmd$/i, '.svg'));
    try {
      execSync(`${mmdcCmd()} -i "${inPath}" -o "${outPath}" -b transparent`, { stdio: 'pipe', env: mmdcEnv() });
      fixSvgSize(outPath);
      log(`  ${f} → ${basename(outPath)}`);
    } catch (e) {
      const detail = (e.stderr && e.stderr.toString().trim()) || (e.stdout && e.stdout.toString().trim()) || e.message;
      errors.push({ file: f, detail });
      log(`  [警告] mmdc 実行に失敗: ${f} — ${detail}`);
    }
  }
}

/** width="100%"（高さ潰れの原因）を viewBox 由来の固定 px に直す。max-width:...px も除去。 */
function fixSvgSizeStr(s) {
  const vb = s.match(/viewBox="0 0 ([\d.]+) ([\d.]+)"/);
  if (vb && /width="100%"/.test(s)) {
    s = s.replace(/width="100%"/, `width="${Math.round(parseFloat(vb[1]))}" height="${Math.round(parseFloat(vb[2]))}"`);
  }
  return s.replace(/max-width:\s*[\d.]+px;?/g, '');
}
function fixSvgSize(svgPath) {
  if (!existsSync(svgPath)) return;
  writeFileSync(svgPath, fixSvgSizeStr(readFileSync(svgPath, 'utf8')));
}

/** Mermaid のコード文字列を mmdc で SVG 文字列に変換（一時ファイル経由・後始末する）。 */
let _mmFenceSeq = 0;
function mermaidCodeToSvg(code) {
  const base = join(tmpdir(), `marp-mmfence-${process.pid}-${_mmFenceSeq++}`);
  const inPath = base + '.mmd', outPath = base + '.svg';
  writeFileSync(inPath, code);
  try {
    execSync(`${mmdcCmd()} -i "${inPath}" -o "${outPath}" -b transparent`, { stdio: 'pipe', env: mmdcEnv() });
    return fixSvgSizeStr(readFileSync(outPath, 'utf8'));
  } catch (e) {
    // execSync の失敗は stderr に mmdc/puppeteer/Chromium の実エラーが入る（「図が出ない」原因の本体）。
    // e.message（コマンド＋終了コード）だけだと原因が分からないので stderr/stdout を detail に載せて投げ直す。
    const detail = (e.stderr && e.stderr.toString().trim()) || (e.stdout && e.stdout.toString().trim()) || e.message;
    const err = new Error(detail); err.detail = detail; throw err;
  } finally {
    try { rmSync(inPath, { force: true }); } catch {}
    try { rmSync(outPath, { force: true }); } catch {}
  }
}

/** md 内の ```mermaid フェンスを抽出し、各々を SVG 化→assets/.fences/fence-N.svg へ書き出し、
 *  そのファイルを相対参照する ![opts](assets/.fences/fence-N.svg) に置換した「一時md」を
 *  deckDir 直下に生成して返す（元 md は不変）。フェンスが無ければ null。
 *  フェンスの info string（例: ```mermaid h:440）は marp 画像オプションとして引き継ぐ。
 *  ＝ソースは md の ```mermaid 1か所（genAI直読）、描画はビルド時のみ画像化（PDF安定）。 */
function inlineMermaidFences(mdPath, log = console.log, errors = [], fast = false, deferred = []) {
  const src = readFileSync(mdPath, 'utf8');
  const re = /^([ \t]*)```mermaid[ \t]*([^\n]*)\n([\s\S]*?)\n[ \t]*```[ \t]*$/gm;
  const deckDir = dirname(mdPath);
  const fdir = join(deckDir, 'assets', '.fences');   // フェンス由来svgの置き場（生成物・gitignore）
  // フェンスはコード内容のハッシュでキャッシュ＝未変更フェンスは mmdc（Chrome）を呼ばず既存svgを再利用。
  let total = 0, built = 0; const used = new Set();
  const out = src.replace(re, (m, indent, opts, code) => {
    total++;
    const hash = createHash('sha1').update(code).digest('hex').slice(0, 16);
    const fname = `fence-${hash}.svg`;
    const fpath = join(fdir, fname);
    const ref = `${indent}![${(opts || '').trim()}](assets/.fences/${fname})`;
    if (existsSync(fpath)) { used.add(fname); return ref; }   // キャッシュヒット＝そのまま描画
    // 速いプレビュー(fast): 未キャッシュの重い図は描かず、元のフェンス(コード)のまま残す＝保存時に描画。
    if (fast) { deferred.push({}); return m; }
    try {                                             // 通常(保存/PDF): キャッシュミスを mmdc で描画
      mkdirSync(fdir, { recursive: true });
      writeFileSync(fpath, mermaidCodeToSvg(code));
      built++; used.add(fname);
      // marp(markdown-it) は data:image/svg+xml を弾く（validateLink）。相対svgファイル参照で描画する。
      return ref;
    } catch (e) {
      const detail = e.detail || e.message;
      errors.push({ detail });
      log(`  [警告] mermaid フェンスの描画に失敗（コードブロックのまま）: ${detail}`);
      return m;
    }
  });
  if (total === 0) return null;
  // 使われなくなった古いフェンスsvgを掃除（キャッシュの肥大化防止）。fastでは消さない＝キャッシュ温存（保存時の再描画を減らす）。
  if (!fast) { try { for (const f of readdirSync(fdir)) { if (f.endsWith('.svg') && !used.has(f)) rmSync(join(fdir, f), { force: true }); } } catch {} }
  log(`Mermaid: フェンス ${total} 件（再描画 ${built} / キャッシュ ${total - built}${deferred.length ? ' / 保存時に描画 ' + deferred.length : ''}）`);
  const tmp = join(deckDir, `.${basename(mdPath, '.md')}.mmfence.tmp.md`);
  writeFileSync(tmp, out);
  return tmp;
}

/** 新規デッキ（自己完結フォルダ）を作成。{ mdPath, deckDir } を返す。 */
export function createDeck({ targetDir, title, subtitle, brand }) {
  const deckDir = resolve(targetDir);
  const b = { ...NEUTRAL_BRAND, ...(brand || loadBrand(deckDir)) };
  const themeDir = findThemeDir(deckDir) || findThemeDir(process.cwd());
  if (!themeDir) throw new Error('00_common/assets/marp が見つかりません（リポジトリ配下で実行してください）');

  const name = basename(deckDir);
  const mdPath = join(deckDir, `${name}.md`);
  if (existsSync(mdPath)) throw new Error(`既に存在します: ${mdPath}`);

  mkdirSync(join(deckDir, 'assets'), { recursive: true });
  mkdirSync(join(deckDir, 'out'), { recursive: true });

  // 表紙背景はテーマが提供（--title-bg）。MDで ![bg] は指定しない（指定するとテーマ表紙を上書きするため）。
  // 個別にカバー画像を貼りたい場合のみ assets/ に置いて ![bg](assets/xxx) を手書きする。
  const coverLine = '<!-- 表紙背景はテーマが提供（--title-bg）。個別指定したいときだけ ![bg](assets/xxx) を書く -->';

  // 結びページ: 中立な表紙レイアウトのクローズ（顧客非依存）。
  const closing = '<!-- _class: closing -->\n<!-- _paginate: false -->';

  const sub = subtitle || 'サブタイトル';
  const projectLine = b.projectLabel ? `### ${b.projectLabel}\n` : '';
  const md = `---
marp: true
theme: ${b.defaultTheme}
paginate: true
footer: '${b.footer}'
---

<!-- _class: cover -->
<!-- _paginate: false -->
<!-- doc-id: TODO -->
<!-- ↑ 正本マップ decks/_common/doc-map.mmd のノードID に置き換える -->

${coverLine}

# ${title}
## ${sub}
${projectLine}
---

<!-- _class: section -->

# 本書について

---

# 本書の位置づけ

<div class="lead-area">本書はプロジェクト管理ドキュメント群の一冊。全体の中での位置は下図（<b style="color:#198038">緑＝本書</b>）。</div>

<!-- 〔プロジェクト管理ガイド系の場合〕doc-id を宣言し  node 00_common/tools/marp/marp-deck.mjs docmap <この.md>  を実行すると下図が生成される。 -->
<!-- ※プロジェクト管理ガイド系でなければ、この「本書の位置づけ」スライドと表紙の doc-id 行は削除してよい -->
![doc-map](assets/doc-map.svg)

---

# 本書の役割（目的・ゴール）

<div class="lead-area">本書が<strong>定義すること</strong>と、読み終えて<strong>分かること</strong>。</div>

<div class="columns">
<div>

**本書が定義する**
- （この文書が定める内容）

</div>
<div>

**読み終えると（ゴール）**
- （読者が理解・実行できること）

</div>
</div>

> **スコープ外**：（この文書が扱わない範囲）

---

# 目次

| 章 | テーマ | 状態（完成後削除） |
|---|---|:---:|
| 1. （章名） | （テーマ） | 骨組み |
| 2. （章名） | （テーマ） | 骨組み |

---

# 用語・凡例

<div class="lead-area">本書で頻出する用語と凡例。先に押さえてから読み進める。</div>

| 用語 | 意味 |
|---|---|
| （用語） | （説明） |

> **凡例**：（色・記号の意味）

---

<!-- _class: section -->

# 1. （セクション名）
## （サブタイトル）

---

# 1-1. （タイトルとコンテンツ）

- ここから本文。
- **図は md に \`\`\`mermaid フェンスで直接書く**（ビルド時に画像化＝PDF安定・genAIは構造を直読）。下が例。
- 位置やサイズ微調整が要る図は \`![](assets/xxx.svg)\` 参照も可。レイアウトは 00_common/assets/marp/README.md 参照。

\`\`\`mermaid
flowchart LR
  A[開始] --> B[処理] --> C[完了]
\`\`\`

---

${closing}
`;
  writeFileSync(mdPath, md);
  return { mdPath, deckDir };
}

/** marp CLI を解決：グローバル `marp` があればそれを、無ければ `npx -y @marp-team/marp-cli`。
 *  （Mac=グローバル導入で高速 / Windows等=未導入でも npx 取得で動く。mermaid と同じ方針） */
let _marpCmd = null;
function marpBin() {
  if (_marpCmd) return _marpCmd;
  try { execSync('marp --version', { stdio: 'pipe' }); _marpCmd = 'marp'; }
  catch { _marpCmd = 'npx -y @marp-team/marp-cli'; }
  return _marpCmd;
}
/** mmdc（mermaid-cli）を解決：グローバル `mmdc` があればそれを、無ければ `npx -y @mermaid-js/mermaid-cli`。
 *  1回だけ解決して使い回す（npx の都度パッケージ解決コストを避ける）。 */
let _mmdcCmd = null;
function mmdcCmd() {
  if (_mmdcCmd) return _mmdcCmd;
  try { execSync('mmdc --version', { stdio: 'pipe' }); _mmdcCmd = 'mmdc'; }
  catch { _mmdcCmd = 'npx -y @mermaid-js/mermaid-cli'; }
  return _mmdcCmd;
}
/** システムに入っている Chrome/Edge/Chromium/Brave を探す（見つからなければ null）。1回だけ解決。 */
let _sysChrome;
export function findSystemChrome() {
  if (_sysChrome !== undefined) return _sysChrome;
  const cands = process.platform === 'darwin' ? [
    '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',
    '/Applications/Chromium.app/Contents/MacOS/Chromium',
    '/Applications/Brave Browser.app/Contents/MacOS/Brave Browser',
  ] : process.platform === 'win32' ? [
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    process.env.LOCALAPPDATA ? join(process.env.LOCALAPPDATA, 'Google\\Chrome\\Application\\chrome.exe') : '',
  ] : [
    '/usr/bin/google-chrome', '/usr/bin/google-chrome-stable',
    '/usr/bin/chromium-browser', '/usr/bin/chromium', '/usr/bin/microsoft-edge',
  ];
  _sysChrome = cands.find((p) => p && existsSync(p)) || null;
  return _sysChrome;
}
/** mmdc(=Puppeteer) 用の環境変数。PUPPETEER_EXECUTABLE_PATH 未設定なら、見つけたシステムChrome/Edgeを使わせる。
 *  npx経由のmmdcは Chromium 未取得（社内プロキシでDL不可など）だと起動に失敗しがち。既存ブラウザで回避する＝「一人だけ図が出ない」対策。 */
function mmdcEnv() {
  const env = { ...process.env };
  if (!env.PUPPETEER_EXECUTABLE_PATH) { const c = findSystemChrome(); if (c) env.PUPPETEER_EXECUTABLE_PATH = c; }
  return env;
}

/** デッキを PDF/HTML 出力。{ out } を返す。fmt: 'pdf' | 'html'。
 *  outPath を渡すとその場所に出力（プレビューHTMLはデッキ直下に置くと assets/ 相対が解決できる）。 */
export function exportDeck(mdPath, { fmt = 'pdf', outPath = null, log = console.log, fast = false } = {}) {
  mdPath = resolve(mdPath);
  if (!existsSync(mdPath)) throw new Error(`not found: ${mdPath}`);
  const deckDir = dirname(mdPath);
  const themeDir = findThemeDir(deckDir);
  if (!themeDir) throw new Error('00_common/assets/marp が見つかりません');

  // Mermaid描画の失敗を集約（呼び出し側＝Studioが「N件の図が描けません: 〇〇」を画面表示できるように）。
  // fast=true（自動プレビュー）では未キャッシュの図を描かず deferred に積む＝「保存で反映」をUIに出せる。
  const mermaidErrors = [], mermaidDeferred = [];

  // 5-2 を内包: assets/*.mmd を SVG 化してから marp（手動 mmdc 不要・PDFが壊れない）
  renderMermaid(join(deckDir, 'assets'), log, mermaidErrors, fast);

  // ```mermaid フェンスがあれば SVG ファイル(assets/.fences/) 参照に差し替えた一時 md を使う（元 md は不変）
  const tmpMd = inlineMermaidFences(mdPath, log, mermaidErrors, fast, mermaidDeferred);
  const inputMd = tmpMd || mdPath;

  // marp/ 内の全テーマCSS（/* @theme x */ 付き）を登録 → デッキの frontmatter theme: で選択
  const themeCss = readdirSync(themeDir).filter((f) => f.toLowerCase().endsWith('.css')).map((f) => join(themeDir, f));
  const ext = fmt === 'html' ? 'html' : 'pdf';
  let out = outPath;
  if (!out) {
    mkdirSync(join(deckDir, 'out'), { recursive: true });
    out = join(deckDir, 'out', basename(mdPath).replace(/\.md$/, `.${ext}`));
  }

  const q = (s) => `"${s}"`;
  const flag = fmt === 'html' ? '--html' : '--html --pdf';
  const themeArgs = themeCss.map((t) => `--theme-set ${q(t)}`).join(' ');
  const cmd = `${marpBin()} ${q(inputMd)} ${themeArgs} ${flag} --allow-local-files -o ${q(out)}`;
  log(cmd);
  try {
    execSync(cmd, { stdio: 'pipe' });
  } finally {
    if (tmpMd) { try { rmSync(tmpMd, { force: true }); } catch {} }
  }
  return { out, mermaidErrors, mermaidDeferred };
}

/** 環境セルフチェック: Node / marp / mermaid(mmdc) が実際に動くか確認して結果を返す。
 *  mermaid は小さな図を実描画して、失敗時は mmdc/Chromium の実エラーを detail に載せる
 *  （「一人だけ図が出ない」の原因切り分け用）。システムChrome使用時はその旨も返す。 */
export function checkEnvironment() {
  const r = {};
  r.node = { ok: true, detail: process.version };
  try { r.marp = { ok: true, detail: execSync('marp --version', { stdio: 'pipe' }).toString().trim() + '（グローバル）' }; }
  catch { r.marp = { ok: true, detail: 'グローバル未導入。npx で自動取得します（初回はネット接続が必要）' }; }
  const chrome = findSystemChrome();
  try {
    const svg = mermaidCodeToSvg('flowchart LR\n  A-->B');
    const via = (_mmdcCmd === 'mmdc' ? 'mmdc(グローバル)' : 'npx 取得') + (chrome ? ` / ブラウザ: ${chrome}` : ' / Puppeteer同梱Chromium');
    r.mermaid = { ok: /<svg[\s>]/.test(svg), detail: '描画OK（' + via + '）' };
  } catch (e) {
    r.mermaid = { ok: false, detail: (e.detail || e.message || '不明なエラー').slice(0, 4000),
      hint: chrome ? `検出済みブラウザ(${chrome})でも失敗。エラー全文を共有してください。`
                   : 'Chrome/Edge が見つかりません。Google Chrome か Microsoft Edge を入れると直ることが多いです。' };
  }
  return r;
}

/** 図ツール(mmdc)をバックグラウンドで先読み（起動時に1回）。npx のパッケージ取得や Chromium 起動を
 *  ユーザーが待つ前に済ませておく＝「初回の図描画だけ1分近く固まる」体験をなくす。非ブロッキング・失敗は無視。 */
let _warmed = false;
export function warmupMermaid(log = () => {}) {
  if (_warmed) return; _warmed = true;
  try {
    const base = join(tmpdir(), `marp-warm-${process.pid}`);
    const inPath = base + '.mmd', outPath = base + '.svg';
    writeFileSync(inPath, 'flowchart LR\n  A-->B');
    log('Mermaid: 図ツールを準備しています（初回のみ・バックグラウンド）…');
    exec(`${mmdcCmd()} -i "${inPath}" -o "${outPath}" -b transparent`, { env: mmdcEnv() }, (err) => {
      try { rmSync(inPath, { force: true }); } catch {}
      try { rmSync(outPath, { force: true }); } catch {}
      log(err ? 'Mermaid: 図ツールの先読みに失敗（保存時に通常どおり実行します）' : 'Mermaid: 図ツールの準備が完了しました');
    });
  } catch { /* 先読み失敗は無視（本番の描画時に通常フローで実行） */ }
}

/** doc-map（プロジェクト管理ドキュメントの関係図）を「正本1枚」から各デッキへ配布。
 *  正本: <decksRoot>/_common/doc-map.mmd（中立・ハイライト無し）
 *  各デッキ .md の `<!-- doc-id: X -->` を読み、ノード X を緑ハイライトした
 *  <deck>/assets/doc-map.mmd を生成（SVG化は export に委譲＝自己完結を維持）。
 *  deckMd を渡せばその1本、渡さなければ decksRoot 配下の全デッキを同期。 */
export function syncDocMap({ deckMd = null, decksRoot = null, log = console.log } = {}) {
  const root = decksRoot ? resolve(decksRoot) : (deckMd ? dirname(dirname(resolve(deckMd))) : null);
  if (!root) throw new Error('usage: docmap <デッキ.md>  または  docmap --all <decksフォルダ>');
  const canonical = join(root, '_common', 'doc-map.mmd');
  if (!existsSync(canonical)) throw new Error(`正本が見つかりません: ${canonical}`);
  const base = readFileSync(canonical, 'utf8').replace(/\s+$/, '');

  const decks = deckMd
    ? [resolve(deckMd)]
    : readdirSync(root)
        .filter((n) => !n.startsWith('_') && !n.startsWith('.'))
        .map((n) => join(root, n, `${n}.md`))
        .filter((p) => existsSync(p));

  let done = 0, warned = 0;
  for (const md of decks) {
    const m = readFileSync(md, 'utf8').match(/<!--\s*doc-id:\s*([A-Za-z0-9_-]+)\s*-->/);
    if (!m) { log(`WARN: doc-id 未宣言（スキップ）: ${md}`); warned++; continue; }
    const id = m[1];
    if (!new RegExp(`(^|\\n)\\s*${id}\\b`).test(base)) {
      log(`WARN: doc-id "${id}" が正本に存在しない（スキップ）: ${md}`); warned++; continue;
    }
    const deckDir = dirname(md);
    mkdirSync(join(deckDir, 'assets'), { recursive: true });
    const outMmd = join(deckDir, 'assets', 'doc-map.mmd');
    writeFileSync(outMmd, `${base}\n  class ${id} this;\n`);
    log(`OK: ${outMmd}  (doc-id=${id})`);
    done++;
  }
  return { done, warned };
}

/* ----------------------------- CLI（直接実行時のみ） ----------------------------- */
function die(msg) { console.error('ERROR: ' + msg); process.exit(1); }
const isMain = process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href;
const [sub, ...rest] = isMain ? process.argv.slice(2) : [false];
if (!isMain) {
  // import 時はCLIを実行しない（studio から関数だけ使う）
} else if (sub === 'new') {
  const [targetDir, title, subtitle] = rest;
  if (!targetDir || !title) die('usage: new <作成先フォルダ> "タイトル" ["サブタイトル"]');
  try {
    const { mdPath } = createDeck({ targetDir, title, subtitle });
    console.log(`OK: created ${mdPath}`);
    console.log(`  PDF出力: node ${process.argv[1]} export "${mdPath}"`);
  } catch (e) { die(e.message); }
} else if (sub === 'export') {
  const [mdArg] = rest;
  if (!mdArg) die('usage: export <デッキ.md>');
  try {
    const { out } = exportDeck(mdArg);
    console.log(`OK: ${out}`);
  } catch (e) { die(e.message); }
} else if (sub === 'docmap') {
  const [arg, arg2] = rest;
  try {
    let r;
    if (arg === '--all') r = syncDocMap({ decksRoot: arg2 || '.' });
    else if (arg) r = syncDocMap({ deckMd: arg });
    else die('usage: docmap <デッキ.md>  |  docmap --all <decksフォルダ>');
    console.log(`OK: ${r.done} デッキ更新 / ${r.warned} 警告`);
    console.log('  ※ doc-map.svg は export 時に生成されます');
  } catch (e) { die(e.message); }
} else if (sub === undefined) {
  console.log('marp-deck.mjs — デッキ雛形生成/エクスポート');
  console.log('  node marp-deck.mjs new <フォルダ> "タイトル" ["サブタイトル"]');
  console.log('  node marp-deck.mjs export <デッキ.md>');
  console.log('  node marp-deck.mjs docmap <デッキ.md> | --all <decksフォルダ>');
} else {
  die(`unknown command: ${sub}`);
}
