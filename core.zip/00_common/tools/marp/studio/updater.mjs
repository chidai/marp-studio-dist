/* ================================================================
 * updater.mjs — Marp Studio のアプリ内アップデータ（チェック/取得/退避）
 *
 * 役割: 「更新を確認」が押されたときだけ外部（or ローカルdir）の配布元を見に行き、
 *   新しいコンポーネントを取得して staging に展開し、pending.json を書く。
 *   実際の入れ替えは次回起動時に apply-update.mjs（00_common の外）が行う。
 *
 * 設計の肝:
 *   - 重い処理（HTTP/zip展開）はここ（00_common 内＝更新可能）に集約。
 *     apply（00_common 自身の置換）だけは外（apply-update.mjs）に置く。
 *   - 到達不可・拒否(403/HTML/404)・タイムアウトは「権利なし/オフライン」として
 *     黙ってスキップ。throw しない＝UI も起動も壊さない。
 *   - 無依存: zip 展開は zlib.inflateRawSync で自前（make-dist が自前で書くのと対称）。
 *
 * コンポーネント:
 *   - core    : クリーンな 00_common 一式（zip 内は `00_common/...`）。applies=core（全置換）。
 *   - theme-* : テナント別オーバーレイ（zip 内は `00_common/assets/...`）。applies=overlay（重ね置き）。
 *
 * 配布元(source): マニフェストの所在（https の URL or ローカル/UNC パス）。
 *   .marp-studio.json の update.sources に順序付き配列で持つ。
 *   到達可能なソースを順に読み、コンポーネント id ごとに「最初に見つかったソース」を採用
 *   （＝冗長/ミラー。ミラーは同一 version を載せる前提）。
 * ================================================================ */
import { readFileSync, writeFileSync, existsSync, mkdirSync, rmSync, readdirSync, statSync } from 'node:fs';
import { join, dirname, basename, isAbsolute } from 'node:path';
import { inflateRawSync } from 'node:zlib';
import { createHash } from 'node:crypto';

const STATE_DIRNAME = '.marp-studio';            // インストールルート直下の状態フォルダ
const DEFAULT_TIMEOUT_MS = 8000;

// ---- 設定読み込み ----------------------------------------------------------
// server.mjs が既に読んだ CONFIG（.marp-studio.json）を渡す。update セクションが無ければ無効。
export function loadUpdateConfig(config, installRoot) {
  const u = config && config.update;
  const sources = Array.isArray(u?.sources) ? u.sources.filter((s) => typeof s === 'string' && s.trim()) : [];
  // テーマ等の「不透明ID → 表示名」対応表（公開manifestに顧客名を載せないため、名前はここで補完）。
  const labels = (u && typeof u.labels === 'object' && u.labels) || {};
  // ドロップフォルダ（テーマ本体zipを手で置く/Box Drive同期で置く所定の場所）。既定はインストール直下。
  const dropRaw = (u && typeof u.dropDir === 'string' && u.dropDir) || 'theme-update-drop';
  const dropDir = installRoot ? (isAbsolute(dropRaw) ? dropRaw : join(installRoot, dropRaw)) : dropRaw;
  return {
    enabled: !!(u && u.enabled !== false && sources.length),
    sources, labels, dropDir,
    timeoutMs: Number(u?.timeoutMs) > 0 ? Number(u.timeoutMs) : DEFAULT_TIMEOUT_MS,
  };
}

// ---- 状態フォルダ（versions / staging / backup） ---------------------------
export function stateDir(installRoot) { return join(installRoot, STATE_DIRNAME); }
export function readVersions(installRoot) {
  const p = join(stateDir(installRoot), 'versions.json');
  try { return JSON.parse(readFileSync(p, 'utf8')); } catch { return {}; }
}
function pendingPath(installRoot) { return join(stateDir(installRoot), 'staging', 'pending.json'); }
export function readPending(installRoot) {
  try { return JSON.parse(readFileSync(pendingPath(installRoot), 'utf8')); } catch { return null; }
}
export function hasBackup(installRoot) {
  return existsSync(join(stateDir(installRoot), 'backup', '00_common'));
}

// ---- source の種別判定とマニフェスト取得 -----------------------------------
const isUrl = (s) => /^https?:\/\//i.test(s);
// URL/パスの「親（ディレクトリ）」を返す。相対 file 解決の基点に使う。
function parentLocator(loc) {
  if (isUrl(loc)) { const u = new URL(loc); u.pathname = u.pathname.replace(/[^/]*$/, ''); u.search = ''; return u.toString(); }
  return dirname(loc);
}
// マニフェストの file エントリを絶対 URL or 絶対パスへ解決。
function resolveFileLocator(base, file) {
  if (isUrl(file)) return file;                         // 絶対URL（Box直リン等）はそのまま
  if (!isUrl(base) && /^([a-zA-Z]:[\\/]|[\\/])/.test(file)) return file;  // 絶対パス
  if (isUrl(base)) return new URL(file, base).toString();
  return join(base, file);
}

// fetch（URL）/ readFile（ローカル）を共通化。失敗は null（黙ってスキップ）。
async function getBytes(loc, timeoutMs) {
  try {
    if (isUrl(loc)) {
      const ac = new AbortController();
      const t = setTimeout(() => ac.abort(), timeoutMs);
      try {
        const r = await fetch(loc, { signal: ac.signal, redirect: 'follow', cache: 'no-store' });
        if (!r.ok) return null;                          // 403/404 等＝権利なし/不在
        return Buffer.from(await r.arrayBuffer());
      } finally { clearTimeout(t); }
    }
    if (!existsSync(loc) || !statSync(loc).isFile()) return null;
    return readFileSync(loc);
  } catch { return null; }                               // タイムアウト/ネット不通/HTML等
}

async function fetchManifest(source, timeoutMs) {
  const buf = await getBytes(source, timeoutMs);
  if (!buf) return null;
  try {
    const m = JSON.parse(buf.toString('utf8'));          // 拒否HTMLは JSON.parse で弾かれる
    if (!m || !Array.isArray(m.components)) return null;
    return { ...m, _base: parentLocator(source) };
  } catch { return null; }
}

// 全ソースをマージ。コンポーネント id ごとに「最初に見つかったソース」を採用（冗長/ミラー）。
// 戻り: { reachableCount, comps: Map<id,{id,label,version,applies,locator}> }
async function resolveLatest(sources, timeoutMs) {
  const comps = new Map();
  let reachableCount = 0;
  for (const src of sources) {
    const man = await fetchManifest(src, timeoutMs);
    if (!man) continue;                                  // 到達不可/拒否はスキップ
    reachableCount++;
    for (const c of man.components) {
      if (!c || !c.id || comps.has(c.id)) continue;
      // delivery: 'http'=manifestのfileを取得 / 'drop'=本体は公開せず固定フォルダから（sha256照合）。
      const delivery = c.delivery === 'drop' ? 'drop' : 'http';
      if (delivery === 'http' && !c.file) continue;        // http なのに所在が無い＝無効
      comps.set(c.id, {
        id: c.id, label: c.label || '', version: String(c.version || ''),
        applies: (c.applies === 'core' || c.applies === 'core-safe') ? c.applies : 'overlay',   // core-safe は素通し（新apply-updateが解釈／旧updaterは未知→overlayに倒す＝安全）
        delivery,
        sha256: typeof c.sha256 === 'string' ? c.sha256.toLowerCase() : null,
        obtainFrom: typeof c.obtainFrom === 'string' ? c.obtainFrom : '',   // 人がブラウザで開く取得元（任意）
        changelog: Array.isArray(c.changelog) ? c.changelog : [],   // 新しい順の累積履歴
        locator: delivery === 'http' ? resolveFileLocator(man._base, c.file) : null,
      });
    }
  }
  return { reachableCount, comps };
}

// ---- zip 展開（無依存・central directory 走査 → inflateRawSync） -----------
function* iterZipEntries(buf) {
  // End of Central Directory を末尾から探す
  let eocd = -1;
  for (let i = buf.length - 22; i >= 0 && i >= buf.length - 22 - 65536; i--) {
    if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd < 0) throw new Error('zip: EOCD が見つかりません');
  let off = buf.readUInt32LE(eocd + 16);                 // central directory 開始オフセット
  const count = buf.readUInt16LE(eocd + 10);
  for (let n = 0; n < count; n++) {
    if (buf.readUInt32LE(off) !== 0x02014b50) throw new Error('zip: central header 不正');
    const method = buf.readUInt16LE(off + 10);
    const compSize = buf.readUInt32LE(off + 20);
    const nameLen = buf.readUInt16LE(off + 28);
    const extraLen = buf.readUInt16LE(off + 30);
    const cmtLen = buf.readUInt16LE(off + 32);
    const lhOff = buf.readUInt32LE(off + 42);
    const name = buf.slice(off + 46, off + 46 + nameLen).toString('utf8');
    // ローカルヘッダから実データ位置を算出（name/extra 長はローカル側を使う）
    if (buf.readUInt32LE(lhOff) !== 0x04034b50) throw new Error('zip: local header 不正');
    const lhNameLen = buf.readUInt16LE(lhOff + 26);
    const lhExtraLen = buf.readUInt16LE(lhOff + 28);
    const dataStart = lhOff + 30 + lhNameLen + lhExtraLen;
    const comp = buf.slice(dataStart, dataStart + compSize);
    yield { name, method, comp };
    off += 46 + nameLen + extraLen + cmtLen;
  }
}

// zip バッファを destDir に展開（パス越境は拒否）。
function extractZip(buf, destDir) {
  mkdirSync(destDir, { recursive: true });
  for (const ent of iterZipEntries(buf)) {
    if (ent.name.endsWith('/')) continue;                // ディレクトリエントリ
    const norm = ent.name.replace(/\\/g, '/');
    if (norm.split('/').some((seg) => seg === '..')) throw new Error('zip: 不正なパス ' + ent.name);
    const out = join(destDir, norm);
    if (out !== destDir && !out.startsWith(destDir + (process.platform === 'win32' ? '\\' : '/')) && !out.startsWith(destDir + '/'))
      throw new Error('zip: パス越境 ' + ent.name);
    const data = ent.method === 0 ? ent.comp : inflateRawSync(ent.comp);
    mkdirSync(dirname(out), { recursive: true });
    writeFileSync(out, data);
  }
}

// 版の同一判定は「ハッシュ（コミット識別子）」で行う＝日付だけ違っても再DLしない。
// 版文字列は "日付 (ハッシュ[-dirty])"。括弧内があればそれを、無ければ全体をキーにする。
function verKey(v) { const m = String(v).match(/\(([^)]+)\)/); return m ? m[1].trim() : String(v).trim(); }

// 導入版より新しい changelog エントリだけ切り出す（複数リリースをまたいでも間が全部見える）。
// changelog は新しい順。導入版に一致する位置より上（=新しい側）を返す。
// 導入版が配列に無い（古すぎ/未導入）＝全件を上限付きで返し、truncated を立てる。
const CHANGELOG_MAX = 30;
function sliceChangelog(changelog, installedVersion) {
  if (!Array.isArray(changelog) || !changelog.length) return { entries: [], truncated: false };
  let idx = installedVersion ? changelog.findIndex((e) => e && e.version === installedVersion) : -1;
  const fresh = idx >= 0 ? changelog.slice(0, idx) : changelog.slice();
  const truncated = fresh.length > CHANGELOG_MAX;
  return { entries: fresh.slice(0, CHANGELOG_MAX), truncated };
}

// 導入済み版を解決（core は実行中の版を真実とする。versions.json が無くても判定できる）。
function installedVersions(installRoot, coreVersion) {
  const installed = readVersions(installRoot);
  if (coreVersion && !installed.core) installed.core = coreVersion;
  return installed;
}

const sha256 = (buf) => createHash('sha256').update(buf).digest('hex');
// ドロップフォルダの zip を sha256 で索引する（テーマ本体は名前ではなく内容ハッシュで照合する）。
// → 置くファイル名は何でもよく、ファイル名に顧客名を出す必要もない。
function indexDropDir(dropDir) {
  const map = new Map();   // sha256 -> filepath
  try {
    for (const f of readdirSync(dropDir)) {
      if (!f.toLowerCase().endsWith('.zip')) continue;
      const p = join(dropDir, f);
      try { if (statSync(p).isFile()) map.set(sha256(readFileSync(p)), p); } catch {}
    }
  } catch {}
  return map;
}
// 不透明ID → 表示名（ローカルの labels で補完。無ければ汎用名。公開manifestには顧客名を載せない）。
const labelOf = (id, c, labels) => labels[id] || c.label || (id.startsWith('theme-') ? `テーマ更新（${id.slice(6, 14)}）` : id);
const isZip = (b) => b && b.length >= 4 && b[0] === 0x50 && b[1] === 0x4b && b[2] === 0x03 && b[3] === 0x04;

// ---- 確認（中身を見るだけ・staging は作らない・外部接続あり） ----------------
// 戻り値: { reachable, found:[{id,label,applies,from,to,notes,notesTruncated}], message }
//   throw しない（全失敗でも reachable:false で返す）。ここでは zip を落とさない（manifest だけ見る）。
export async function checkUpdates({ installRoot, config, coreVersion }) {
  const cfg = loadUpdateConfig(config, installRoot);
  if (!cfg.enabled) return { reachable: false, found: [], message: '更新元が設定されていません' };
  const { reachableCount, comps } = await resolveLatest(cfg.sources, cfg.timeoutMs);
  if (reachableCount === 0) return { reachable: false, found: [], message: '更新元に接続できませんでした（オフライン等）' };

  const installed = installedVersions(installRoot, coreVersion);
  const drop = indexDropDir(cfg.dropDir);   // テーマ本体(drop)の照合用
  const found = [];
  for (const [id, c] of comps) {
    const cur = installed[id] || '';
    if (cur && verKey(cur) === verKey(c.version)) continue;   // 同一ハッシュ＝更新なし
    const cl = sliceChangelog(c.changelog, cur);
    const base = { id, label: labelOf(id, c, cfg.labels), applies: c.applies, delivery: c.delivery,
      from: cur || '(未導入)', to: c.version, notes: cl.entries, notesTruncated: cl.truncated };
    if (c.delivery === 'drop') {
      // 本体は公開しない。固定ドロップフォルダに該当zip(sha256一致)が置かれていれば適用可。
      const ready = !!(c.sha256 && drop.has(c.sha256));
      found.push({ ...base, ready, needsFile: !ready, dropDir: cfg.dropDir, obtainFrom: c.obtainFrom });
    } else {
      found.push({ ...base, ready: true });
    }
  }
  return { reachable: true, found, message: found.length ? '更新があります' : '最新です' };
}

// ---- 適用予約（選んだものだけ取得して staging に退避＝次回起動で適用） --------
// ids: 適用するコンポーネントid配列（未指定なら見つかった全部）。throw しない。
// 戻り値: { staged:[{id,label,to}], skipped:[id], message }
export async function stageUpdates({ installRoot, config, coreVersion, ids = null }) {
  const cfg = loadUpdateConfig(config, installRoot);
  if (!cfg.enabled) return { staged: [], skipped: [], message: '更新元が設定されていません' };
  const { reachableCount, comps } = await resolveLatest(cfg.sources, cfg.timeoutMs);
  if (reachableCount === 0) return { staged: [], skipped: [], message: '更新元に接続できませんでした（オフライン等）' };

  const installed = installedVersions(installRoot, coreVersion);
  const drop = indexDropDir(cfg.dropDir);
  const want = Array.isArray(ids) && ids.length ? new Set(ids) : null;   // null=新しいもの全部
  const stageRoot = join(stateDir(installRoot), 'staging');
  rmSync(stageRoot, { recursive: true, force: true });
  mkdirSync(stageRoot, { recursive: true });

  const staged = [], items = [], skipped = [];
  for (const [id, c] of comps) {
    const cur = installed[id] || '';
    if (cur && verKey(cur) === verKey(c.version)) continue;     // 更新なし
    if (want && !want.has(id)) continue;                        // 選ばれていない＝適用しない
    let buf = null;
    if (c.delivery === 'drop') {
      const p = c.sha256 && drop.get(c.sha256);                 // 本体は固定フォルダから（内容ハッシュ照合）
      if (p) buf = readFileSync(p);                             // 未配置/不一致なら buf=null
    } else {
      buf = await getBytes(c.locator, cfg.timeoutMs);           // http 取得
      if (buf && c.sha256 && sha256(buf) !== c.sha256) buf = null;   // 整合性検証（sha256指定時）
    }
    if (!isZip(buf)) { skipped.push(id); continue; }            // 未配置・拒否・改竄・非zip → スキップ
    try { extractZip(buf, join(stageRoot, id)); }
    catch { rmSync(join(stageRoot, id), { recursive: true, force: true }); skipped.push(id); continue; }
    const label = labelOf(id, c, cfg.labels);
    staged.push({ id, label, to: c.version });
    items.push({ id, label, applies: c.applies, from: cur || '', to: c.version, notes: sliceChangelog(c.changelog, cur).entries });
  }

  if (!items.length) {
    rmSync(stageRoot, { recursive: true, force: true });
    return { staged: [], skipped, message: skipped.length ? '取得できませんでした' : '適用対象がありません' };
  }
  items.sort((a, b) => (a.applies === 'core' ? -1 : 0) - (b.applies === 'core' ? -1 : 0));   // core を先に
  writeFileSync(join(stageRoot, 'pending.json'),
    JSON.stringify({ type: 'update', at: new Date().toISOString(), items }, null, 2) + '\n', 'utf8');
  return { staged, skipped, message: '次回起動時に適用されます' };
}

// ロールバック指示書を書く（次回起動で apply-update が backup を戻す）。
export function stageRollback(installRoot) {
  if (!hasBackup(installRoot)) return { ok: false, message: '戻せる版（バックアップ）がありません' };
  const stageRoot = join(stateDir(installRoot), 'staging');
  rmSync(stageRoot, { recursive: true, force: true });
  mkdirSync(stageRoot, { recursive: true });
  writeFileSync(join(stageRoot, 'pending.json'),
    JSON.stringify({ type: 'rollback', at: new Date().toISOString() }, null, 2) + '\n', 'utf8');
  return { ok: true, message: '次回起動時に前の版へ戻します' };
}

// 取り消し（適用前に staging を捨てる）。
export function clearStaging(installRoot) {
  rmSync(join(stateDir(installRoot), 'staging'), { recursive: true, force: true });
}
