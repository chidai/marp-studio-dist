#!/usr/bin/env node
/* ================================================================
 * Marp Studio — ブラウザだけで完結するローカルWeb GUI（コマンド操作不要）
 *
 * ねらい: ターミナル操作もVSCodeも不要で、ブラウザだけでデッキを
 *   作る → 編集（左:テキスト / 右:ライブプレビュー）→ PDF作成、まで完結。
 *
 * 起動: ランチャー（start-studio.command / .bat）をダブルクリック、または
 *   node 00_common/tools/marp/studio/server.mjs
 *   → ブラウザで http://localhost:4321 が開く
 *
 * 依存: Node のみ（描画/出力は同梱エンジン marp-deck.mjs 経由で marp CLI を使用）。
 * デッキ置き場: <リポジトリルート>/decks/ 配下（自動作成）。
 * ================================================================ */
import { createServer } from 'node:http';
import { readFileSync, writeFileSync, existsSync, mkdirSync, readdirSync, statSync, renameSync, rmSync } from 'node:fs';
import { resolve, dirname, join, extname, normalize, basename, relative, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { exec, execSync } from 'node:child_process';
import { createDeck, exportDeck, findThemeDir, checkEnvironment, warmupMermaid, loadBrand, mermaidCodeToSvg } from '../marp-deck.mjs';
import { exportPptx, isPptxReady } from '../pptx-export.mjs';
import { checkUpdates, stageUpdates, stageRollback, clearStaging, readVersions, readPending, hasBackup, loadUpdateConfig } from './updater.mjs';

const themeDir = findThemeDir(process.cwd()) || findThemeDir(dirname(fileURLToPath(import.meta.url)));
if (!themeDir) { console.error('00_common/assets/marp が見つかりません。リポジトリ配下で実行してください。'); process.exit(1); }
const REPO_ROOT = resolve(themeDir, '..', '..', '..');         // リポジトリのルート（00_common の親）
// primary ルート＝ランチャが STUDIO_ROOT で指定する decks/（新規作成・/api/new はここに作る）
const PRIMARY_ROOT = process.env.STUDIO_ROOT ? resolve(process.env.STUDIO_ROOT) : join(REPO_ROOT, 'decks');
const DECKS_ROOT = PRIMARY_ROOT;   // 後方互換 alias（既存参照を壊さない）
mkdirSync(PRIMARY_ROOT, { recursive: true });

// バージョン（不具合調査の起点）。版＝どのコミットかを特定できるよう「日付 (短縮gitハッシュ[-dirty])」にする。
//   - リポジトリで実行時: 起動時に git から自動算出（未コミットがあれば -dirty）。
//   - 配布版（.git なし）: make-dist が STAMPED_VERSION にビルド時の値を刻印 → それを使う。
// 同じ日に複数版を作っても区別でき、版から git のコミットを直接たどれる。
const STAMPED_VERSION = '2026.07.06 (d82e5a7)';   // ← make-dist が配布時に 'YYYY.MM.DD (hash)' へ置換する
function resolveVersion() {
  try {
    const hash = execSync('git rev-parse --short HEAD', { cwd: REPO_ROOT, stdio: 'pipe' }).toString().trim();
    if (hash) {
      let dirty = '';
      // dirty は配布物に入る MarpStudio 関連パスに限定（無関係な他ファイルの未コミットで -dirty にしない）。make-dist と同じ方針。
      // guides も配布物に入る（ガイド＋生成AI規約 AGENTS.md 等の原本）＝未コミットは版数に反映する。
      try { if (execSync('git status --porcelain --untracked-files=no -- 00_common/tools/marp 00_common/assets/marp 00_common/guides', { cwd: REPO_ROOT, stdio: 'pipe' }).toString().trim()) dirty = '-dirty'; } catch {}
      const d = new Date(), p = (n) => String(n).padStart(2, '0');
      return `${d.getFullYear()}.${p(d.getMonth() + 1)}.${p(d.getDate())} (${hash}${dirty})`;
    }
  } catch { /* git不可（配布版など）→ 刻印値にフォールバック */ }
  return STAMPED_VERSION;
}
const STUDIO_VERSION = resolveVersion();
// アップデータの状態（.marp-studio/versions・staging・backup）はインストールルート＝00_commonの親に置く。
// 配布版では zipルート（apply-update.mjs と同じ場所）。リポ開発時は update 未設定なので inert。
const INSTALL_ROOT = REPO_ROOT;
// 開発元（git作業ツリー）判定：配布物は .git を含まない＝自動更新の対象。
// 開発元は git で最新化する対象＝自動更新の対象外（apply-update が 00_common を上書きするのを避ける）。
const IS_DEV_ROOT = existsSync(join(INSTALL_ROOT, '.git'));
const PORT = Number(process.env.STUDIO_PORT || 4321);

// 待ち受けの自動停止（ブラウザのXで閉じてポートがオーファン化するのを防ぐ）。
// 各画面が IDLE_PING_MS ごとに /api/ping を打つ。最後の ping から IDLE_EXIT_MS を超えたら終了。
// 一度でも ping を受けるまでは終了しない（起動直後/手動URL貼り付け待ちで誤終了しないため）。
// 無 ping がこの時間続いたら終了。短すぎると「別ウィンドウへ切替・小休止・スリープ等で
// ping が一時的に途切れただけ」でも落ちてしまう（ブラウザは非アクティブタブのタイマを間引く）。
// オーファン掃除は数分遅れても実害がないため、誤終了を避けて長め(3分)にする。
const IDLE_EXIT_MS = 180000;
const NO_AUTOEXIT = /^(1|true|yes)$/i.test(process.env.STUDIO_NO_AUTOEXIT || '');  // テスト/確認用に自動停止を無効化
let lastBeatAt = Date.now();
let everPinged = false;

const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css', '.js': 'text/javascript',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif',
  '.svg': 'image/svg+xml', '.pdf': 'application/pdf', '.json': 'application/json' };

// 置き場所に依存しないよう themeDir（=00_common/assets/marp）基点で算出する
const COMMON_ROOT = resolve(themeDir, '..', '..');           // .../00_common（ビューアで開ける範囲）
const GUIDES_DIR = join(COMMON_ROOT, 'guides', 'marp');      // .../guides/marp（ガイドMD置き場）
const safeName = (s) => String(s || '').replace(/[^\p{L}\p{N}_\-]/gu, '_').slice(0, 60);
// ================= 監視ルートとデッキ索引（複数フォルダ・枝刈り再帰） =================
const CONFIG_FILENAME = '.marp-studio.json';
const PRUNE_DIRS = new Set(['out', '.git', 'node_modules', '_assets', '.trash']);
const DEFAULT_DEPTH = 4;

// プロジェクト直下（PRIMARY_ROOTの親）から上方3階層で設定ファイルを探す。無ければ null（=後方互換）。
function loadConfig() {
  const dirs = [resolve(PRIMARY_ROOT, '..'), resolve(PRIMARY_ROOT, '..', '..'), resolve(PRIMARY_ROOT, '..', '..', '..')];
  for (const dir of dirs) {
    const p = join(dir, CONFIG_FILENAME);
    if (existsSync(p)) {
      try {
        const raw = JSON.parse(readFileSync(p, 'utf8'));
        console.log(`Marp Studio: 設定ファイルを読み込みました → ${p}`);
        return { ...raw, _configDir: dir };
      } catch (e) {
        console.warn(`Marp Studio: 設定ファイルの読み込みに失敗（無視して続行）: ${p}\n  ${e.message}`);
        return null;
      }
    }
  }
  return null;
}

// 監視ルート配列を確定。先頭=primary固定、設定の roots を絶対化して追加（重複absPathは排除）。
function buildRootList(config) {
  const list = [{ label: basename(PRIMARY_ROOT), path: PRIMARY_ROOT, isPrimary: true }];
  const seen = new Set([PRIMARY_ROOT]);
  for (const r of (config?.roots ?? [])) {
    try {
      const abs = resolve(config._configDir || REPO_ROOT, r.path);
      if (abs === PRIMARY_ROOT) { if (r.label) list[0].label = r.label; continue; }
      if (seen.has(abs)) continue;
      seen.add(abs);
      list.push({ label: r.label || basename(abs), path: abs, isPrimary: false });
    } catch {}
  }
  return list;
}

// デッキ判定: <dir>/<dirname>.md を優先、無ければ README.md 以外の *.md が1つだけならそれ（引き継ぎ用）。なければ null。
// README.md のみのフォルダ（章の索引フォルダ等）はデッキ扱いしない＝誤検出防止。
function deckMdInDir(absDir) {
  const pref = join(absDir, `${basename(absDir)}.md`);
  if (existsSync(pref)) return pref;
  try {
    const mds = readdirSync(absDir).filter((f) => f.toLowerCase().endsWith('.md') && f.toLowerCase() !== 'readme.md');
    if (mds.length === 1) return join(absDir, mds[0]);
  } catch {}
  return null;
}

// 1ルートを枝刈り再帰。デッキと判定したら配下には潜らない。out に {absDir, mdPath} を push。
function walkDecks(rootPath, maxDepth, excludes, out) {
  const extra = new Set(excludes || []);
  const walk = (dir, depth) => {
    if (depth > maxDepth) return;
    let entries; try { entries = readdirSync(dir, { withFileTypes: true }); } catch { return; }
    for (const ent of entries) {
      const nm = ent.name;
      if (nm.startsWith('.') || PRUNE_DIRS.has(nm) || extra.has(nm)) continue;
      if (!ent.isDirectory()) continue;
      const absDir = join(dir, nm);
      const md = deckMdInDir(absDir);
      if (md) out.push({ absDir, mdPath: md });        // デッキ確定→配下には潜らない
      else walk(absDir, depth + 1);
    }
  };
  walk(rootPath, 1);
}

// deck id 生成。primary(rootIndex=0) の depth1 は「フォルダ名そのまま」＝既存URL互換。
function makeDeckId(rootIndex, relPath) {
  const parts = relPath.split(/[\\/]/);
  if (rootIndex === 0 && parts.length === 1) return parts[0];
  return rootIndex + ':' + parts.join(':');
}

// 全ルートを走査して索引 Map<id, DeckEntry> を構築。
function scanRoots(rootList, depth, excludes) {
  const index = new Map();
  rootList.forEach((root, rootIndex) => {
    if (!existsSync(root.path)) return;
    const found = [];
    walkDecks(root.path, depth, excludes, found);
    for (const f of found) {
      const relPath = relative(root.path, f.absDir).normalize('NFC');
      const id = makeDeckId(rootIndex, relPath);
      if (index.has(id)) continue;                     // 衝突は先勝ち
      index.set(id, { id, absDir: f.absDir, mdPath: f.mdPath, rootLabel: root.label, rootPath: root.path, relPath, name: basename(f.absDir), rootIndex });
    }
  });
  return index;
}

// 共有テーマCSS（00_common/assets/marp/*.css）の最新更新時刻。テーマを直すと全プレビューを再ビルドさせる。
function themeCssMaxMtime() {
  let m = 0;
  try {
    for (const f of readdirSync(themeDir)) {
      if (!f.toLowerCase().endsWith('.css')) continue;
      try { const t = statSync(join(themeDir, f)).mtimeMs; if (t > m) m = t; } catch {}
    }
  } catch {}
  return m;
}

// プレビューの鮮度（execSyncを呼ばず mtime のみ）。md/assets/共有テーマ が preview より新しい or preview不在 → stale。
// themeMtime を渡すと themeCssMaxMtime() を都度呼ばない（一覧で全デッキ分を1回算出に）。
function checkFreshness(mdPath, absDir, previewPath, themeMtime = null) {
  try {
    if (!existsSync(previewPath)) return { fresh: false };
    const pm = statSync(previewPath).mtimeMs;
    if (statSync(mdPath).mtimeMs > pm) return { fresh: false };
    const tm = themeMtime == null ? themeCssMaxMtime() : themeMtime;
    if (tm > pm) return { fresh: false };   // 共有テーマCSSの変更も検知（顧客テーマ差し替え等）
    const assetsDir = join(absDir, 'assets');
    if (existsSync(assetsDir)) {
      for (const f of readdirSync(assetsDir)) {
        try { const fp = join(assetsDir, f); if (statSync(fp).isFile() && statSync(fp).mtimeMs > pm) return { fresh: false }; } catch {}
      }
    }
    return { fresh: true };
  } catch { return { fresh: false }; }
}

let CONFIG = loadConfig();
// scanDepth を正とし、旧配布物が書いた depth も後方互換で読む（既に配った depth 版の救済）。
let SCAN_DEPTH = Number(CONFIG?.scanDepth ?? CONFIG?.depth) > 0 ? Number(CONFIG.scanDepth ?? CONFIG.depth) : DEFAULT_DEPTH;
let ROOT_LIST = buildRootList(CONFIG);
let DECK_INDEX = scanRoots(ROOT_LIST, SCAN_DEPTH, CONFIG?.excludes);
console.log(`Marp Studio: ${DECK_INDEX.size} デッキを索引しました（${ROOT_LIST.length} ルート, 深さ${SCAN_DEPTH}）`);

// 索引を再構築（再走査ボタン / 新規・改名・削除後）。depth指定があれば深さを更新。
function rescanIndex(depth) {
  if (depth && Number(depth) > 0) SCAN_DEPTH = Number(depth);
  ROOT_LIST = buildRootList(CONFIG);
  DECK_INDEX = scanRoots(ROOT_LIST, SCAN_DEPTH, CONFIG?.excludes);
  return DECK_INDEX;
}

// 既存デッキの参照用: パス越境を弾き、Unicode正規化(NFC)した id を索引で解決。見つからなければ null。
// ※ safeName は「新規作成時の名前生成」専用（既存名の照合には使わない）。
function resolveDeck(deck) {
  const raw = String(deck || '');
  if (!raw || /[\\/\0]/.test(raw) || raw === '.' || raw === '..') return null;
  const want = raw.normalize('NFC');
  return DECK_INDEX.has(want) ? want : null;
}
function deckDir(id) { return DECK_INDEX.get(id)?.absDir ?? null; }
// デッキ本体MDのパス（索引引き）。索引未登録時のみ従来フォールバック（PRIMARY_ROOT直下）。
function deckMd(id) {
  const e = DECK_INDEX.get(id);
  if (e) return e.mdPath;
  const dir = join(PRIMARY_ROOT, id);
  const pref = join(dir, `${id}.md`);
  if (existsSync(pref)) return pref;
  try { const md = readdirSync(dir).find((f) => f.toLowerCase().endsWith('.md')); if (md) return join(dir, md); } catch {}
  return pref;
}
// 本文のスライド枚数（先頭frontmatterを除き、`---` 区切り＋1）
function countPages(src) {
  const s = src.replace(/\r\n/g, '\n').replace(/^---\n[\s\S]*?\n---\n/, '');
  return (s.match(/^---$/gm) || []).length + 1;
}
// 頁数キャッシュ（mdPath→{mtime,pages}）。mtimeが変わらなければ md を読み直さない。
const PAGES_CACHE = new Map();
function cachedPages(mdPath, mtimeMs) {
  const c = PAGES_CACHE.get(mdPath);
  if (c && c.mtime === mtimeMs) return c.pages;
  const pages = countPages(readFileSync(mdPath, 'utf8'));
  PAGES_CACHE.set(mdPath, { mtime: mtimeMs, pages });
  return pages;
}
// デッキが採用しているテーマ（frontmatter の theme:）。mtimeでキャッシュ。
const THEME_CACHE = new Map();
function cachedTheme(mdPath, mtimeMs) {
  const c = THEME_CACHE.get(mdPath);
  if (c && c.mtime === mtimeMs) return c.theme;
  const m = readFileSync(mdPath, 'utf8').slice(0, 2000).match(/^theme:\s*(.+)$/m);
  const theme = m ? m[1].trim() : 'base';
  THEME_CACHE.set(mdPath, { mtime: mtimeMs, theme });
  return theme;
}
// デッキの論理名＝本文先頭の H1（`# タイトル`）。共有git配下はフォルダ名がASCIIのため、
// 一覧では日本語タイトルをホバー表示・検索対象にする。mtimeでキャッシュ。
const TITLE_CACHE = new Map();
function cachedTitle(mdPath, mtimeMs) {
  const c = TITLE_CACHE.get(mdPath);
  if (c && c.mtime === mtimeMs) return c.title;
  const m = readFileSync(mdPath, 'utf8').slice(0, 4000).match(/^#\s+(.+?)\s*$/m);
  const title = m ? m[1].trim() : '';
  TITLE_CACHE.set(mdPath, { mtime: mtimeMs, title });
  return title;
}
// デッキ一覧（索引から・更新日の新しい順）。場所・鮮度などのメタを付与。
function listDecks() {
  const out = [];
  const themeMtime = themeCssMaxMtime();   // 全デッキ共通＝1回だけ算出（旧: デッキ毎に算出）
  for (const [id, e] of DECK_INDEX) {
    try {
      if (!existsSync(e.mdPath)) continue;
      const st = statSync(e.mdPath);
      const previewPath = join(e.absDir, '.preview.html');
      out.push({
        id, name: e.name,
        title: cachedTitle(e.mdPath, st.mtimeMs),
        pages: cachedPages(e.mdPath, st.mtimeMs),
        theme: cachedTheme(e.mdPath, st.mtimeMs),
        created: st.birthtime, updated: st.mtime,
        rootLabel: e.rootLabel, rootPath: e.rootPath, relPath: e.relPath,
        isPrimary: e.rootIndex === 0,
        needsBuild: !checkFreshness(e.mdPath, e.absDir, previewPath, themeMtime).fresh,
      });
    } catch {}
  }
  out.sort((a, b) => new Date(b.updated) - new Date(a.updated));
  return out;
}
// marp/ 内のテーマ名一覧（/* @theme x */ を抽出）。
// 並びは決定的にする（readdirSync 任せだと毎回変わって探しにくい）。
// この dist/リポの既定テーマ（.marp-studio.json の brand.defaultTheme）を先頭、次に base、
// 残りを名前順。先頭が既定＝編集画面のドロップダウンは theme: 未指定デッキで既定を自動選択する。
function listThemes() {
  try {
    const names = readdirSync(themeDir).filter((f) => f.toLowerCase().endsWith('.css')).map((f) => {
      const m = readFileSync(join(themeDir, f), 'utf8').slice(0, 2000).match(/@theme\s+([A-Za-z0-9_-]+)/);
      return m ? m[1] : null;
    }).filter(Boolean);
    let def = 'base';
    try { def = loadBrand(PRIMARY_ROOT).defaultTheme || 'base'; } catch {}
    const rank = (t) => (t === def ? 0 : t === 'base' ? 1 : 2);
    return names.sort((a, b) => rank(a) - rank(b) || a.localeCompare(b, 'en'));
  } catch { return []; }
}

function send(res, code, body, type = 'text/html; charset=utf-8') {
  res.writeHead(code, { 'Content-Type': type }); res.end(body);
}
function readBody(req) {
  return new Promise((r) => { let b = ''; req.on('data', (c) => (b += c)); req.on('end', () => r(b)); });
}
function readBodyBuffer(req) {
  return new Promise((r) => { const cs = []; req.on('data', (c) => cs.push(c)); req.on('end', () => r(Buffer.concat(cs))); });
}
// デッキ直下の静的ファイル配信（プレビューHTML・assets・out/PDF）。パス越境を禁止。
// .preview.html は配信前に鮮度チェックし、stale（md/assets が新しい/不在）なら再ビルドしてから返す。
function serveDeckFile(res, id, rel) {
  const e = DECK_INDEX.get(id);
  if (!e) return send(res, 404, 'not found', 'text/plain');
  const base = e.absDir;
  const p = normalize(join(base, rel));
  if (p !== base && !p.startsWith(base + sep)) return send(res, 403, 'forbidden', 'text/plain');
  if (basename(p) === '.preview.html' && !checkFreshness(e.mdPath, base, p).fresh) {
    buildPreview(id);   // 同期。fresh ならスキップ済みなので呼ばれない
  }
  if (!existsSync(p) || !statSync(p).isFile()) return send(res, 404, 'not found', 'text/plain');
  const mime = MIME[extname(p).toLowerCase()] || 'application/octet-stream';
  // 発表(preview)HTMLは marp 生成物で favicon を持たない → 本体と別の発表用faviconを <head> に注入して区別。
  if (basename(p) === '.preview.html') {
    let html = readFileSync(p, 'utf8');
    if (!/rel=["']icon["']/i.test(html)) html = html.replace(/<head([^>]*)>/i, `<head$1>${FAVICON_PRESENT}`);
    res.writeHead(200, { 'Content-Type': mime });
    return res.end(html);
  }
  res.writeHead(200, { 'Content-Type': mime });
  res.end(readFileSync(p));
}

// ディレクトリ配下の合計バイト数（.trash の容量表示用）。失敗は 0 扱い。
function dirBytes(p) {
  let total = 0;
  try {
    const st = statSync(p);
    if (st.isDirectory()) { for (const n of readdirSync(p)) total += dirBytes(join(p, n)); }
    else total += st.size;
  } catch {}
  return total;
}

const server = createServer(async (req, res) => {
  const url = new URL(req.url, `http://localhost:${PORT}`);
  const path = decodeURIComponent(url.pathname);
  try {
    if (path === '/' && req.method === 'GET') {
      let cust = '';
      try { cust = loadBrand(PRIMARY_ROOT).customer || ''; } catch {}
      const proj = cust ? '（' + esc(cust) + '）' : '';   // .marp-studio.json の brand.customer（顧客ラベル・製品/社内版は空）
      return send(res, 200, PAGE_HOME.replace('{{DECKS}}', DECKS_ROOT).replace('{{PROJECT}}', proj));
    }
    if (path === '/edit' && req.method === 'GET') return send(res, 200, PAGE_EDIT);

    if (path === '/api/decks' && req.method === 'GET') {
      const depth = url.searchParams.get('depth');
      const rescan = url.searchParams.get('rescan');
      if (depth || rescan) rescanIndex(depth);   // depth指定は暗黙rescan
      return send(res, 200, JSON.stringify(listDecks()), MIME['.json']);
    }

    if (path === '/api/themes' && req.method === 'GET')
      return send(res, 200, JSON.stringify(listThemes()), MIME['.json']);

    // 環境セルフチェック（Node/marp/mermaid が実際に動くか）。「一人だけ図が出ない」の原因切り分け用。
    // PPTX(β)部品の取得状況も併記（未取得はエラーではない＝初回作成時に自動取得する旨を示す）。
    if (path === '/api/selfcheck' && req.method === 'GET') {
      try {
        const r = checkEnvironment();
        const ready = isPptxReady();
        r.pptx = { ok: true, detail: ready ? 'PPTX(β)変換部品は取得済み' : '未取得。初回に「PPTX (β)」を押すと自動取得します（要ネット接続）' };
        return send(res, 200, JSON.stringify(r), MIME['.json']);
      } catch (e) { return send(res, 200, JSON.stringify({ error: e.message }), MIME['.json']); }
    }

    // バージョン情報（本体＋導入済みコンポーネント＋適用待ち／ロールバック可否）。
    if (path === '/api/version' && req.method === 'GET') {
      const installed = readVersions(INSTALL_ROOT);
      const pending = readPending(INSTALL_ROOT);
      const cfg = loadUpdateConfig(CONFIG, INSTALL_ROOT);
      return send(res, 200, JSON.stringify({
        core: STUDIO_VERSION,
        installed,
        updateEnabled: cfg.enabled,
        devRoot: IS_DEV_ROOT,
        canRollback: hasBackup(INSTALL_ROOT),
        pending: pending ? { type: pending.type, items: (pending.items || []).map((i) => ({ id: i.id, label: i.label, to: i.to })) } : null,
      }), MIME['.json']);
    }

    // 更新を確認（手動・中身を見るだけ）。外部/ローカルソースに接続し、新版と変更内容を返す。
    // ここでは staging を作らない＝「見たけど適用しない」が選べる。失敗・オフラインでも throw しない。
    if (path === '/api/update/check' && req.method === 'POST') {
      try {
        const r = await checkUpdates({ installRoot: INSTALL_ROOT, config: CONFIG, coreVersion: STUDIO_VERSION });
        return send(res, 200, JSON.stringify(r), MIME['.json']);
      } catch (e) {
        return send(res, 200, JSON.stringify({ reachable: false, found: [], message: '確認に失敗しました: ' + e.message }), MIME['.json']);
      }
    }

    // 選んだ更新を「次回起動時に適用」する＝取得して staging に退避（ここで初めてDL）。
    // body: { ids: [...] }（省略時は新しいもの全部）。適用は次回起動時（apply-update.mjs）。
    if (path === '/api/update/apply' && req.method === 'POST') {
      try {
        const { ids } = JSON.parse(await readBody(req) || '{}');
        const r = await stageUpdates({ installRoot: INSTALL_ROOT, config: CONFIG, coreVersion: STUDIO_VERSION, ids: Array.isArray(ids) ? ids : null });
        return send(res, 200, JSON.stringify(r), MIME['.json']);
      } catch (e) {
        return send(res, 200, JSON.stringify({ staged: [], skipped: [], message: '取得に失敗しました: ' + e.message }), MIME['.json']);
      }
    }

    // 適用予約の取り消し（staging を捨てる＝次回起動で何もしない）。
    if (path === '/api/update/cancel' && req.method === 'POST') {
      clearStaging(INSTALL_ROOT);
      return send(res, 200, JSON.stringify({ ok: true, message: '適用予約を取り消しました' }), MIME['.json']);
    }

    // 前の版へ戻す指示（次回起動時に適用）。
    if (path === '/api/update/rollback' && req.method === 'POST') {
      return send(res, 200, JSON.stringify(stageRollback(INSTALL_ROOT)), MIME['.json']);
    }

    // 各画面からの生存通知（ハートビート）。最後の ping 時刻を更新するだけ。
    if (path === '/api/ping' && req.method === 'POST') {
      lastBeatAt = Date.now();
      everPinged = true;
      return send(res, 200, JSON.stringify({ ok: true }), MIME['.json']);
    }

    // Web画面からの終了。応答を返してからプロセスを落とす（保存済みデッキは残る）
    if (path === '/api/shutdown' && req.method === 'POST') {
      send(res, 200, JSON.stringify({ ok: true }), MIME['.json']);
      console.log('Web画面から終了が指示されました。Marp Studio を終了します。');
      setTimeout(() => process.exit(0), 200);
      return;
    }

    if (path === '/api/new' && req.method === 'POST') {
      const { title, subtitle } = JSON.parse(await readBody(req) || '{}');
      const name = safeName(title);
      if (!name) return send(res, 400, JSON.stringify({ error: 'タイトルを入力してください' }), MIME['.json']);
      if (existsSync(join(PRIMARY_ROOT, name))) return send(res, 409, JSON.stringify({ error: '同名のデッキが既にあります' }), MIME['.json']);
      createDeck({ targetDir: join(PRIMARY_ROOT, name), title, subtitle });
      rescanIndex();          // 新デッキを索引へ（id==name: primary直下）
      buildPreview(name);
      return send(res, 200, JSON.stringify({ name, id: name }), MIME['.json']);
    }

    if (path === '/api/md' && req.method === 'GET') {
      const name = resolveDeck(url.searchParams.get('deck'));
      if (!name || !existsSync(deckMd(name))) return send(res, 404, JSON.stringify({ error: 'not found' }), MIME['.json']);
      return send(res, 200, JSON.stringify({ content: readFileSync(deckMd(name), 'utf8') }), MIME['.json']);
    }

    // svg参照に対応する Mermaid ソース(.mmd)を返す（スライド複製時に図を編集可能なフェンスへ戻す用）。
    // 同じ場所に <同名>.mmd がある時だけ返す（drawio等の .mmd 不在は404＝画像のまま）。
    if (path === '/api/mmd-src' && req.method === 'GET') {
      const id = resolveDeck(url.searchParams.get('deck'));
      const e = id && DECK_INDEX.get(id);
      if (!e) return send(res, 404, JSON.stringify({ error: 'deck not found' }), MIME['.json']);
      const rel = url.searchParams.get('path') || '';
      if (!rel || rel.includes('..') || rel.includes('\0') || !/\.svg$/i.test(rel))
        return send(res, 400, JSON.stringify({ error: 'bad path' }), MIME['.json']);
      const svgAbs = normalize(join(e.absDir, rel));
      if (svgAbs !== e.absDir && !svgAbs.startsWith(e.absDir + sep))
        return send(res, 403, JSON.stringify({ error: 'forbidden' }), MIME['.json']);
      const mmdAbs = svgAbs.replace(/\.svg$/i, '.mmd');
      // doc-map は docmap コマンドで再生成する正本由来の図。手編集向けに戻さない（複製時の対象外）。
      if (basename(mmdAbs).toLowerCase() === 'doc-map.mmd')
        return send(res, 404, JSON.stringify({ error: 'excluded' }), MIME['.json']);
      if (!existsSync(mmdAbs) || !statSync(mmdAbs).isFile())
        return send(res, 404, JSON.stringify({ error: 'no mmd' }), MIME['.json']);
      return send(res, 200, JSON.stringify({ mmd: readFileSync(mmdAbs, 'utf8') }), MIME['.json']);
    }

    if (path === '/api/save' && req.method === 'POST') {
      const { deck, content } = JSON.parse(await readBody(req) || '{}');
      const name = resolveDeck(deck);
      if (!name || !existsSync(deckMd(name))) return send(res, 404, JSON.stringify({ error: 'not found' }), MIME['.json']);
      writeFileSync(deckMd(name), String(content ?? ''));
      const r = buildPreview(name);
      return send(res, 200, JSON.stringify(r), MIME['.json']);
    }

    // プレビューだけ別テーマ等で再生成（デッキ.md は書き換えない＝gitを汚さない）。
    if (path === '/api/preview' && req.method === 'POST') {
      const { deck, content } = JSON.parse(await readBody(req) || '{}');
      const name = resolveDeck(deck);
      if (!name || !existsSync(deckMd(name))) return send(res, 404, JSON.stringify({ error: 'not found' }), MIME['.json']);
      return send(res, 200, JSON.stringify(buildPreviewFrom(name, content)), MIME['.json']);
    }

    if (path === '/api/export' && req.method === 'POST') {
      const { deck } = JSON.parse(await readBody(req) || '{}');
      const id = resolveDeck(deck);
      const e = id && DECK_INDEX.get(id);
      if (!e || !existsSync(e.mdPath)) return send(res, 404, JSON.stringify({ error: 'not found' }), MIME['.json']);
      try {
        exportDeck(e.mdPath, { fmt: 'pdf', log: () => {} });   // out/<stem>.pdf に出力
        const stem = basename(e.mdPath, '.md');
        return send(res, 200, JSON.stringify({ url: `/deck/${encodeURIComponent(id)}/out/${encodeURIComponent(stem)}.pdf` }), MIME['.json']);
      } catch (err) { return send(res, 500, JSON.stringify({ error: 'PDF作成に失敗: ' + err.message }), MIME['.json']); }
    }

    // PPTX(β)出力。初回は pptxgenjs を自動取得（要ネット）→ out/<stem>.pptx を生成。
    if (path === '/api/export-pptx' && req.method === 'POST') {
      const { deck } = JSON.parse(await readBody(req) || '{}');
      const id = resolveDeck(deck);
      const e = id && DECK_INDEX.get(id);
      if (!e || !existsSync(e.mdPath)) return send(res, 404, JSON.stringify({ error: 'not found' }), MIME['.json']);
      try {
        await exportPptx(e.mdPath, { log: () => {} });
        const stem = basename(e.mdPath, '.md');
        return send(res, 200, JSON.stringify({ url: `/deck/${encodeURIComponent(id)}/out/${encodeURIComponent(stem)}.pptx` }), MIME['.json']);
      } catch (err) { return send(res, 500, JSON.stringify({ error: 'PPTX作成に失敗: ' + err.message }), MIME['.json']); }
    }

    if (path === '/api/rename' && req.method === 'POST') {
      const { deck, newName } = JSON.parse(await readBody(req) || '{}');
      const oldId = resolveDeck(deck);
      const e = oldId && DECK_INDEX.get(oldId);
      if (!e) return send(res, 404, JSON.stringify({ error: 'not found' }), MIME['.json']);
      // 名前変更は個人decks(primary)直下のデッキのみ（共有ルート/ネストは不可）
      if (e.rootIndex !== 0 || e.relPath.split(/[\\/]/).length !== 1)
        return send(res, 403, JSON.stringify({ error: 'このデッキは名前変更できません（個人decks直下のみ可）' }), MIME['.json']);
      const newN = safeName(newName);
      if (!newN) return send(res, 400, JSON.stringify({ error: '新しい名前を入力してください' }), MIME['.json']);
      if (newN.normalize('NFC') === e.name.normalize('NFC')) return send(res, 200, JSON.stringify({ name: e.name, id: e.name }), MIME['.json']);
      if (existsSync(join(PRIMARY_ROOT, newN)) || DECK_INDEX.has(newN)) return send(res, 409, JSON.stringify({ error: '同名のデッキが既にあります' }), MIME['.json']);
      const mdName = basename(e.mdPath);                     // 引き継ぎデッキ対応（実在のMD名）
      renameSync(e.absDir, join(PRIMARY_ROOT, newN));
      const innerOld = join(PRIMARY_ROOT, newN, mdName);
      if (existsSync(innerOld)) renameSync(innerOld, join(PRIMARY_ROOT, newN, `${newN}.md`));
      try { rmSync(join(PRIMARY_ROOT, newN, '.preview.html'), { force: true }); } catch {}
      try { rmSync(join(PRIMARY_ROOT, newN, 'out'), { recursive: true, force: true }); } catch {}
      rescanIndex();
      buildPreview(newN);
      return send(res, 200, JSON.stringify({ name: newN, id: newN }), MIME['.json']);
    }

    if (path === '/api/delete' && req.method === 'POST') {
      const { deck } = JSON.parse(await readBody(req) || '{}');
      const id = resolveDeck(deck);
      const e = id && DECK_INDEX.get(id);
      if (!e) return send(res, 404, JSON.stringify({ error: 'not found' }), MIME['.json']);
      // 共有ルートのデッキはここから消さない（gitで操作する）。個人decks(primary)のみ可。
      if (e.rootIndex !== 0) return send(res, 403, JSON.stringify({ error: '共有ルートのデッキはここから削除できません（gitで操作）' }), MIME['.json']);
      // すぐ消さず .trash へ退避（復元可能）
      const trash = join(e.rootPath, '.trash'); mkdirSync(trash, { recursive: true });
      const stamp = new Date().toISOString().replace(/[:.]/g, '-');
      renameSync(e.absDir, join(trash, e.name + '__' + stamp));
      rescanIndex();
      return send(res, 200, JSON.stringify({ ok: true }), MIME['.json']);
    }

    // ゴミ箱(.trash)の件数・総容量。削除は個人decks(primary)限定なので primary の .trash だけ見る。
    if (path === '/api/trash' && req.method === 'GET') {
      const trash = join(PRIMARY_ROOT, '.trash');
      let count = 0, bytes = 0;
      if (existsSync(trash)) {
        const entries = readdirSync(trash);
        count = entries.length;
        for (const n of entries) bytes += dirBytes(join(trash, n));
      }
      return send(res, 200, JSON.stringify({ count, bytes }), MIME['.json']);
    }
    // ゴミ箱を空にする（.trash 内の各エントリを完全削除。元に戻せない）。
    if (path === '/api/trash/empty' && req.method === 'POST') {
      const trash = join(PRIMARY_ROOT, '.trash');
      let removed = 0;
      if (existsSync(trash)) {
        for (const n of readdirSync(trash)) { rmSync(join(trash, n), { recursive: true, force: true }); removed++; }
      }
      return send(res, 200, JSON.stringify({ ok: true, removed }), MIME['.json']);
    }

    if (path === '/api/guides' && req.method === 'GET') {
      // `_dev-*.md` は開発元(.git あり)のみ表示。配布物には元々含まれない（make-dist が除外）。
      const files = readdirSync(GUIDES_DIR).filter((f) => f.toLowerCase().endsWith('.md') && (IS_DEV_ROOT || !f.startsWith('_dev-')));
      // 読む順: README(案内) → かんたん版 → 詳細版 → その他
      // 並び順: README(案内)→かんたん版→詳細版→その他(9)→開発元用 _dev-(20 で最下部)。同順は名前順。
      const rank = (f) => f === 'README.md' ? 0 : f === 'Marp-Studioの使い方.md' ? 1 : f === 'Markdown_Marpプレゼン作成ガイド.md' ? 2 : f.startsWith('_dev-') ? 20 : 9;
      files.sort((a, b) => rank(a) - rank(b) || a.localeCompare(b));
      return send(res, 200, JSON.stringify(files), MIME['.json']);
    }
    if (path === '/guide' && req.method === 'GET') {
      const f = url.searchParams.get('file') || '';
      const p = normalize(join(GUIDES_DIR, f));   // file は guides/marp 基点（../でassets等も可）
      if (!p.startsWith(COMMON_ROOT) || !p.toLowerCase().endsWith('.md') || !existsSync(p))
        return send(res, 404, 'not found', 'text/plain');
      _viewerBase = dirname(p);                   // このファイルのディレクトリを相対解決の基点に
      return send(res, 200, guidePage(basename(p), mdToHtml(readFileSync(p, 'utf8'))));
    }
    // 00_common 配下の非mdファイル（PDF・画像等）を配信（ビューアのリンク先）
    const cm = path.match(/^\/common\/(.+)$/);
    if (cm && req.method === 'GET') {
      const fp = normalize(join(COMMON_ROOT, cm[1]));
      if (!fp.startsWith(COMMON_ROOT) || !existsSync(fp) || !statSync(fp).isFile())
        return send(res, 404, 'not found', 'text/plain');
      res.writeHead(200, { 'Content-Type': MIME[extname(fp).toLowerCase()] || 'application/octet-stream' });
      return res.end(readFileSync(fp));
    }

    if (path === '/api/upload' && req.method === 'POST') {
      const id = resolveDeck(url.searchParams.get('deck'));
      const de = id && DECK_INDEX.get(id);
      if (!de) return send(res, 404, JSON.stringify({ error: 'deck not found' }), MIME['.json']);
      // ファイル名は安全化しつつ拡張子を保持
      const raw = url.searchParams.get('name') || 'image.png';
      const ext = (extname(raw) || '.png').toLowerCase();
      const stem = safeName(raw.slice(0, raw.length - extname(raw).length)) || 'image';
      const assetsDir = join(de.absDir, 'assets');
      mkdirSync(assetsDir, { recursive: true });
      let fname = `${stem}${ext}`, i = 1;
      while (existsSync(join(assetsDir, fname))) fname = `${stem}_${i++}${ext}`;
      const buf = await readBodyBuffer(req);
      writeFileSync(join(assetsDir, fname), buf);
      return send(res, 200, JSON.stringify({ file: `assets/${fname}` }), MIME['.json']);
    }

    const m = path.match(/^\/deck\/([^/]+)\/(.+)$/);
    if (m && req.method === 'GET') {
      const dn = resolveDeck(m[1]);
      if (!dn) return send(res, 404, 'not found', 'text/plain');
      return serveDeckFile(res, dn, m[2]);
    }

    return send(res, 404, 'not found', 'text/plain');
  } catch (e) {
    return send(res, 500, JSON.stringify({ error: e.message }), MIME['.json']);
  }
});

// プレビューHTMLをデッキ直下に生成（assets/ 相対が解決できる位置）。{ok}/{ok:false,error} を返す。
function buildPreview(id) {
  const e = DECK_INDEX.get(id);
  if (!e) return { ok: false, error: 'deck not found' };
  try {
    const r = exportDeck(e.mdPath, { fmt: 'html', outPath: join(e.absDir, '.preview.html'), log: () => {} });
    return { ok: true, preview: `/deck/${encodeURIComponent(id)}/.preview.html`, mermaidErrors: r.mermaidErrors || [] };
  } catch (err) {
    return { ok: false, error: err.message };
  }
}

// テーマ比較用：与えられた本文(content)から一時 md を作って .preview.html を生成するが、
// デッキ本体(.md)は一切書き換えない＝「プレビューだけ別テーマ」を git を汚さずに行う経路。
function buildPreviewFrom(id, content) {
  const e = DECK_INDEX.get(id);
  if (!e) return { ok: false, error: 'deck not found' };
  const tmp = join(e.absDir, '.' + basename(e.mdPath, '.md') + '.preview-src.tmp.md');
  try {
    writeFileSync(tmp, String(content ?? ''));
    // fast=true: 自動プレビューは未キャッシュの重い図(mmdc)を描かない＝軽い修正は即時、図は保存時に描画。
    const r = exportDeck(tmp, { fmt: 'html', outPath: join(e.absDir, '.preview.html'), log: () => {}, fast: true });
    return { ok: true, preview: `/deck/${encodeURIComponent(id)}/.preview.html`, mermaidErrors: r.mermaidErrors || [], mermaidDeferred: (r.mermaidDeferred || []).length };
  } catch (err) {
    return { ok: false, error: err.message };
  } finally {
    try { rmSync(tmp, { force: true }); } catch {}
  }
}

// ポートが使用中なら自動で次の番号へ（最大10個試す）
function start(port, triesLeft) {
  server.removeAllListeners('error');
  server.removeAllListeners('listening');
  server.once('error', (e) => {
    if (e.code === 'EADDRINUSE' && triesLeft > 0) {
      console.log(`ポート ${port} は使用中。${port + 1} を試します…`);
      start(port + 1, triesLeft - 1);
    } else {
      console.error('起動に失敗しました:', e.message);
      process.exit(1);
    }
  });
  server.once('listening', () => {
    const p = server.address().port;      // 実際にバインドできたポート
    const u = `http://localhost:${p}`;
    console.log(`Marp Studio v${STUDIO_VERSION} を起動しました → ${u}   (decks: ${DECKS_ROOT})`);
    console.log('ブラウザが自動で開きます。開かない場合は上のURLをブラウザに貼ってください。');
    console.log('────────────────────────────────────────────');
    console.log('■ 終了するには:  Webページ右上の「■ 終了」ボタン');
    console.log(`                  または、この画面で ${process.platform === 'win32' ? 'Ctrl+C' : 'Control+C（Ctrl+C）'} を押す／このウィンドウを閉じる`);
    console.log('────────────────────────────────────────────');
    const opener = process.platform === 'darwin' ? 'open' : process.platform === 'win32' ? 'start ""' : 'xdg-open';
    exec(`${opener} ${u}`, () => {});
    warmupMermaid(console.log);   // 図ツール(mmdc)を裏で先読み＝初回の図描画の長い待ちを減らす

    // 待ち受けの自動停止監視。全画面が閉じる（=ping が途絶える）と IDLE_EXIT_MS 後に終了。
    // スリープ復帰時も lastBeatAt が古くなるため終了し、画面側は「終了しています」を表示する。
    // テスト/動作確認で人が画面を開いただけで落とされないよう、STUDIO_NO_AUTOEXIT=1 で無効化できる。
    if (NO_AUTOEXIT) {
      console.log('（自動停止は無効です: STUDIO_NO_AUTOEXIT。終了は「■ 終了」ボタンか Ctrl+C で）');
    } else {
      setInterval(() => {
        if (everPinged && Date.now() - lastBeatAt > IDLE_EXIT_MS) {
          console.log('すべての画面が閉じられたため、Marp Studio を終了します。');
          process.exit(0);
        }
      }, 5000).unref();
    }
  });
  server.listen(port);
}
start(PORT, 10);

/* -------- 簡易 Markdown → HTML（ガイド表示用・依存なし） -------- */
function esc(s){return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}
let _viewerBase = COMMON_ROOT;   // /guide が「表示中ファイルのディレクトリ」を設定（相対リンク解決の基点）
// 表示時だけリンクを書き換える（ソースMDは通常の相対リンクのまま＝Finder/VSCode/GitHubでも有効）
function link(text, href){
  if (/^(https?:|#|mailto:)/.test(href)) return '<a href="'+href+'" target="_blank">'+text+'</a>';
  const hashless = href.replace(/#.*$/, '');
  if (!hashless || href.endsWith('/')) return text;                 // フォルダ等はリンク化しない
  let abs; try { abs = normalize(join(_viewerBase, hashless)); } catch { return text; }
  if (!abs.startsWith(COMMON_ROOT) || !existsSync(abs)) return text; // 範囲外/未存在→ただの文字
  if (abs.toLowerCase().endsWith('.md'))                            // .md はビューアで開く
    return '<a href="/guide?file='+encodeURIComponent(relative(GUIDES_DIR, abs))+'">'+text+'</a>';
  const rel = relative(COMMON_ROOT, abs).split('/').map(encodeURIComponent).join('/'); // それ以外は静的配信
  return '<a href="/common/'+rel+'" target="_blank">'+text+'</a>';
}
function inline(s){return esc(s)
  .replace(/`([^`]+)`/g,'<code>$1</code>')
  .replace(/\*\*([^*]+)\*\*/g,'<strong>$1</strong>')
  .replace(/\[([^\]]+)\]\(([^)]+)\)/g, (m, text, href) => link(text, href));}
// ガイド内の ```mermaid をサーバ側でSVG化して埋め込む（ビューアは簡易表示なので画像/CDN不要。既存mmdc流用・オフライン可）。
// コード内容でキャッシュ（初回のみmmdc起動）。失敗時はコードブロックにフォールバック。
const _mmSvgCache = new Map();
function mermaidToInlineSvg(code){
  if(_mmSvgCache.has(code)) return _mmSvgCache.get(code);
  let html;
  try { html = '<div class="mmd">' + mermaidCodeToSvg(code) + '</div>'; }
  catch(e){ html = '<pre><code>' + esc(code) + '</code></pre>'; }
  _mmSvgCache.set(code, html);
  return html;
}
function mdToHtml(src){
  const L=src.replace(/\r\n/g,'\n').split('\n'); let o='',i=0;
  const isBlock=(s)=>/^(#{1,6}\s|>|\||```|\s*[-*]\s|\s*\d+\.\s)/.test(s)||/^---+\s*$/.test(s);
  while(i<L.length){ let l=L[i];
    if(/^```/.test(l)){ const lang=(l.match(/^```\s*([A-Za-z0-9_-]+)/)||[])[1]||''; let c=''; i++; while(i<L.length&&!/^```/.test(L[i])){c+=L[i]+'\n';i++;} i++; o += lang.toLowerCase()==='mermaid' ? mermaidToInlineSvg(c) : '<pre><code>'+esc(c)+'</code></pre>'; continue; }
    if(/^\s*$/.test(l)){i++;continue;}
    if(/^---+\s*$/.test(l)){o+='<hr>';i++;continue;}
    const h=l.match(/^(#{1,6})\s+(.*)$/); if(h){const n=h[1].length;o+='<h'+n+'>'+inline(h[2])+'</h'+n+'>';i++;continue;}
    if(/^>\s?/.test(l)){let q='';while(i<L.length&&/^>\s?/.test(L[i])){q+=L[i].replace(/^>\s?/,'')+'\n';i++;}o+='<blockquote>'+mdToHtml(q)+'</blockquote>';continue;}
    if(/^\|.*\|/.test(l)&&i+1<L.length&&/^\|[\s:\-|]+\|/.test(L[i+1])){
      const cells=(r)=>r.replace(/^\||\|$/g,'').split('|').map((c)=>c.trim());
      const head=cells(l); i+=2; let b='';
      while(i<L.length&&/^\|.*\|/.test(L[i])){b+='<tr>'+cells(L[i]).map((c)=>'<td>'+inline(c)+'</td>').join('')+'</tr>';i++;}
      o+='<table><thead><tr>'+head.map((c)=>'<th>'+inline(c)+'</th>').join('')+'</tr></thead><tbody>'+b+'</tbody></table>'; continue; }
    if(/^\s*[-*]\s+/.test(l)){let it='';while(i<L.length&&/^\s*[-*]\s+/.test(L[i])){it+='<li>'+inline(L[i].replace(/^\s*[-*]\s+/,''))+'</li>';i++;}o+='<ul>'+it+'</ul>';continue;}
    if(/^\s*\d+\.\s+/.test(l)){let it='';while(i<L.length&&/^\s*\d+\.\s+/.test(L[i])){it+='<li>'+inline(L[i].replace(/^\s*\d+\.\s+/,''))+'</li>';i++;}o+='<ol>'+it+'</ol>';continue;}
    let p=l; i++; while(i<L.length&&!/^\s*$/.test(L[i])&&!isBlock(L[i])){p+=' '+L[i];i++;}
    o+='<p>'+inline(p)+'</p>';
  } return o;
}
function guidePage(title, body){
  return '<!doctype html><html lang="ja"><head><meta charset="utf-8"><title>'+esc(title)+' — ガイド</title>'+FAVICON+STYLE+
   '<style>.doc{max-width:900px;margin:24px auto;padding:0 20px;line-height:1.7}'+
   '.doc h1{font-size:24px}.doc h2{font-size:19px;border-bottom:1px solid var(--line);padding-bottom:4px;margin-top:28px}.doc h3{font-size:16px}'+
   '.doc table{border-collapse:collapse;width:100%;margin:12px 0}.doc th,.doc td{border:1px solid var(--line);padding:6px 8px;text-align:left}.doc th{background:#edf5ff}'+
   '.doc pre{background:#f4f4f4;padding:12px;border-radius:6px;overflow:auto}.doc code{background:#f4f4f4;padding:1px 4px;border-radius:3px}.doc pre code{background:none;padding:0}'+
   '.doc blockquote{border-left:4px solid var(--ibm);background:#f7fbff;margin:10px 0;padding:8px 12px}.doc hr{border:0;border-top:1px solid var(--line);margin:20px 0}'+
   '.doc .mmd{margin:14px 0;overflow:auto}.doc .mmd svg{max-width:100%;height:auto}</style></head>'+
   '<body><header><h1>Marp Studio</h1><span class="ver">v'+STUDIO_VERSION+'</span><span class="sub">ガイド: '+esc(title)+'</span><span style="flex:1"></span><a href="/">← 一覧へ</a></header>'+
   '<div class="doc">'+body+'</div></body></html>';
}

/* ----------------------------- UI ----------------------------- */
const STYLE = `<style>
  :root{--ibm:#0F62FE;--ink:#161616;--gray:#6F6F6F;--line:#e0e0e0}
  *{box-sizing:border-box} body{font-family:'IBM Plex Sans JP','Hiragino Kaku Gothic ProN','Meiryo',sans-serif;color:var(--ink);margin:0;background:#f4f4f4}
  header{background:#fff;border-bottom:2px solid var(--ibm);padding:12px 20px;display:flex;align-items:center;gap:12px;flex-wrap:wrap;position:sticky;top:0;z-index:30}
  header a{margin-left:auto}
  header h1{font-size:18px;margin:0} header .sub{color:var(--gray);font-size:12px}
  header .ver{font-size:11px;color:var(--ibm);background:#edf5ff;border:1px solid #d0e2ff;border-radius:10px;padding:1px 8px;font-weight:600;align-self:center}
  .wrap{max-width:1100px;margin:24px auto;padding:0 20px}
  /* トップページ上段: 「新規作成」と「ヘルプ・ガイド」は横幅を食わないので2カラムで並べる（一覧は下に全幅） */
  .home-top{display:grid;grid-template-columns:1fr 1fr;gap:16px;align-items:start}
  @media(max-width:760px){.home-top{grid-template-columns:1fr}}
  .card{background:#fff;border:1px solid var(--line);border-radius:8px;padding:20px;margin-bottom:16px}
  .btn{background:var(--ibm);color:#fff;border:0;border-radius:4px;padding:10px 16px;font-size:14px;line-height:1.4;cursor:pointer}
  .btn:hover{background:#0a4fd6} .btn.sec{background:#fff;color:var(--ibm);border:1px solid var(--ibm)}
  .btn:disabled{background:#c6c6c6;cursor:wait}
  input,textarea{font-family:inherit;font-size:14px;border:1px solid #8d8d8d;border-radius:4px;padding:8px;width:100%}
  label{display:block;font-size:13px;color:var(--gray);margin:10px 0 4px}
  ul.decks{list-style:none;padding:0} ul.decks li{display:flex;justify-content:space-between;align-items:center;padding:10px 0;border-bottom:1px solid var(--line)}
  a{color:var(--ibm);text-decoration:none} a:hover{text-decoration:underline}
  .muted{color:var(--gray);font-size:13px}
  .btn.quit{background:#fff;color:#da1e28;border:1px solid #da1e28}
  .btn.quit:hover{background:#fff1f1}
  /* デッキ一覧（テーブル） */
  .toolbar2{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-bottom:12px}
  .toolbar2 select{padding:5px;border:1px solid var(--line);border-radius:4px;font-size:13px}
  .toolbar2 input[type=search]{width:220px}
  .deck-table{width:100%;border-collapse:collapse;font-size:13px}
  .deck-table th{text-align:left;padding:8px 10px;border-bottom:2px solid var(--line);white-space:nowrap;color:var(--gray);font-size:12px}
  .deck-table th.sortable{cursor:pointer} .deck-table th.sortable:hover{color:var(--ibm)}
  .deck-table td{padding:5px 10px;border-bottom:1px solid var(--line);vertical-align:middle}
  .deck-table td.deckname{line-height:1.2}
  .deck-table tbody tr:hover td{background:#f4f4f4}
  .deck-sub{display:block;font-size:11px;font-weight:400;color:#a0a0a0;line-height:1.15;max-width:340px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .badge{display:inline-block;padding:1px 6px;border-radius:10px;font-size:11px;font-weight:bold;margin-right:4px;white-space:nowrap}
  .badge.personal{background:#defbe6;color:#0e6027} .badge.shared{background:#edf5ff;color:#0043ce}
  .badge.stale{background:#fff8e1;color:#8a6100}
</style>`;

// タブのアイコン（favicon）。外部ファイルを増やさずSVGをdata URIで埋め込む＝自己完結を維持。
// IBM Carbon配色の角丸スクエアに、白いスライド（見出しバー＋本文行）とスタンドで「プレゼン」を表す。
const FAVICON_SVG = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#4589ff"/><stop offset="1" stop-color="#0043ce"/></linearGradient></defs>
<rect width="32" height="32" rx="7" fill="url(#g)"/>
<rect x="6.5" y="7.5" width="19" height="13" rx="2" fill="#fff"/>
<rect x="9" y="10" width="9" height="2.2" rx="1.1" fill="#0f62fe"/>
<rect x="9" y="13.8" width="14" height="1.6" rx=".8" fill="#a6c8ff"/>
<rect x="9" y="16.4" width="11.5" height="1.6" rx=".8" fill="#a6c8ff"/>
<rect x="14.5" y="20.5" width="3" height="3" fill="#fff"/>
<rect x="10.5" y="23.5" width="11" height="2.2" rx="1.1" fill="#fff"/>
</svg>`;
const FAVICON = `<link rel="icon" type="image/svg+xml" href="data:image/svg+xml;base64,${Buffer.from(FAVICON_SVG).toString('base64')}">`;

// 発表（preview）タブ用の別favicon。本体（青＋スライド）と混同しないよう、緑の角丸スクエアに
// 白い再生三角＝「発表＝再生中」を表す。serveDeckFile が .preview.html 配信時に <head> へ注入する。
const FAVICON_PRESENT_SVG = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
<defs><linearGradient id="gp" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#42be65"/><stop offset="1" stop-color="#0e6027"/></linearGradient></defs>
<rect width="32" height="32" rx="7" fill="url(#gp)"/>
<path d="M12.5 9 L23 16 L12.5 23 Z" fill="#fff"/>
</svg>`;
const FAVICON_PRESENT = `<link rel="icon" type="image/svg+xml" href="data:image/svg+xml;base64,${Buffer.from(FAVICON_PRESENT_SVG).toString('base64')}">`;

// ヘッダー右端の「終了」ボタンと、その動作（/api/shutdown を叩いて終了画面を出す）。
// 両ページで共通利用。QUIT_JS は既存の <script> 内に差し込む（要素生成後に実行される）。
const QUIT_BTN = '<button class="btn quit" id="quitBtn" title="Marp Studio を終了します" style="margin-left:8px">■ 終了</button>';
const QUIT_JS = `
(function(){
  var b=document.getElementById('quitBtn'); if(!b) return;
  b.onclick=async function(){
    var warn=(window.__beforeQuit ? window.__beforeQuit() : '');   // 編集画面では未保存があれば警告文を前置き
    if(!confirm(warn + 'Marp Studio を終了します。よろしいですか？\\n（作成済みのデッキはそのまま残ります）')) return;
    window.__stopBeat=true;   // 明示終了の案内画面を、ハートビートの「終了しています」で上書きしない
    b.disabled=true;
    try{ await fetch('/api/shutdown',{method:'POST'}); }catch(e){}
    document.body.innerHTML='<div class="wrap"><div class="card" style="text-align:center">'
      +'<h2 style="margin-top:0">Marp Studio を終了しました</h2>'
      +'<p class="muted">このタブ（ウィンドウ）は閉じて構いません。<br>'
      +'もう一度使うときは、起動用ファイル（<code>Marp-Studioを起動.command</code> / <code>.bat</code>）をダブルクリックしてください。</p>'
      +'</div></div>';
  };
})();`;

// 待ち受けの自動停止（クライアント側）。両ページの <script> 末尾に差し込む。
// IDLE_PING_MS ごとに /api/ping を打って生存を知らせ、サーバが落ちたら案内画面に切り替える。
// 画面遷移(編集↔一覧)やリロードでは新しいページが ping を再開するので途切れない。
const HEARTBEAT_JS = `
(function(){
  var FAILS_BEFORE_DOWN=3, fails=0, banner=null;
  // サーバ不応答を「画面下のバナー」で知らせる（body は差し替えない＝編集中テキストを失わない）。
  // 復活したら自動で消す。明示終了(■終了)中は出さない。
  function showDown(){
    if(banner || window.__stopBeat) return;
    banner=document.createElement('div');
    banner.style.cssText='position:fixed;left:0;right:0;bottom:0;z-index:9500;background:#fff3cd;border-top:2px solid #e0b400;'
      +'padding:10px 16px;font-size:13px;display:flex;align-items:center;gap:12px;box-shadow:0 -2px 10px rgba(0,0,0,.12)';
    // 編集画面(本文 textarea #src がある)と一覧画面でメッセージ・操作を出し分ける（両画面で同じ文言だと片方が嘘になるため）。
    var editing=document.getElementById('src');
    var msg = editing
      ? 'スリープ・長時間放置などでサーバが停止した可能性があります。編集中の本文は下の「本文をコピー」で退避できます（起動し直して貼り戻せます）。'
      : 'サーバが停止しています。「再接続を確認」で戻らない場合は Marp Studio を起動し直してください。';
    banner.innerHTML='<b>⚠ Marp Studio サーバが応答しません</b>'
      +'<span style="color:#6F6F6F">'+msg+'</span>'
      +'<span style="flex:1"></span>'
      +(editing?'<button id="__hbCopy" class="btn sec">本文をコピー</button>':'')
      +'<button id="__hbRetry" class="btn sec">再接続を確認</button>';
    document.body.appendChild(banner);
    document.getElementById('__hbRetry').onclick=beat;
    if(editing){
      // 実際に効くコピー退避。navigator.clipboard が使えない環境は prompt で手動コピーに退避。
      document.getElementById('__hbCopy').onclick=async function(e){
        var t=e.target, txt=document.getElementById('src').value;
        try{ await navigator.clipboard.writeText(txt); t.textContent='コピーしました'; setTimeout(function(){t.textContent='本文をコピー';},1500); }
        catch(_){ window.prompt('本文（Ctrl+C / Cmd+C で手動コピー）', txt); }
      };
    }
  }
  function hideDown(){ if(banner){ banner.remove(); banner=null; } }
  async function beat(){
    if(window.__stopBeat) return;   // 明示終了の最中は何もしない
    try{
      var r=await fetch('/api/ping',{method:'POST',cache:'no-store'});
      if(!r.ok) throw 0;
      fails=0; hideDown();          // 復活＝バナーを消す
    }catch(e){
      if(++fails>=FAILS_BEFORE_DOWN) showDown();
    }
  }
  beat();
  setInterval(beat, 5000);
  // 別ウィンドウから戻ったら即座に生存確認（間引かれた ping の取り戻し）。
  document.addEventListener('visibilitychange', function(){ if(!document.hidden) beat(); });
})();`;

const PAGE_HOME = `<!doctype html><html lang="ja"><head><meta charset="utf-8"><title>Marp Studio</title>${FAVICON}${STYLE}</head>
<body><header><h1>Marp Studio</h1><span class="ver" id="verBadge" title="バージョン情報・更新の確認" style="cursor:pointer">v${STUDIO_VERSION}</span><span class="sub">ブラウザだけでスライドを作る{{PROJECT}}</span><span style="flex:1"></span><button class="btn sec" id="updateBtn" title="新版の確認・バージョン情報（次回起動時に適用）">🔄 更新</button><button class="btn sec" id="selfcheckBtn" title="図が出ない等のトラブル診断（Node/Marp/Mermaidが動くか）">🩺 環境チェック</button>${QUIT_BTN}</header>
<div id="updModal" style="display:none;position:fixed;inset:0;z-index:9000;align-items:center;justify-content:center;background:rgba(22,22,22,.4)">
  <div style="background:#fff;border-radius:10px;max-width:680px;width:90%;max-height:82vh;overflow:auto;padding:20px 24px">
    <h2 style="margin:0 0 4px;font-size:18px">バージョン情報と更新</h2>
    <div id="updVersions" class="muted" style="margin:0 0 12px">読み込み中…</div>
    <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
      <button class="btn" id="updCheck" title="更新元を確認し、新しい版があれば取得します（適用は次回起動時）">🔄 更新を確認</button>
      <button class="btn sec" id="updRollback" style="display:none" title="直前の版に戻します（次回起動時に適用）">↩ 前の版に戻す</button>
      <span id="updMsg" class="muted" style="font-size:13px"></span>
    </div>
    <div id="updResult" style="margin-top:14px"></div>
    <p style="text-align:right;margin:14px 0 0"><button class="btn sec" id="updClose">閉じる</button></p>
  </div>
</div>
<div id="scModal" style="display:none;position:fixed;inset:0;z-index:9000;align-items:center;justify-content:center;background:rgba(22,22,22,.4)">
  <div style="background:#fff;border-radius:10px;max-width:680px;width:90%;max-height:80vh;overflow:auto;padding:20px 24px">
    <h2 style="margin:0 0 4px;font-size:18px">環境チェック</h2>
    <p class="muted" style="margin:0 0 12px">スライド作成に必要なツールが実際に動くか確認します（図が出ない時の原因切り分け用）。</p>
    <div id="scBody"><p class="muted">確認中…</p></div>
    <p style="text-align:right;margin:14px 0 0"><button class="btn" id="scClose">閉じる</button></p>
  </div>
</div>
<div class="wrap">
  <div class="home-top">
    <div class="card">
      <h2 style="margin-top:0;font-size:16px">新しいデッキ（スライド一式）を作る</h2>
      <label>タイトル（必須）</label><input id="title" placeholder="例: キックオフ会議">
      <label>サブタイトル（任意）</label><input id="subtitle" placeholder="例: 事前調査">
      <p><button class="btn" id="create">作成して編集へ</button> <span id="msg" class="muted"></span></p>
    </div>
    <div class="card">
      <h2 style="margin-top:0;font-size:16px">ヘルプ・ガイド</h2>
      <ul class="decks" id="guides"><li class="muted">読み込み中…</li></ul>
    </div>
  </div>
  <div class="card">
    <h2 style="margin-top:0;font-size:16px">デッキ（スライド一式）一覧</h2>
    <div class="toolbar2">
      <button class="btn sec" id="rescan" title="フォルダを再走査して一覧を最新化">🔄 再走査</button>
      <label class="muted">深さ <select id="depth"><option>2</option><option>3</option><option selected>4</option><option>6</option><option>8</option></select></label>
      <label class="muted">場所 <select id="rootFilter"><option value="">すべて</option></select></label>
      <input id="filter" type="search" placeholder="デッキ名・場所・テーマで絞り込み">
      <button class="btn sec" id="stealth" aria-pressed="false" title="検索した項目だけ表示（空欄では一覧を出しません。すべて出すには * ）" aria-label="検索した項目だけ表示" style="padding:6px 9px;line-height:1">🔍</button>
      <span id="cnt" class="muted" style="font-size:12px"></span>
      <span style="flex:1"></span>
      <span id="trashInfo" class="muted" style="font-size:12px"></span>
      <button class="btn sec" id="emptyTrash" style="display:none" title="ゴミ箱(.trash)の中身を完全に削除します（元に戻せません）">🗑 ゴミ箱を空にする</button>
    </div>
    <div style="overflow-x:auto">
      <table class="deck-table" id="list">
        <thead><tr>
          <th data-col="status" class="sortable">状態</th>
          <th data-col="name" class="sortable">デッキ名</th>
          <th data-col="pages" class="sortable" style="text-align:right" title="ページ数">頁</th>
          <th data-col="theme" class="sortable" title="採用しているテーマ（frontmatter の theme:）">テーマ</th>
          <th data-col="updated" class="sortable">更新</th>
          <th data-col="location" class="sortable">場所</th>
          <th>操作</th>
        </tr></thead>
        <tbody id="deckBody"><tr><td colspan="7" class="muted">読み込み中…</td></tr></tbody>
      </table>
    </div>
    <p class="muted" style="margin-bottom:0">保存先（個人）: <code>{{DECKS}}</code><br>
    状態の <b>個</b>＝個人作業領域(decks)で編集中／<b>共</b>＝共有gitの正規版／<b>更</b>＝要更新（開くと自動で再生成）。<b>発表</b>は最新化されたプレビューを開きます。
    複数フォルダの監視は <code>.marp-studio.json</code> で設定できます。</p>
  </div>
</div>
<script>
let allDecks = [], sortCol = 'updated', sortDir = -1, stealth = false;
const fmt=(s)=>{ const d=new Date(s); return isNaN(d)?'-':d.getFullYear()+'/'+String(d.getMonth()+1).padStart(2,'0')+'/'+String(d.getDate()).padStart(2,'0'); };
function escH(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
async function refresh(opts){
  opts = opts || {};
  document.getElementById('cnt').textContent = '読み込み中…';
  const qs = new URLSearchParams();
  if(opts.rescan) qs.set('rescan','1');
  if(opts.depth) qs.set('depth', document.getElementById('depth').value);
  const r = await fetch('/api/decks?'+qs.toString());
  allDecks = await r.json();
  const rf = document.getElementById('rootFilter'); const cur = rf.value;
  const labels = [...new Set(allDecks.map(d=>d.rootLabel))];
  rf.innerHTML = '<option value="">すべて</option>' + labels.map(l=>'<option value="'+escH(l)+'">'+escH(l)+'</option>').join('');
  if(labels.indexOf(cur)>=0) rf.value = cur;
  render();
}
function applyFilter(decks){
  const q = document.getElementById('filter').value.trim().toLowerCase();
  const root = document.getElementById('rootFilter').value;
  const byRoot = decks.filter(function(d){ return !root || d.rootLabel === root; });
  // ステルスON: 空欄=非表示、* / % =全件。それ以外は通常の絞り込み（OFF時は従来どおりで挙動不変）。
  if(stealth){
    if(q==='') return [];
    if(q==='*'||q==='%') return byRoot;
  }
  return byRoot.filter(function(d){
    if(q && (d.name+' '+(d.title||'')+' '+d.relPath+' '+d.rootLabel+' '+(d.theme||'')).toLowerCase().indexOf(q)<0) return false;
    return true;
  });
}
function sortDecks(decks){
  const c = sortCol;
  return decks.slice().sort(function(a,b){
    let x,y;
    if(c==='pages'){x=a.pages;y=b.pages;}
    else if(c==='theme'){x=a.theme||'';y=b.theme||'';}
    else if(c==='updated'){x=new Date(a.updated).getTime();y=new Date(b.updated).getTime();}
    else if(c==='location'){x=a.rootLabel+'/'+a.relPath;y=b.rootLabel+'/'+b.relPath;}
    else if(c==='status'){x=a.isPrimary?0:1;y=b.isPrimary?0:1;}
    else {x=a.name;y=b.name;}
    if(x<y) return -sortDir; if(x>y) return sortDir; return 0;
  });
}
function rowHtml(d){
  const badge = d.isPrimary ? '<span class="badge personal" title="個人＝個人作業領域(decks)で編集中">個</span>' : '<span class="badge shared" title="共有＝共有gitの正規版">共</span>';
  const stale = d.needsBuild ? '<span class="badge stale" title="要更新＝プレビュー再生成が必要（開くと自動更新）">更</span>' : '';
  const eid = encodeURIComponent(d.id);
  const del = d.isPrimary ? ' ｜ <a href="#" class="del" style="color:#da1e28">削除</a>' : '';
  return '<tr data-id="'+escH(d.id)+'" data-name="'+escH(d.name)+'">'
    + '<td style="white-space:nowrap">'+badge+stale+'</td>'
    + '<td class="deckname"'+(d.title?' title="タイトル: '+escH(d.title)+'"':'')+'><strong>'+escH(d.name)+'</strong>'
      +(d.title&&d.title!==d.name?'<span class="deck-sub">'+escH(d.title)+'</span>':'')+'</td>'
    + '<td style="text-align:right" class="muted">'+d.pages+'</td>'
    + '<td class="muted" style="white-space:nowrap">'+escH(d.theme||'')+'</td>'
    + '<td class="muted" style="white-space:nowrap">'+fmt(d.updated)+'</td>'
    + '<td class="muted" style="font-size:12px">'+escH(d.rootLabel)+' / '+escH(d.relPath)+'</td>'
    + '<td style="white-space:nowrap"><a href="/edit?deck='+eid+'">編集</a> ｜ <a href="/deck/'+eid+'/.preview.html" target="_blank">発表</a>'
    + ' ｜ <a href="#" class="copy" data-path="'+escH(d.rootPath+'/'+d.relPath)+'">パス</a>'+del+'</td></tr>';
}
function render(){
  const rows = sortDecks(applyFilter(allDecks));
  const q = document.getElementById('filter').value.trim();
  // ステルス時は表示中の実数だけを出す（空欄=0件で一覧と一致／「/全19」を出さないので隠している総数も漏らさない）。
  // 通常時は従来の「一致/全」。
  document.getElementById('cnt').textContent = stealth
    ? (rows.length + ' 件')
    : (rows.length+' 件 / 全 '+allDecks.length+' 件');
  const tb = document.getElementById('deckBody');
  const empty = (stealth && q==='')
    ? 'キーワードを入力すると表示します（すべて表示するには * を入力）。'
    : '該当なし。上の「作成」やフォルダ追加・再走査をお試しください。';
  tb.innerHTML = rows.length ? rows.map(rowHtml).join('') : '<tr><td colspan="7" class="muted">'+empty+'</td></tr>';
  tb.querySelectorAll('.del').forEach(function(a){ a.onclick = onDelete; });
  tb.querySelectorAll('.copy').forEach(function(a){ a.onclick = onCopy; });
}
async function onDelete(e){
  e.preventDefault();
  const tr = e.target.closest('tr'); const id = tr.dataset.id, name = tr.dataset.name;
  if(!confirm('デッキ「'+name+'」を削除します。よろしいですか？\\n（すぐには消えず .trash に移動するので、後から戻せます）')) return;
  const r = await fetch('/api/delete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({deck:id})});
  const j = await r.json(); if(j.error){ alert(j.error); return; } refresh(); refreshTrash();
}
async function onCopy(e){
  e.preventDefault();
  const p = e.target.dataset.path;
  try{ await navigator.clipboard.writeText(p); const t=e.target; t.textContent='コピー済'; setTimeout(function(){t.textContent='パス';},1200); }
  catch(_){ prompt('パス（手動コピー）', p); }
}
document.querySelectorAll('.deck-table th.sortable').forEach(function(th){
  th.onclick = function(){ const c=th.dataset.col; if(sortCol===c) sortDir*=-1; else { sortCol=c; sortDir=(c==='updated')?-1:1; } render(); };
});
document.getElementById('filter').oninput = render;
document.getElementById('rootFilter').onchange = render;
(function(){ const b=document.getElementById('stealth'); b.onclick=function(){ stealth=!stealth; b.setAttribute('aria-pressed', stealth?'true':'false'); b.style.background = stealth?'#d0e2ff':''; b.style.color = stealth?'#0043ce':''; render(); }; })();
document.getElementById('rescan').onclick = function(){ refresh({rescan:true}); refreshTrash(); };
document.getElementById('depth').onchange = function(){ refresh({depth:true}); };
// ゴミ箱(.trash)の件数・容量を一覧に表示し、「空にする」で手動削除（自動削除はしない）。
async function refreshTrash(){
  try{
    const j = await (await fetch('/api/trash')).json();
    const info=document.getElementById('trashInfo'), btn=document.getElementById('emptyTrash');
    if(j.count>0){
      const mb = j.bytes>=1048576 ? (j.bytes/1048576).toFixed(1)+' MB' : Math.max(1,Math.round(j.bytes/1024))+' KB';
      info.textContent='🗑 ゴミ箱 '+j.count+'件（約'+mb+'）'; btn.style.display='';
    } else { info.textContent=''; btn.style.display='none'; }
  }catch(e){ /* 取得失敗は無視 */ }
}
document.getElementById('emptyTrash').onclick = async function(){
  if(!confirm('ゴミ箱(.trash)の中身を完全に削除します。\\n元に戻せません。よろしいですか？')) return;
  try{
    const j = await (await fetch('/api/trash/empty',{method:'POST'})).json();
    await refreshTrash();
    alert('ゴミ箱を空にしました（'+(j.removed||0)+'件削除）');
  }catch(e){ alert('削除に失敗しました: '+e.message); }
};
async function refreshGuides(){
  const r= await fetch('/api/guides'); const gs= await r.json();
  const ul=document.getElementById('guides'); ul.innerHTML = gs.length?'':'<li class="muted">ガイドが見つかりません</li>';
  const label=(g)=> g==='README.md' ? '📌 はじめに（このフォルダの案内）'
    : g==='Marp-Studioの使い方.md' ? '📗 かんたん版（Studioの使い方）'
    : g==='Markdown_Marpプレゼン作成ガイド.md' ? '📘 詳細版（作成ガイド）'
    : g.startsWith('_dev-') ? '🛠 '+g.replace(/^_dev-/,'').replace(/\\.md$/,'')+'（開発元用）'
    : '📖 '+g.replace(/\\.md$/,'');
  for(const g of gs){ const li=document.createElement('li');
    li.innerHTML='<span>'+label(g)+'</span><span><a href="/guide?file='+encodeURIComponent(g)+'" target="_blank">開く</a></span>';
    ul.appendChild(li); }
}
refreshGuides();
document.getElementById('create').onclick = async ()=>{
  const title=document.getElementById('title').value.trim();
  const subtitle=document.getElementById('subtitle').value.trim();
  const msg=document.getElementById('msg');
  if(!title){ msg.textContent='タイトルを入力してください'; return; }
  msg.textContent='作成中…';
  const r= await fetch('/api/new',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({title,subtitle})});
  const j= await r.json();
  if(j.error){ msg.textContent=j.error; return; }
  location.href='/edit?deck='+encodeURIComponent(j.name);
};
// 環境チェック（図が出ない等のトラブル診断）。実際に小さなMermaidを描画して結果を出す。
async function runSelfCheck(){
  const modal=document.getElementById('scModal'), body=document.getElementById('scBody');
  modal.style.display='flex';
  body.innerHTML='<p class="muted">確認中…（初回は図変換ツールの取得で時間がかかることがあります）</p>';
  try{
    const j= await (await fetch('/api/selfcheck')).json();
    if(j.error){ body.innerHTML='<p style="color:#da1e28">チェックに失敗しました: '+escH(j.error)+'</p>'; return; }
    const row=function(name,desc,o){ const ok=o&&o.ok;
      return '<div style="display:flex;gap:12px;padding:10px 0;border-bottom:1px solid var(--line);align-items:flex-start">'
        +'<span style="min-width:160px"><b>'+name+'</b><br><span class="muted" style="font-size:12px">'+desc+'</span></span>'
        +'<span style="color:'+(ok?'#0e6027':'#da1e28')+';font-weight:700;min-width:34px">'+(ok?'OK':'NG')+'</span>'
        +'<span style="flex:1;word-break:break-all;font-size:13px">'+escH((o&&o.detail)||'')
        +(o&&o.hint?'<br><b style="color:#a2191f">対処:</b> '+escH(o.hint):'')+'</span></div>'; };
    body.innerHTML=
      '<div class="muted" style="font-size:12px;margin-bottom:8px">確認する項目 ── 左:何を見るか ／ 中:判定(OK/NG) ／ 右:結果・対処</div>'
      +row('Node.js','スライド生成の土台（v18以上が必要）',j.node)
      +row('Marp','Markdown をスライドに変換するツール',j.marp)
      +row('図 (Mermaid)','コードから図(SVG)を生成（Chrome/Edge を使用）',j.mermaid)
      +row('PPTX (β)','PowerPoint(編集可能)への変換部品',j.pptx);
  }catch(e){ body.innerHTML='<p style="color:#da1e28">通信エラー: '+escH(e.message)+'</p>'; }
}
document.getElementById('selfcheckBtn').onclick=runSelfCheck;
document.getElementById('scClose').onclick=function(){ document.getElementById('scModal').style.display='none'; };

// バージョン情報・更新（版バッジ/「🔄 更新」ボタンで開く）
async function loadVersionPanel(){
  const vp=document.getElementById('updVersions'), rb=document.getElementById('updRollback');
  try{
    const j= await (await fetch('/api/version')).json();
    let html='<b>本体</b>: v'+escH(j.core);
    for(const k of Object.keys(j.installed||{})){ if(k==='core') continue; html+='<br>'+escH(k)+': '+escH(j.installed[k]); }
    if(!j.updateEnabled){ html+= j.devRoot
      ? '<br><span style="color:#697077">※ 開発元（git管理）です。自動更新は配布物向けの機能で、この環境は git で常に最新です。</span>'
      : '<br><span style="color:#8a6100">※ この配布物には更新元が設定されていません（手動でzipを入れ替えてください）</span>'; }
    if(j.pending){ const t=j.pending.type==='rollback'?'前の版へ戻す':'更新';
      html+='<br><b style="color:#0e6027">適用待ち（'+t+'）</b>: '+((j.pending.items||[]).map(function(i){return escH(i.label||i.id);}).join(', ')||'—')
        +' <button class="btn sec" id="updCancel" style="padding:2px 8px;font-size:12px">取り消す</button>'
        +'<br><span class="muted">次回起動時に適用されます</span>'; }
    vp.innerHTML=html;
    rb.style.display=j.canRollback?'inline-block':'none';
    const cancel=document.getElementById('updCancel');
    if(cancel) cancel.onclick=async function(){
      try{ const r= await (await fetch('/api/update/cancel',{method:'POST'})).json(); document.getElementById('updMsg').textContent=r.message||''; loadVersionPanel(); }
      catch(e){ document.getElementById('updMsg').textContent='失敗: '+e.message; }
    };
  }catch(e){ vp.textContent='バージョン情報の取得に失敗: '+e.message; }
}
// 変更内容（changelog）を版ごと（日付つき）に表示。複数バージョンに跨る場合は全部並ぶ。
// 各コンポーネントにチェックボックスを付け、選んだものだけ適用予約できる。
function renderFound(found){
  if(!found||!found.length) return '';
  return found.map(function(f){
    const notes=(f.notes||[]).map(function(n){
      const li=(n.notes||[]).map(function(x){return '<li>'+escH(x)+'</li>';}).join('');
      return '<div style="margin:6px 0"><b>'+escH(n.version||'')+'</b> <span class="muted">'+escH(n.date||'')+'</span>'
        +(n.summary?' — '+escH(n.summary):'')+(li?'<ul style="margin:4px 0 0 18px">'+li+'</ul>':'')+'</div>';
    }).join('');
    // ドロップ方式（テーマ）でまだファイルが置かれていない場合は、チェックでなく「取得案内＋置き場」を出す。
    const needFile = (f.delivery === 'drop' && !f.ready);
    const head = needFile
      ? '<b>'+escH(f.label||f.id)+'</b> <span class="muted">'+escH(f.from)+' → '+escH(f.to)+'</span>'
        +'<span style="color:#8a6100;font-size:12px;margin-left:6px">ファイル未配置</span>'
      : '<label style="display:block;cursor:pointer"><input type="checkbox" class="updchk" value="'+escH(f.id)+'" checked> '
        +'<b>'+escH(f.label||f.id)+'</b> <span class="muted">'+escH(f.from)+' → '+escH(f.to)+'</span></label>';
    const guide = needFile
      ? '<div class="muted" style="font-size:12px;margin-top:6px;background:#fff8e1;border:1px solid #ffe08a;border-radius:4px;padding:8px">'
        +'このテーマは本体を配布元から取得し、次のフォルダに置いてから「更新を確認」を押し直してください：<br>'
        +'<code style="word-break:break-all">'+escH(f.dropDir||'')+'</code>'
        +(f.obtainFrom?'<br>取得元: <a href="'+escH(f.obtainFrom)+'" target="_blank">開く</a>':'')+'</div>'
      : '';
    return '<div class="card" style="margin:10px 0;padding:12px">'+head
      +(f.notesTruncated?'<div class="muted" style="font-size:12px">（これより古い履歴は省略）</div>':'')
      +'<div style="margin-top:6px">'+(notes||'<div class="muted" style="font-size:12px">変更内容の記載なし</div>')+'</div>'
      +guide+'</div>';
  }).join('');
}
function openUpdModal(){
  document.getElementById('updModal').style.display='flex';
  document.getElementById('updResult').innerHTML=''; document.getElementById('updMsg').textContent='';
  loadVersionPanel();
}
document.getElementById('verBadge').onclick=openUpdModal;       // 版バッジからも開ける（補助）
document.getElementById('updateBtn').onclick=openUpdModal;      // ヘッダーの「🔄 更新」ボタン（主導線）
document.getElementById('updClose').onclick=function(){ document.getElementById('updModal').style.display='none'; };
document.getElementById('updCheck').onclick=async function(){
  const msg=document.getElementById('updMsg'), out=document.getElementById('updResult'), b=this;
  b.disabled=true; msg.textContent='確認中…'; out.innerHTML='';
  try{
    const j= await (await fetch('/api/update/check',{method:'POST'})).json();
    msg.textContent=j.message||'';
    if(j.found && j.found.length){
      // 中身を見せるだけ。ここでは取得・適用しない。下のボタンを押したものだけ予約。
      out.innerHTML=renderFound(j.found)
        +'<div style="display:flex;gap:8px;justify-content:flex-end;align-items:center;margin-top:6px">'
        +'<span class="muted" style="flex:1;font-size:12px">見るだけでは適用されません。チェックした項目だけ予約されます。</span>'
        +'<button class="btn" id="updApply">✓ 選んだ更新を次回起動時に適用</button></div>';
      document.getElementById('updApply').onclick=applySelected;
    } else { out.innerHTML=''; }
    loadVersionPanel();
  }catch(e){ msg.textContent='確認に失敗: '+e.message; }
  finally{ b.disabled=false; }
};
async function applySelected(){
  const ids=[].slice.call(document.querySelectorAll('.updchk:checked')).map(function(c){return c.value;});
  const msg=document.getElementById('updMsg'), b=this;
  if(!ids.length){ msg.textContent='適用する項目を選んでください'; return; }
  b.disabled=true; msg.textContent='取得中…';
  try{
    const r= await (await fetch('/api/update/apply',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({ids:ids})})).json();
    msg.textContent=r.message||'';
    document.getElementById('updResult').innerHTML='';   // 予約済み。一覧は閉じてパネルに「適用待ち」を出す
    loadVersionPanel();
  }catch(e){ msg.textContent='取得に失敗: '+e.message; }
  finally{ b.disabled=false; }
}
document.getElementById('updRollback').onclick=async function(){
  if(!confirm('前の版に戻します。次回起動時に適用されます。よろしいですか？')) return;
  const msg=document.getElementById('updMsg');
  try{ const j= await (await fetch('/api/update/rollback',{method:'POST'})).json(); msg.textContent=j.message||''; loadVersionPanel(); }
  catch(e){ msg.textContent='失敗: '+e.message; }
};
refresh();
refreshTrash();
${QUIT_JS}
${HEARTBEAT_JS}
</script></body></html>`;

const PAGE_EDIT = `<!doctype html><html lang="ja"><head><meta charset="utf-8"><title>編集 — Marp Studio</title>${FAVICON}${STYLE}
<style>
  body{display:flex;flex-direction:column;height:100vh;overflow:hidden}
  header,.toolbar,#fzPanel,#tblPanel,#mmPanel,#mmErr,#htmlWarn,.panehead{flex-shrink:0}
  /* Markdownで書けるのにHTMLで書いている箇所の警告帯（琥珀・非ブロッキング）。直し方＋AIへの指示コピーを提示。 */
  #htmlWarn{display:none;align-items:flex-start;gap:12px;background:#fff8e1;border-bottom:1px solid #ffdf9e;color:#6b5300;padding:8px 16px;font-size:13px;line-height:1.5;max-height:30vh;overflow:auto}
  #htmlWarn .items{margin:2px 0 0;font-size:12px;color:#5a4a00}
  #htmlWarn .x{flex-shrink:0;cursor:pointer;font-weight:bold;color:#6b5300;font-size:16px;line-height:1}
  #htmlWarn button.mini{padding:3px 10px;font-size:12px}
  .edit{display:grid;grid-template-columns:1fr 1fr;gap:0;flex:1;min-height:0}
  .pane{display:flex;flex-direction:column;min-width:0}
  .pane textarea{flex:1;border:0;border-right:1px solid var(--line);border-radius:0;padding:16px;resize:none;line-height:1.5;font-family:ui-monospace,Menlo,Consolas,monospace}
  .pane iframe{flex:1;border:0;width:100%;background:#fff}
  .pane.preview{padding-bottom:7px;padding-right:6px;background:#f4f4f4;position:relative}  /* 下=ページャー用に控えめ余白 / 右=枠に貼り付かないよう少し。position=生成中オーバーレイの基準 */
  .toolbar{background:#fff;border-bottom:1px solid var(--line);padding:8px 16px;display:flex;gap:8px;align-items:center}
  .panehead{background:#fafafa;border-bottom:1px solid var(--line);padding:6px 12px;font-size:12px;color:var(--gray)}
  .ins{border:1px solid var(--ibm);border-radius:4px;padding:6px 10px;font-size:13px;cursor:pointer}
  .ins.slide{background:var(--ibm);color:#fff}        /* ページ追加=塗り */
  .ins.slide:hover{background:#0a4fd6}
  .ins.part{background:#fff;color:var(--ibm)}         /* スライド内=白 */
  .ins.part:hover{background:#edf5ff}
  /* 表編集ストリップ：カーソルが表の中にある時だけ本文ペインのヘッダーに出る（普段は非表示＝busyにしない） */
  .tblstrip{display:none;align-items:center;gap:4px;flex-wrap:nowrap;flex-shrink:0}
  .tblstrip .tlabel{font-size:11px;color:var(--ibm);font-weight:600;white-space:nowrap}
  .tblstrip .tbl{border:1px solid var(--ibm);background:#fff;color:var(--ibm);border-radius:4px;font-size:12px;line-height:1;padding:3px 7px;cursor:pointer;white-space:nowrap}
  .tblstrip .tbl:hover{background:#edf5ff}
  .tblstrip .tbl.del{border-color:#da1e28;color:#da1e28}        /* 削除＝赤（破壊的操作。Xが積算でなく「消す」と一目で分かる） */
  .tblstrip .tbl.del:hover{background:#fff1f1}
  .tblstrip .tbl-sep{width:1px;height:15px;background:var(--line);margin:0 2px}
  #fzPanel select,#tblPanel select,#mmPanel select{padding:5px;border:1px solid var(--ibm);border-radius:4px;font-size:13px;color:var(--ibm);background:#fff}
  .fz{border:1px solid var(--line);background:#fff;border-radius:4px;cursor:pointer;font-size:13px;padding:2px 0}
  .fz.sel{background:var(--ibm);color:#fff;border-color:var(--ibm)}
  .panehead{display:flex;align-items:center;gap:10px}
  .ph-hint{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0}  /* 狭幅では説明文を省略表示 */
  .pageind{margin-left:auto;font-weight:600;color:var(--ibm);flex-shrink:0}        /* カーソルの現在ページ */
  .dirty{margin-left:auto;flex-shrink:0}
  .dirty.clean{color:var(--gray)}                                    /* 保存済み・最新 */
  .dirty.stale{color:#ba4e00;font-weight:600}                        /* プレビュー反映待ち（入力直後） */
  .dirty.unsaved{color:var(--ibm);font-weight:600}                   /* プレビューは最新だが未保存 */
  .follow{display:flex;align-items:center;gap:4px;font-size:13px;color:var(--gray);cursor:pointer;user-select:none;white-space:nowrap;flex-shrink:0}
  /* テーマ採用＝普段は隠し、別テーマをプレビューした時だけ出す小さなリンク（多用しない操作なので控えめに） */
  .themeapply{background:none;border:none;color:var(--ibm);font-size:12px;cursor:pointer;padding:2px 4px;text-decoration:underline;white-space:nowrap;flex-shrink:0}
  .themeapply:hover{color:#0043ce}
  /* ツールバーの状態メッセージ：グレーで埋もれないよう色・太字・縦位置を整える */
  .toolbar #msg{font-size:13px;line-height:1;color:var(--ibm);font-weight:600;white-space:nowrap;align-self:center}
  /* 処理中フローティング：プレビュー更新中は全面を覆い操作をロックする */
  #busy{position:fixed;inset:0;z-index:9000;display:none;align-items:center;justify-content:center;background:rgba(22,22,22,.28);backdrop-filter:blur(1px)}
  #busy .box{background:#fff;border:1px solid var(--line);border-radius:10px;box-shadow:0 8px 30px rgba(0,0,0,.18);padding:20px 26px;display:flex;align-items:center;gap:14px;font-size:15px;color:var(--ink);max-width:80vw}
  #busy .spin{width:22px;height:22px;border:3px solid #d0e2ff;border-top-color:var(--ibm);border-radius:50%;animation:busyspin .8s linear infinite;flex-shrink:0}
  @keyframes busyspin{to{transform:rotate(360deg)}}
  /* Mermaid描画失敗の警告帯（黙ってコードブロックにしない＝原因を見せる） */
  #mmErr{display:none;align-items:flex-start;gap:12px;background:#fff1f1;border-bottom:1px solid #ffb3b8;color:#a2191f;padding:8px 16px;font-size:13px;line-height:1.5;max-height:30vh;overflow:auto}
  #mmErr .dl{margin-top:4px} #mmErr .d{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:12px;color:#750e13;word-break:break-all}
  #mmErr .diag{flex-shrink:0;color:#0043ce;font-weight:600;white-space:nowrap}
  #mmErr .x{flex-shrink:0;cursor:pointer;font-weight:bold;color:#a2191f;font-size:16px;line-height:1}
  /* プレビュー生成中オーバーレイ（開いた直後・重いビルド時のみ／チラつき防止で350ms超だけ表示） */
  #prevLoading{position:absolute;left:0;right:0;bottom:0;top:30px;display:none;align-items:center;justify-content:center;gap:10px;background:rgba(244,244,244,.72);backdrop-filter:blur(1px);z-index:5;font-size:14px;color:var(--ibm);font-weight:600}
  #prevLoading .spin{width:18px;height:18px;border:3px solid #d0e2ff;border-top-color:var(--ibm);border-radius:50%;animation:busyspin .8s linear infinite}
  /* 未保存のとき保存ボタンを目立たせる（自動プレビューで見た目が最新でも、保存忘れに気づけるように） */
  .btn#save.needsave{background:#ba4e00} .btn#save.needsave:hover{background:#9a4100}
</style></head>
<body><header><h1>Marp Studio</h1><span class="ver">v${STUDIO_VERSION}</span><span class="sub" id="deckname"></span><span style="flex:1"></span><a href="/" id="toList">← 一覧へ</a>${QUIT_BTN}</header>
<div class="toolbar">
  <button class="btn" id="save" title="本文を .md ファイルに書き込んで確定します（プレビューは入力で自動更新されますが、保存しないとファイルには残りません）">保存</button>
  <button class="btn sec" id="pdf">PDFを作る</button>
  <button class="btn sec" id="pptx" title="PowerPoint(.pptx)を作ります。文字・表・付箋は編集可能、図(Mermaid/画像)だけ画像として埋め込みます（β）">PPTXを作る(β)</button>
  <button class="btn sec" id="rename">名前を変更</button>
  <label style="font-size:13px;color:var(--gray)" title="ここでの切り替えはプレビュー表示だけ。デッキ（.md）は書き換えません＝gitに反映されません">テーマ(表示のみ) <select id="theme"></select></label>
  <button class="themeapply" id="themeSave" style="display:none" title="表示中のテーマを本文に採用します（未保存になります。確定は「保存」）">→ このテーマを採用</button>
  <label class="follow" title="カーソルのあるページにプレビューを自動で合わせます（既定ON・動作は軽量）。違和感があればOFFに"><input type="checkbox" id="follow" checked>プレビュー追従</label>
</div>
<div class="toolbar" style="flex-wrap:wrap;gap:6px">
  <span class="muted" style="margin-right:2px">🆕 ページを追加:</span>
  <button class="ins slide" data-k="slide" title="種類（表紙・中表紙・背表紙・リード文＋コンテンツ）を選んでスライドを1枚追加します">＋スライド</button>
  <button class="ins slide" data-k="section" title="章の区切り（セクション中扉）ページを追加します">セクション中扉</button>
  <button class="ins slide" data-k="dupSlide" title="今カーソルがあるスライドを丸ごと複製して直後に追加します（会議中の「案B」作りに便利）">このスライドを複製</button>
  <span style="width:1px;height:22px;background:var(--line);margin:0 6px"></span>
  <span class="muted" style="margin-right:2px">⬇ 今のスライドに入れる:</span>
  <button class="ins part" data-k="cols" title="今のスライドに2カラム枠を入れます">2カラム</button>
  <button class="ins part" data-k="bullets" title="今のスライドに箇条書きを入れます">箇条書き</button>
  <button class="ins part" data-k="mermaid" title="図(Mermaid)をカーソル位置に入れます。保存でプレビューに画像表示されます">Mermaid図</button>
  <button class="ins part" data-k="fusen" title="付箋を色・サイズ・位置を選んで入れます">付箋</button>
  <button class="ins part" data-k="table" title="表を行数・列数を選んで入れます">表</button>
  <button class="ins part" data-k="image" title="画像を選んで取り込み、今のスライドに入れます">画像</button>
  <input type="file" id="file" accept="image/*" style="display:none">
</div>
<div id="fzPanel" style="display:none;background:#fff;border-bottom:1px solid var(--line);padding:10px 16px;align-items:center;gap:14px;flex-wrap:wrap">
  <strong style="font-size:13px">付箋</strong>
  <label style="font-size:13px">文言 <input id="fzText" value="メモ" style="font-size:13px;padding:4px 6px;border:1px solid #8d8d8d;border-radius:4px;width:160px"></label>
  <label style="font-size:13px">色
    <select id="fzColor"><option value="yellow">黄</option><option value="blue">青</option><option value="pink">桃</option><option value="green">緑</option></select>
  </label>
  <label style="font-size:13px">サイズ
    <select id="fzSize"><option value="">標準</option><option value="small">小</option><option value="large">大</option><option value="wide">横長</option><option value="fit">内容に合わせる</option></select>
  </label>
  <span style="font-size:13px">位置:</span>
  <div id="fzGrid" style="display:inline-grid;grid-template-columns:repeat(3,26px);grid-gap:3px">
    <button class="fz" data-t="110" data-l="60">↖</button><button class="fz" data-t="110" data-l="515">↑</button><button class="fz" data-t="110" data-l="970">↗</button>
    <button class="fz" data-t="320" data-l="60">←</button><button class="fz sel" data-t="320" data-l="515">＋</button><button class="fz" data-t="320" data-l="970">→</button>
    <button class="fz" data-t="520" data-l="60">↙</button><button class="fz" data-t="520" data-l="515">↓</button><button class="fz" data-t="520" data-l="970">↘</button>
  </div>
  <button class="btn" id="fzInsert">挿入</button>
  <button class="btn sec" id="fzClose">閉じる</button>
  <span class="muted" style="font-size:12px">挿入後、本文の <code>top/left</code> の数値で微調整できます</span>
</div>
<div id="tblPanel" style="display:none;background:#fff;border-bottom:1px solid var(--line);padding:10px 16px;align-items:center;gap:14px;flex-wrap:wrap">
  <strong style="font-size:13px">表</strong>
  <label style="font-size:13px">列数
    <select id="tblCols"><option>2</option><option selected>3</option><option>4</option><option>5</option><option>6</option></select>
  </label>
  <label style="font-size:13px">行数（データ）
    <select id="tblRows"><option>1</option><option selected>2</option><option>3</option><option>4</option><option>5</option><option>6</option><option>7</option><option>8</option></select>
  </label>
  <button class="btn" id="tblInsert">挿入</button>
  <button class="btn sec" id="tblClose">閉じる</button>
  <span class="muted" style="font-size:12px">先頭は見出し行になります</span>
</div>
<div id="mmPanel" style="display:none;background:#fff;border-bottom:1px solid var(--line);padding:10px 16px;align-items:center;gap:14px;flex-wrap:wrap">
  <strong style="font-size:13px">Mermaid図</strong>
  <label style="font-size:13px">種類
    <select id="mmType">
      <optgroup label="フロー・構造">
        <option value="flow">フローチャート</option>
        <option value="sequence">シーケンス図</option>
        <option value="state">状態遷移図</option>
        <option value="class">クラス図</option>
        <option value="er">ER図（実体関連）</option>
        <option value="mindmap">マインドマップ</option>
      </optgroup>
      <optgroup label="時間・計画">
        <option value="gantt">ガントチャート</option>
        <option value="timeline">タイムライン</option>
        <option value="journey">ユーザージャーニー</option>
      </optgroup>
      <optgroup label="グラフ・分析">
        <option value="pie">円グラフ</option>
        <option value="bar">棒グラフ</option>
        <option value="line">折れ線グラフ</option>
        <option value="quadrant">4象限（quadrant）</option>
      </optgroup>
    </select>
  </label>
  <button class="btn" id="mmInsert">挿入</button>
  <button class="btn sec" id="mmClose">閉じる</button>
  <span class="muted" style="font-size:12px">雛形を入れます。保存でプレビューに画像表示（初回は少し時間がかかります）</span>
</div>
<div id="newPanel" style="display:none;background:#fff;border-bottom:1px solid var(--line);padding:10px 16px;align-items:center;gap:14px;flex-wrap:wrap">
  <strong style="font-size:13px">新しいスライド</strong>
  <label style="font-size:13px">種類
    <select id="newType">
      <option value="title">表紙</option>
      <option value="section">中表紙（章の区切り）</option>
      <option value="closing">背表紙（結び）</option>
      <option value="lead" selected>リード文＋コンテンツ</option>
    </select>
  </label>
  <label id="newCountWrap" style="font-size:13px">コンテンツ数
    <select id="newCount"><option>1</option><option selected>2</option><option>3</option><option>4</option></select>
  </label>
  <button class="btn" id="newInsert">挿入</button>
  <button class="btn sec" id="newClose">閉じる</button>
  <span class="muted" style="font-size:12px">選んだ型の雛形を1枚、カーソル位置の直後に追加します。保存でプレビュー反映</span>
</div>
<div id="mmErr"></div>
<div id="htmlWarn"></div>
<div class="edit">
  <div class="pane"><div class="panehead"><span class="ph-hint" title="上の「挿入」ボタンでカーソル位置に雛形を入れられます。スライドの区切りは ---">本文（Markdown）</span>
    <span class="tblstrip" id="tblStrip">
      <span class="tlabel">表:</span>
      <button class="tbl" data-op="colAddL" title="カーソル位置の左に列を追加">左に列+</button>
      <button class="tbl" data-op="colAddR" title="カーソル位置の右に列を追加">右に列+</button>
      <button class="tbl del" data-op="colDel" title="カーソルのある列を削除">列削</button>
      <button class="tbl" data-op="colLeft" title="列を左へ移動">◀移動</button>
      <button class="tbl" data-op="colRight" title="列を右へ移動">移動▶</button>
      <span class="tbl-sep"></span>
      <button class="tbl" data-op="rowAdd" title="カーソルの下に行を追加">行+</button>
      <button class="tbl del" data-op="rowDel" title="カーソルのある行を削除">行削</button>
    </span><span id="pageInd" class="pageind"></span></div><textarea id="src" spellcheck="false"></textarea></div>
  <div class="pane preview"><div class="panehead"><span class="ph-hint">プレビュー（入力で自動更新・保存で確定）</span><span id="msg" class="muted" style="flex:1;font-size:12px;text-align:right;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"></span><span id="dirty" class="dirty"></span></div><iframe id="prev"></iframe><div id="prevLoading"><span class="spin"></span>プレビュー生成中…</div></div>
</div>
<div id="busy"><div class="box"><span class="spin"></span><span id="busyMsg">プレビューを更新中…</span></div></div>
<script>
const deck = new URLSearchParams(location.search).get('deck');
document.getElementById('deckname').textContent = deck;
const msg=document.getElementById('msg'), prev=document.getElementById('prev'), src=document.getElementById('src');
const pageInd=document.getElementById('pageInd'), dirty=document.getElementById('dirty'), follow=document.getElementById('follow');
let savedContent='';      // 直近にディスク保存した本文（未保存判定の基準）
let previewedContent='';  // 現在iframeプレビューが反映している本文（保存 or 自動プレビューで更新）
// 非ブロッキング自動プレビューの状態
let autoTimer=null, autoInFlight=false, autoPending=false, autoReload=false, saving=false, lastDeferred=0;
let pendingPage=null;   // 次のiframe再読込後に「表示中だったページ」へ戻すための一時保持（テーマ採用など、カーソルに追従させたくない操作用）
let prevLoadTimer=null;   // 「生成中…」は350ms超かかる時だけ出す（軽い自動プレビューではチラつかせない）
function showPreview(){
  if(prevLoadTimer) clearTimeout(prevLoadTimer);
  prevLoadTimer=setTimeout(()=>{ const el=document.getElementById('prevLoading'); if(el) el.style.display='flex'; }, 350);
  prev.src = '/deck/'+encodeURIComponent(deck)+'/.preview.html?t='+Date.now();
}
function hidePrevLoading(){ if(prevLoadTimer){ clearTimeout(prevLoadTimer); prevLoadTimer=null; } const el=document.getElementById('prevLoading'); if(el) el.style.display='none'; }
function escE(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}
// Mermaid描画失敗を赤帯で表示（黙ってコードブロックにせず、実エラーを見せる）。空なら隠す。
function showMermaidErrors(list){
  const el=document.getElementById('mmErr');
  if(!list || !list.length){ el.style.display='none'; el.innerHTML=''; return; }
  const items=list.map(function(e){ return '<div class="d">・'+escE(e.detail||'(詳細なし)')+'</div>'; }).join('');
  el.innerHTML='<div style="flex:1;min-width:0"><b>⚠ 図(Mermaid)を '+list.length+' 件描画できませんでした</b>（該当箇所はコードのまま表示されます）'
    +'<div class="dl">'+items+'</div></div>'
    +'<a href="/" target="_blank" class="diag">環境チェック</a><span class="x" title="閉じる">×</span>';
  el.style.display='flex';
  el.querySelector('.x').onclick=function(){ el.style.display='none'; };
}
// ===== Markdownハイジーン検査：Markdownで書けるのにHTMLで書いている箇所を警告（開く時/保存時）=====
// 方針: CSS/レイアウト目的のHTML(div/span/fusen 等)は許容。Markdownで代替できるHTMLだけを対象にする。
// 対象デッキは生成AIが出力していることが多いので、直し方に加え「生成AIへの指示プロンプト」をコピーできるようにする。
// 各ルールは開始タグを捕捉し、属性に style= / class= があれば見逃す。
// 理由: 色や配置などの装飾はMarkdownでは表現できない＝それはHTMLでよい。
//       「装飾なしのタグ」＝Markdownで同じことが書ける、これだけを警告する（＝主義そのもの）。
// inline:true のタグ(強調/リンク/コード/画像)は「その行が生HTMLブロックの中」だと Markdown記法が描画されない
// ことがある（例: <div ...>本文<strong>x</strong></div> の1行）。過去、描画されず已むなくタグ化した箇所を
// 「Markdownに直せ」と誤誘導しないため、生HTMLタグと同居する行では inline 系の指摘を見送る。
var HTML_RULES=[
  {re:/<(table)(\\s[^>]*)?>/ig,        kind:'表(table)',            fix:'Markdownの表（| 列1 | 列2 |）に。セルの背景色は使わない（テーマ色に追従せず、テーマ変更で不整合になる）', always:true},
  {re:/<(ul|ol)(\\s[^>]*)?>/ig,        kind:'箇条書き(ul/ol)',       fix:'「- 」や「1. 」に'},
  {re:/<(li)(\\s[^>]*)?>/ig,           kind:'リスト項目(li)',        fix:'「- 」に'},
  {re:/<(h[1-6])(\\s[^>]*)?>/ig,       kind:'見出し(h1-h6)',         fix:'「#」「##」「###」に'},
  {re:/<(blockquote)(\\s[^>]*)?>/ig,   kind:'引用(blockquote)',      fix:'「> 」に'},
  {re:/<(b|strong|i|em)(\\s[^>]*)?>/ig,kind:'強調(b/strong/i/em)',   fix:'**太字** や *斜体* に', inline:true},
  {re:/<(a)(\\s[^>]*)?>/ig,            kind:'リンク(a)',             fix:'[表示文字](URL) に', inline:true},
  {re:/<(code|pre)(\\s[^>]*)?>/ig,     kind:'コード(code/pre)',      fix:'バッククォートで囲む記法に', inline:true},
  {re:/<(img)(\\s[^>]*)?>/ig,          kind:'画像(img)',             fix:'![説明](パス) に', inline:true}
];
function attrIsPlain(attr){ return !/\\b(style|class)\\s*=/i.test(attr||''); }  // 装飾属性なし＝Markdown同等
function isHtmlBlockLine(ln){ return /<\\/?(div|span|table|thead|tbody|tr|td|th|section)\\b/i.test(ln); }  // 生HTMLブロック文脈
function scanHtmlHygiene(text){
  var lines=text.split('\\n'), incat=false, byKind={};
  for(var i=0;i<lines.length;i++){
    var ln=lines[i];
    if(/<!--\\s*catalog:start/.test(ln)){ incat=true; continue; }
    if(/<!--\\s*catalog:end/.test(ln)){ incat=false; continue; }
    if(incat) continue;                    // catalog 生成ブロックは対象外（機械が管理する領域）
    var htmlLine=isHtmlBlockLine(ln);
    for(var r=0;r<HTML_RULES.length;r++){
      var rule=HTML_RULES[r];
      if(rule.inline && htmlLine) continue; // 生HTML行の inline タグは Markdown が効かない可能性＝見送る
      rule.re.lastIndex=0; var m;
      while((m=rule.re.exec(ln))){
        if(!rule.always && !attrIsPlain(m[2])) continue;   // 表は常時警告。他は style/class 付き(装飾)を見逃す
        if(!byKind[rule.kind]) byKind[rule.kind]={kind:rule.kind, fix:rule.fix, lines:[]};
        if(byKind[rule.kind].lines.length<8) byKind[rule.kind].lines.push(i+1);
      }
    }
  }
  return Object.keys(byKind).map(function(k){ return byKind[k]; });
}
function buildAiPrompt(found){
  var L=[];
  L.push('このMarpスライド(.md)には、Markdownで書ける内容をHTMLタグで書いている箇所があります。');
  L.push('見た目を変えずに、次のHTMLをMarkdown記法へ書き直してください。');
  L.push('重要1: <div class="lead-area / columns / content-wrapper / content-box / fusen"> などレイアウト目的のHTML(div・span)は変更せず、そのまま残してください。');
  L.push('重要2: style や class の付いたHTML（色・配置などの装飾）はMarkdownで表現できないため、変更せず残してください。装飾のない素のタグだけをMarkdownへ直します。');
  L.push('重要3: 表(table)は Markdown の表へ直し、セルの背景色は付けないでください。ハードコードした色はテーマ変更に追従せず不整合になります（例: ibm系テーマでヘッダが青のまま緑にならない）。強調が要る場合も文字色までに留めます。');
  L.push('frontmatter(---)・Marpディレクティブ(<!-- _class: ... -->)・コードフェンスも触らないでください。');
  L.push('置き換え対象:');
  found.forEach(function(f){ L.push('・'+f.kind+' → '+f.fix+'（'+f.lines.slice(0,5).join(', ')+' 行目付近）'); });
  return L.join('\\n');
}
function runHtmlHygiene(when){
  var el=document.getElementById('htmlWarn');
  var found=scanHtmlHygiene(src.value);
  if(!found.length){ el.style.display='none'; el.innerHTML=''; return; }
  var items=found.map(function(f){ return '<div>・<b>'+escE(f.kind)+'</b> → '+escE(f.fix)
    +' <span style="color:#8a7a3a">('+f.lines.join(', ')+' 行目付近)</span></div>'; }).join('');
  el.innerHTML='<div style="flex:1;min-width:0"><b>⚠ Markdownで書ける箇所をHTMLで書いています（'+found.length+'種）</b>'
    +' — レイアウト用の div 等はそのままでOK。下は「Markdownに直せる」ものだけです。'
    +'<div class="items">'+items+'</div>'
    +'<div style="margin-top:6px"><button class="btn sec mini" id="htmlAiCopy" title="生成AIに貼り付けて直してもらう指示文をコピーします">AIへの指示をコピー</button></div></div>'
    +'<span class="x" title="閉じる">×</span>';
  el.style.display='flex';
  el.querySelector('.x').onclick=function(){ el.style.display='none'; };
  document.getElementById('htmlAiCopy').onclick=async function(e){
    var t=e.target, txt=buildAiPrompt(found);
    try{ await navigator.clipboard.writeText(txt); t.textContent='コピーしました'; setTimeout(function(){t.textContent='AIへの指示をコピー';},1500); }
    catch(_){ window.prompt('AIへの指示（手動コピー）', txt); }
  };
}
// 処理中ロック：オーバーレイ表示＋編集/ボタンを無効化（プレビュー更新が終わるまで操作させない）
let busyPending=null;   // 次の保存で表示する文言（テーマ切替などが事前にセット）
function setBusy(on, text){
  const b=document.getElementById('busy');
  if(on && text) document.getElementById('busyMsg').textContent=text;
  b.style.display = on ? 'flex' : 'none';
  src.readOnly = on;   // disabled だと再有効化でカーソルが0へ戻る（→追従が現在ページを見失う）。readOnly は選択位置を保つ
  ['save','theme','themeSave','pdf','pptx'].forEach(id=>{ const el=document.getElementById(id); if(el) el.disabled=on; });
}
// サーバの countPages と同ロジック（frontmatterを除いた本文の ^---^ 区切り数+1）
function totalPages(text){ const s=text.replace(/^---\\n[\\s\\S]*?\\n---\\n/,''); return (s.match(/^---$/gm)||[]).length+1; }
// カーソル位置(pos)が何ページ目か。frontmatter内は1ページ目(表紙)扱い。
function pageAt(text,pos){ let bs=0; const fm=text.match(/^---\\n[\\s\\S]*?\\n---\\n/); if(fm) bs=fm[0].length;
  if(pos<=bs) return 1; return (text.slice(bs,pos).match(/^---$/gm)||[]).length+1; }
let curPage=1;
function updateStatus(){
  const total=totalPages(src.value);
  curPage=Math.min(pageAt(src.value, src.selectionStart), total);
  pageInd.textContent='ページ '+curPage+' / '+total;
  const previewStale = src.value!==previewedContent;   // プレビューがまだ反映していない（入力直後）
  const unsaved = src.value!==savedContent;            // ディスク未保存
  if(previewStale){ dirty.textContent='○ プレビュー反映待ち…'; dirty.className='dirty stale'; }
  else if(unsaved){ dirty.textContent='✓ プレビュー最新（未保存）'; dirty.className='dirty unsaved'; }
  else { dirty.textContent='✓ 保存済み・最新'; dirty.className='dirty clean'; }
  // 保存ボタン自体に未保存を反映（色＋ラベル）。自動プレビューで見た目が最新でも保存忘れに気づけるように。
  const sv=document.getElementById('save');
  if(sv){ sv.classList.toggle('needsave', unsaved); sv.textContent = unsaved ? '● 保存（未保存の変更）' : '保存'; }
  // pendingPage 中（テーマ採用などの再読込待ち）はカーソル追従を抑止＝表示ページを動かさない。
  if(follow.checked && pendingPage==null) gotoPreviewPage(curPage);
  refreshTableStrip();
  updateThemeApply();
}
// 本文(.md)に現在書かれているテーマ。
function curDeckTheme(){ const m=src.value.match(/^theme:\\s*(.+)$/m); return m?m[1].trim():''; }
// 「採用」リンクは、ドロップダウンで本文と違うテーマを表示している時だけ出す（普段は隠す）。
function updateThemeApply(){
  const sel=document.getElementById('theme'), btn=document.getElementById('themeSave');
  if(!sel||!btn) return;
  btn.style.display = (sel.value && sel.value!==curDeckTheme()) ? '' : 'none';
}
async function load(){
  const r= await fetch('/api/md?deck='+encodeURIComponent(deck)); const j= await r.json();
  src.value = j.content || '';
  src.selectionStart = src.selectionEnd = 0;   // value代入はカーソルを末尾に置く＝追従ONだと開いた途端に最終ページへ飛ぶ。先頭(表紙)へ戻す
  savedContent=src.value; previewedContent=src.value; await loadThemes();
  // ディスク上の .preview.html は「表示専用のテーマ切替」で上書きされ、デッキ本文(frontmatter)の
  // テーマと食い違ったまま残ることがある（例: あるデッキを開いたのに別テーマの表示のまま）。
  // 開いた時点でデッキ本文のテーマから作り直して必ず一致させる。
  try{
    setBusy(true, 'プレビューを準備中…');
    const pr= await fetch('/api/preview',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({deck,content:effectiveContent(src.value)})});
    const pj= await pr.json(); showMermaidErrors(pj.mermaidErrors||[]);
  }catch(e){ /* 失敗時は既存の .preview.html をそのまま表示 */ }
  showPreview(); updateStatus();
  runHtmlHygiene('open');   // 開いた時点で検査（他ツール生成物の混入に気付けるように）
}
// プレビュー(bespoke)を指定ページへ。bespokeは location.hash（#N）でページ移動する。
let lastSent=0;
function gotoPreviewPage(n){
  if(n===lastSent) return; lastSent=n;
  try{ const w=prev.contentWindow; if(w){ w.location.hash='#'+n; } }catch(e){ /* 読み込み前等は無視 */ }
}
// いまプレビュー(iframe)が実際に表示しているページ番号。bespoke は location.hash(#N) にページを持つ。
// 取得できなければ（読み込み直後でhash未設定など）カーソル由来の curPage を代替に使う。
function currentPreviewPage(){
  try{ const n=parseInt((prev.contentWindow.location.hash||'').slice(1),10); if(n>0) return n; }catch(e){}
  return curPage;
}
// --- 逆同期: プレビューのページ移動（クリック/矢印）→ 左の編集カーソルを該当スライド先頭へ ---
// スライド n の本文先頭位置（frontmatterを除いた n-1 個目の --- 区切りの直後）。
function slideStartPos(text, n){
  const fm=text.match(/^---\\n[\\s\\S]*?\\n---\\n/); let bs=fm?fm[0].length:0;
  const skip=(p)=>{ while(p<text.length && (text[p]==='\\n'||text[p]==='\\r')) p++; return p; };  // 先頭の空行を飛ばして見出し行へ
  if(n<=1) return skip(bs);
  const re=/^---$/gm; re.lastIndex=bs; let m, c=0;
  while((m=re.exec(text))){ if(++c===n-1){ return skip(m.index+m[0].length); } }
  return bs;
}
// テキストエリアを指定位置の行が見えるようにスクロール（フォーカスは奪わない＝プレビュー操作を妨げない）。
function scrollSrcToPos(pos){
  const cs=getComputedStyle(src);
  const lh=parseFloat(cs.lineHeight)||(parseFloat(cs.fontSize)*1.5);
  // 折り返しを含めて pos の実画素Yを測る（行数×行高だと折り返し分ずれ、後ろのページほど累積する）。
  const mir=document.createElement('div'); const s=mir.style;
  s.position='absolute'; s.top='-9999px'; s.left='-9999px'; s.visibility='hidden';
  s.whiteSpace='pre-wrap'; s.overflowWrap='break-word'; s.wordWrap='break-word';
  s.fontFamily=cs.fontFamily; s.fontSize=cs.fontSize; s.fontWeight=cs.fontWeight;
  s.lineHeight=cs.lineHeight; s.letterSpacing=cs.letterSpacing; s.tabSize=cs.tabSize;
  s.padding='0'; s.border='0';
  s.width=(src.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight))+'px';
  mir.textContent=src.value.slice(0,pos);
  const mark=document.createElement('span'); mark.textContent='.'; mir.appendChild(mark);
  document.body.appendChild(mir);
  const y=mark.offsetTop; document.body.removeChild(mir);
  src.scrollTop=Math.max(0, y - lh);   // 対象スライドの先頭行を編集域の上方へ（1行分の余白）
}
function jumpEditorToSlide(n){
  const pos=slideStartPos(src.value, n);
  src.selectionStart=src.selectionEnd=pos; lastPos=pos;
  scrollSrcToPos(pos); updateStatus();   // updateStatus内の gotoPreviewPage は lastSent と一致＝no-op
}
// 逆同期は「プレビュー内のユーザー操作（クリック/キー）」を引き金にする。ポーリングだと
// 再読込中の一瞬の #1 や、こちらからのページ送りまで誤検知してカーソルを引き戻してしまうため。
// 送り/戻りボタン・矢印キー・全ページ一覧での選択は、いずれも iframe 内の click/keydown なので捕捉できる。
function syncFromPreview(){
  if(!follow.checked) return;
  const n=parseInt((prev.contentWindow.location.hash||'').slice(1),10);
  if(!n || n===lastSent) return; lastSent=n;
  jumpEditorToSlide(n);
}
function attachPrevUserNav(){
  try{
    const d=prev.contentDocument; if(!d) return;
    const onUser=()=>{ setTimeout(syncFromPreview, 120); };   // bespoke が hash を更新するのを待ってから拾う
    d.addEventListener('click', onUser, true);
    d.addEventListener('keydown', onUser, true);
  }catch(e){}
}
// 保存などでiframeを読み直したら、追従ONなら現在ページへ復帰（#1にリセットされるため）＋ユーザー操作の購読を張り直す
prev.addEventListener('load', ()=>{ hidePrevLoading(); setBusy(false); lastSent=0; attachPrevUserNav();
  // pendingPage があれば「表示中だったページ」を最優先で復帰（カーソルに追従させない）。無ければ従来どおり curPage。
  const target=(pendingPage!=null)?pendingPage:curPage;
  if(follow.checked || autoReload || pendingPage!=null) gotoPreviewPage(target);
  pendingPage=null; autoReload=false; });
follow.addEventListener('change', ()=>{ if(follow.checked){ lastSent=0; gotoPreviewPage(curPage); } });
// テーマ一覧をドロップダウンに。現在値は本文 frontmatter の theme: から
async function loadThemes(){
  const sel=document.getElementById('theme');
  const ts= await (await fetch('/api/themes')).json();
  sel.innerHTML='';
  for(const t of ts){ const o=document.createElement('option'); o.value=t; o.textContent=t; sel.appendChild(o); }
  const m=src.value.match(/^theme:\\s*(.+)$/m);
  if(m && ts.includes(m[1].trim())) sel.value=m[1].trim();
}
// 本文の theme: 行を t に差し替えた文字列を返す（本文自体は変更しない）
function swapTheme(text, t){
  return /^theme:\\s*.+$/m.test(text) ? text.replace(/^theme:\\s*.+$/m,'theme: '+t)
                                      : text.replace(/^---\\s*$/m,'---\\ntheme: '+t);
}
// src.value の代入はカーソルを末尾へ飛ばす（→追従ONだとプレビューが最終ページへジャンプ）。
// 先頭付近(theme:行)の長さ変化分だけ補正して、カーソル＝現在ページを保つ。
function setSrcKeepCursor(newText){
  const ss=src.selectionStart, se=src.selectionEnd, d=newText.length-src.value.length;
  src.value=newText;
  const fix=(p)=>Math.min(newText.length, Math.max(0, p+d));
  src.focus();   // 非フォーカスのまま選択位置を設定すると 0 にリセットされる環境があるため、当てる前にフォーカス
  src.selectionStart=fix(ss); src.selectionEnd=fix(se);
}
// 表示用ドロップダウンで選んだテーマを当てた「表示用コンテンツ」を返す（src.value自体は変えない）。
// 自動プレビュー/保存プレビューでも選択中テーマを保つため（テーマ切替後に編集すると元テーマに戻る不具合の対策）。
function effectiveContent(text){
  const sel=document.getElementById('theme'); const t=sel&&sel.value; if(!t) return text;
  const m=text.match(/^theme:\\s*(.+)$/m);
  return (m && m[1].trim()===t) ? text : swapTheme(text, t);
}
// ドロップダウンを本文の theme: に合わせる（保存後・読込後に呼ぶ）
function syncThemeDropdown(){
  const m=src.value.match(/^theme:\\s*(.+)$/m); if(!m) return;
  const sel=document.getElementById('theme'); const v=m[1].trim();
  if([...sel.options].some(o=>o.value===v)) sel.value=v;
}
// テーマ・ドロップダウン＝「プレビュー表示だけ」。デッキ(.md)は書き換えない＝git を汚さない。
document.getElementById('theme').onchange=async ()=>{
  const t=document.getElementById('theme').value;
  setBusy(true, 'テーマ "'+t+'" でプレビュー表示中…（デッキは未変更）');
  msg.textContent='プレビュー: '+t+'（表示のみ・未保存）';
  updateThemeApply();   // 本文と違うテーマを表示中なら「採用」リンクを出す
  try{
    const content=swapTheme(src.value, t);   // 一時的に theme を差し替えた本文でプレビューだけ生成
    const r= await fetch('/api/preview',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({deck,content})});
    const j= await r.json();
    if(!j.ok){ msg.textContent='プレビュー失敗: '+(j.error||''); setBusy(false); return; }
    showMermaidErrors(j.mermaidErrors||[]);
    showPreview();   // iframe 再読込 → load で setBusy(false)
  }catch(e){ msg.textContent='通信エラー: '+e.message; setBusy(false); }
};
// 「このテーマを採用」＝表示中テーマを本文(.md textarea)の theme: に書き込む＝未保存状態にする。
// ディスクには書かない（確定は「保存」ボタン）。プレビューは自動更新で新テーマを反映。
document.getElementById('themeSave').onclick=()=>{
  const t=document.getElementById('theme').value;
  const shown=currentPreviewPage();            // 採用前に「いま表示しているページ」を控える
  setSrcKeepCursor(swapTheme(src.value, t));   // カーソル＝現在ページを保つ（末尾ジャンプ防止）
  msg.textContent='テーマ "'+t+'" を採用しました（未保存）。「保存」で確定します';
  pendingPage=shown; autoReload=true;          // 再読込後も表示ページを維持（追従ON/OFFやカーソル位置に依らず遷移させない）
  updateStatus();
  scheduleAutoPreview();   // 未保存表示に切替＋プレビューだけ自動更新
};
document.getElementById('save').onclick = async ()=>{
  // プレビューで別テーマを表示中（＝未採用）のまま保存しようとしたら、採用するか確認する。
  // 黙って旧テーマで保存され「選んだのに戻る」誤解を防ぐ（テーマ切替自体は非破壊のまま）。
  const dd=document.getElementById('theme').value, dt=curDeckTheme(src.value);
  if(dd && dd!==dt){
    if(confirm('プレビュー表示中のテーマ「'+dd+'」はまだ採用していません。\\nこのテーマを採用して保存しますか？\\n\\n［OK］採用して保存　／　［キャンセル］保存を中止')){
      setSrcKeepCursor(swapTheme(src.value, dd)); updateThemeApply();
    } else { msg.textContent='保存を中止しました（テーマは未採用のまま）'; return; }
  }
  if(autoTimer){ clearTimeout(autoTimer); autoTimer=null; }   // 自動プレビュー予約を取り消し（保存が優先）
  saving=true;
  const heavyMsg = lastDeferred>0 ? '図を描画して保存しています…（初回は図ツールの取得で時間がかかることがあります／一度きり）' : '保存してプレビューを更新中… 少しお待ちください';
  setBusy(true, busyPending || heavyMsg); busyPending=null;
  msg.textContent='保存中…';
  const sending=src.value;
  try{
    const r= await fetch('/api/save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({deck,content:sending})});
    const j= await r.json();
    if(j.ok){ savedContent=sending; previewedContent=sending; lastDeferred=0; syncThemeDropdown(); }   // ディスク確定＝両基準を更新・図は描画済み
    msg.textContent = j.ok ? '保存しました' : ('プレビュー失敗: '+(j.error||''));
    showMermaidErrors(j.mermaidErrors||[]);   // 図の描画失敗があれば赤帯で表示（無ければ隠す）
    if(!j.ok) setBusy(false);        // 失敗時は iframe を読み直さない＝ここでロック解除
    showPreview(); updateStatus();   // 成功時は iframe load で setBusy(false)
    if(j.ok) runHtmlHygiene('save'); // 保存時に再検査（直したら消える／残っていれば気付ける）
  }catch(e){ msg.textContent='通信エラー: '+e.message; setBusy(false); }
  finally{ saving=false; }
};
// ===== 非ブロッキング自動プレビュー：入力が止まったら md は保存せずプレビューだけ再生成（画面はロックしない） =====
const AUTO_DELAY=650;
function scheduleAutoPreview(){ if(autoTimer) clearTimeout(autoTimer); autoTimer=setTimeout(runAutoPreview, AUTO_DELAY); }
async function runAutoPreview(){
  autoTimer=null;
  if(saving) return;                         // 明示保存中は譲る
  if(src.value===previewedContent) return;   // 変化なし
  if(autoInFlight){ autoPending=true; return; }   // 多重ビルド防止（終わったら再実行）
  autoInFlight=true;
  const sending=src.value;
  msg.textContent='プレビュー更新中…';
  try{
    const r= await fetch('/api/preview',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({deck,content:effectiveContent(sending)})});
    const j= await r.json();
    if(saving) return;                       // 途中で保存が走ったら破棄（保存側が反映）
    if(j.ok){
      previewedContent=sending;
      showMermaidErrors(j.mermaidErrors||[]);
      const def=j.mermaidDeferred||0;   // 自動プレビューで未描画にした図の数（保存すると描画される）
      lastDeferred=def;                 // 保存時のメッセージ判定に使う（描画で待つ可能性を予告）
      msg.textContent = def>0 ? ('プレビュー更新（図 '+def+' 件は「保存」で描画）') : 'プレビュー最新（未保存）';
      autoReload=true; showPreview(); updateStatus();   // 反映後はカーソルのページへ寄せる
    }else{ msg.textContent='プレビュー失敗: '+(j.error||''); }
  }catch(e){ msg.textContent='通信エラー: '+e.message; }
  finally{
    autoInFlight=false;
    if(autoPending){ autoPending=false; if(src.value!==previewedContent) scheduleAutoPreview(); }   // 入力が続いていたら再予約
  }
}
document.getElementById('pdf').onclick = async (e)=>{
  const b=e.target; b.disabled=true; msg.textContent='PDF作成中…（少し待ってください）';
  const r= await fetch('/api/export',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({deck})});
  const j= await r.json(); b.disabled=false;
  if(j.error){ msg.textContent=j.error; return; }
  msg.textContent='PDFができました → '; const a=document.createElement('a');
  a.href=j.url; a.textContent='ダウンロード'; a.target='_blank'; msg.appendChild(a);
};
document.getElementById('pptx').onclick = async (e)=>{
  const b=e.target; b.disabled=true;
  // 初回は部品の自動取得で少し時間がかかる旨を先に伝える（無言で固まらないように）。
  msg.textContent='PPTX作成中…（初回のみ部品を取得するためネット接続が必要・少し待ってください）';
  const r= await fetch('/api/export-pptx',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({deck})});
  const j= await r.json(); b.disabled=false;
  if(j.error){ msg.textContent=j.error; return; }
  msg.textContent='PPTX(β)ができました → '; const a=document.createElement('a');
  a.href=j.url; a.textContent='ダウンロード'; a.target='_blank'; msg.appendChild(a);
};
// 直近のカーソル位置を覚える（ボタンを押すとtextareaのフォーカスが外れるため）
let lastPos = null;
['click','keyup','select','input'].forEach((ev)=>src.addEventListener(ev,()=>{ lastPos = src.selectionStart; updateStatus(); }));
src.addEventListener('input', scheduleAutoPreview);   // 入力が止まったら自動でプレビューだけ再生成（保存はしない）
// カーソル（直近の位置／未操作なら末尾）に挿入し、その場所までスクロール
function insertAtCursor(text){
  const s=src;
  const pos = (document.activeElement===s) ? s.selectionStart : (lastPos==null ? s.value.length : lastPos);
  s.value = s.value.slice(0,pos) + text + s.value.slice(pos);
  const end = pos + text.length; lastPos = end;
  s.focus(); s.selectionStart=s.selectionEnd=end;
  // 挿入箇所が見えるようスクロール
  const lh = parseInt(getComputedStyle(s).lineHeight) || 20;
  const line = s.value.slice(0,end).split('\\n').length;
  s.scrollTop = Math.max(0, line*lh - s.clientHeight/2);
  updateStatus(); scheduleAutoPreview();   // ボタン挿入はinputが出ないので明示的に自動プレビューを起動
}
// カーソル位置(pos)が属するスライドの本文範囲を返す。contentStart..sepStart が本文、
// sepStart は次の区切り(---)の位置（最後のスライドは末尾）。frontmatter内は先頭スライド扱い。
function findSlideRange(text, pos){
  const fm = text.match(/^---\\n[\\s\\S]*?\\n---\\n/);
  const bodyStart = fm ? fm[0].length : 0;
  if(pos < bodyStart) pos = bodyStart;
  const re = /^---$/gm; re.lastIndex = bodyStart;
  const seps = []; let m;
  while((m = re.exec(text))) seps.push({start:m.index, end:m.index+m[0].length});
  let cs = bodyStart;
  for(let i=0;i<seps.length;i++){
    if(pos <= seps[i].start) return {contentStart:cs, sepStart:seps[i].start, isLast:false};
    cs = seps[i].end;
  }
  return {contentStart:cs, sepStart:text.length, isLast:true};
}
// 複製スライド内の svg参照のうち、同名 .mmd があるものをインライン mermaid フェンスに戻す（編集可能化）。
// 画像オプション（![h:440](…)）はフェンスの info string に引き継ぐ。元スライドは触らない＝マスターは保全。
async function restoreMermaidRefs(text){
  const re=/!\\[([^\\]]*)\\]\\(([^)\\s]+\\.svg)\\)/g;
  const matches=[...text.matchAll(re)];
  if(!matches.length) return text;
  let out=text, restored=0;
  for(const mt of matches){
    const opts=(mt[1]||'').trim(), p=mt[2];
    try{
      const r=await fetch('/api/mmd-src?deck='+encodeURIComponent(deck)+'&path='+encodeURIComponent(p));
      if(!r.ok) continue;
      const j=await r.json(); if(!j.mmd) continue;
      const fence='\\n\\n\`\`\`mermaid'+(opts?' '+opts:'')+'\\n'+j.mmd.replace(/\\s+$/,'')+'\\n\`\`\`\\n';
      out=out.replace(mt[0], fence); restored++;
    }catch(e){ /* 取得失敗時は画像参照のまま */ }
  }
  if(restored) msg.textContent='複製スライド内の図 '+restored+' 件を編集可能な Mermaid に戻しました';
  return out;
}
// 現在のスライドを丸ごと複製し、直後に新しいスライドとして挿入。カーソルは複製側の先頭へ。
async function duplicateCurrentSlide(){
  const text=src.value;
  const pos=(document.activeElement===src)?src.selectionStart:(lastPos==null?text.length:lastPos);
  const r=findSlideRange(text,pos);
  let slide=text.slice(r.contentStart, r.sepStart).replace(/^\\n+|\\n+$/g,'');   // 外側の空行だけ除去
  if(!slide.trim()){ msg.textContent='複製できるスライドが見つかりません'; return; }
  // 先頭の見出し(# 〜)に「(コピー)」を付与（既に付いていれば二重化しない）
  slide=slide.replace(/^(#{1,6}[ \\t]+[^\\n]*?)[ \\t]*$/m, (mm,h)=> /コピー/.test(h) ? mm : h+' (コピー)');
  slide=await restoreMermaidRefs(slide);   // svg参照→編集可能なMermaidフェンスへ（同名.mmdがある図のみ）
  const pre = r.isLast ? '\\n\\n---\\n\\n' : '---\\n\\n';   // 区切り＋複製本文の前置き
  const post = r.isLast ? '\\n' : '\\n\\n';
  const insert = pre + slide + post;
  const insertPos = r.isLast ? text.length : r.sepStart;
  src.value = text.slice(0,insertPos) + insert + text.slice(insertPos);
  const cur = insertPos + pre.length;     // 複製スライド本文の先頭へカーソル
  lastPos = cur; src.focus(); src.selectionStart=src.selectionEnd=cur;
  const lh=parseInt(getComputedStyle(src).lineHeight)||20;
  const line=src.value.slice(0,cur).split('\\n').length;
  src.scrollTop=Math.max(0, line*lh - src.clientHeight/2);
  updateStatus(); scheduleAutoPreview();   // 複製もinputが出ないので明示的に自動プレビューを起動
  msg.textContent='現在のスライドを複製しました（自動でプレビュー更新）';
}
function makeTable(cols,rows){
  const head = Array.from({length:cols}, (_,i)=>' 見出し'+(i+1)+' ').join('|');
  const sep  = Array.from({length:cols}, ()=>'---').join('|');
  const row  = Array.from({length:cols}, ()=>' … ').join('|');
  let body=''; for(let r=0;r<rows;r++) body+='|'+row+'|\\n';
  return '\\n\\n|'+head+'|\\n|'+sep+'|\\n'+body;
}
function togglePanel(id){
  const me=document.getElementById(id);
  ['fzPanel','tblPanel','mmPanel','newPanel'].forEach((x)=>{ if(x!==id) document.getElementById(x).style.display='none'; });
  me.style.display = me.style.display==='flex' ? 'none' : 'flex';
}
/* ===== 表編集ストリップ：カーソル位置のMarkdown表を列/行操作（textarea書き換えのみ＝buildは保存時だけ） ===== */
function tblSplitRow(line){ return line.trim().replace(/^\\|/,'').replace(/\\|$/,'').split('|').map((c)=>c.trim()); }
function tblJoinRow(cells){ return '| '+cells.join(' | ')+' |'; }
function tblIsSep(cells){ return cells.length>0 && cells.every((c)=>/^:?-{1,}:?$/.test(c.trim())); }
// カーソル行を含む連続した「| …」行の塊を表として検出。2行目が区切り行でなければ表でない＝null。
function tableAtCursor(){
  const text=src.value;
  const pos=(document.activeElement===src)?src.selectionStart:(lastPos==null?text.length:lastPos);
  const lines=text.split('\\n');
  let off=0, li=0;
  for(; li<lines.length; li++){ const len=lines[li].length+1; if(pos<off+len) break; off+=len; }
  if(li>=lines.length) li=lines.length-1;
  const colInLine=pos-off;
  const isPipe=(s)=> s!=null && /^\\s*\\|/.test(s) && s.trim()!=='';
  if(!isPipe(lines[li])) return null;
  let top=li; while(top>0 && isPipe(lines[top-1])) top--;
  let bot=li; while(bot<lines.length-1 && isPipe(lines[bot+1])) bot++;
  if(bot-top<1) return null;
  const block=lines.slice(top,bot+1);
  if(!tblIsSep(tblSplitRow(block[1]))) return null;
  let blockStart=0; for(let k=0;k<top;k++) blockStart+=lines[k].length+1;
  const blockEnd=blockStart+block.join('\\n').length;
  const curLine=lines[li];
  const pipesBefore=(curLine.slice(0,colInLine).match(/\\|/g)||[]).length;
  const header=tblSplitRow(block[0]);
  const cols=header.length;
  let col=Math.max(0, pipesBefore-1); col=Math.min(col, cols-1);
  return { text, top, blockStart, blockEnd, block, col, rowInBlock: li-top, cols };
}
function tblToMatrix(block){
  const header=tblSplitRow(block[0]);
  const n=header.length;
  const fix=(a)=>{ const b=a.slice(); while(b.length<n) b.push(''); return b.slice(0,n); };
  const sep=tblSplitRow(block[1]).map((c)=>c.trim()||'---');
  return { header:fix(header), sep:fix(sep).map((c)=>c||'---'), rows:block.slice(2).map((r)=>fix(tblSplitRow(r))) };
}
function tblMatrixToText(m){ return [tblJoinRow(m.header), tblJoinRow(m.sep), ...m.rows.map(tblJoinRow)].join('\\n'); }
// 新しい表テキスト内で (行index, 列index) のセル内容先頭の絶対オフセットを求める
function tblCellOffset(blockStart, blockText, lineIdx, col){
  const bl=blockText.split('\\n'); lineIdx=Math.max(0,Math.min(lineIdx, bl.length-1));
  let off=blockStart; for(let k=0;k<lineIdx;k++) off+=bl[k].length+1;
  const line=bl[lineIdx]; let pipes=0, idx=0;
  for(; idx<line.length; idx++){ if(line[idx]==='|'){ pipes++; if(pipes===col+1){ idx++; break; } } }
  while(idx<line.length && line[idx]===' ') idx++;
  return off+idx;
}
function applyTableOp(op){
  const t=tableAtCursor(); if(!t){ return; }
  const m=tblToMatrix(t.block);
  let col=t.col, rowInBlock=t.rowInBlock;
  const dataIdx = rowInBlock>=2 ? rowInBlock-2 : -1;   // データ行のindex（header/sepは-1）
  const eachCol=(fn)=>{ fn(m.header); fn(m.sep); m.rows.forEach(fn); };
  if(op==='colAddL'){ eachCol((a)=>a.splice(col,0,'')); m.sep[col]='---'; m.header[col]='見出し'; }
  else if(op==='colAddR'){ col=col+1; eachCol((a)=>a.splice(col,0,'')); m.sep[col]='---'; m.header[col]='見出し'; }
  else if(op==='colDel'){ if(m.header.length<=1) return; eachCol((a)=>a.splice(col,1)); col=Math.min(col, m.header.length-1); }
  else if(op==='colLeft'){ if(col<=0) return; eachCol((a)=>{ const x=a[col];a[col]=a[col-1];a[col-1]=x; }); col--; }
  else if(op==='colRight'){ if(col>=m.header.length-1) return; eachCol((a)=>{ const x=a[col];a[col]=a[col+1];a[col+1]=x; }); col++; }
  else if(op==='rowAdd'){ const at=dataIdx>=0?dataIdx+1:0; m.rows.splice(at,0,m.header.map(()=>'')); rowInBlock=at+2; }
  else if(op==='rowDel'){ if(dataIdx<0||m.rows.length===0) return; m.rows.splice(dataIdx,1); rowInBlock = m.rows.length===0 ? 0 : Math.min(rowInBlock, m.rows.length+1); }
  const newBlock=tblMatrixToText(m);
  src.value = t.text.slice(0,t.blockStart) + newBlock + t.text.slice(t.blockEnd);
  const pos=tblCellOffset(t.blockStart, newBlock, rowInBlock, col);
  lastPos=pos; src.focus(); src.selectionStart=src.selectionEnd=pos;
  updateStatus(); scheduleAutoPreview();   // 表操作もinputが出ないので明示的に自動プレビューを起動
  msg.textContent='表を更新しました（自動でプレビュー更新）';
}
// カーソルが表の中にある時だけストリップを表示
function refreshTableStrip(){
  const strip=document.getElementById('tblStrip'); if(!strip) return;
  strip.style.display = tableAtCursor() ? 'flex' : 'none';
}
document.querySelectorAll('#tblStrip .tbl').forEach((b)=>{
  b.addEventListener('mousedown',(e)=>e.preventDefault());   // textareaのフォーカス/選択を保持
  b.onclick=()=>applyTableOp(b.dataset.op);
});
const SNIP = {
  slide:    '\\n\\n---\\n\\n# 見出し\\n\\n- 箇条書き\\n',
  section:  '\\n\\n---\\n\\n<!-- _class: section -->\\n\\n# セクション\\n## サブタイトル\\n',
  cols:     '\\n\\n<div class="columns">\\n<div>\\n\\n### 左\\n- 項目\\n\\n</div>\\n<div>\\n\\n### 右\\n- 項目\\n\\n</div>\\n</div>\\n',
  bullets:  '\\n- 箇条書き1\\n- 箇条書き2\\n',
  mermaid:  '\\n\\n\`\`\`mermaid\\nflowchart LR\\n  A[開始] --> B[処理] --> C[完了]\\n\`\`\`\\n',
};
// Mermaid図の種類別テンプレート（「Mermaid図」ボタン→パネルで選択して挿入）
const MM_SNIP = {
  flow:     '\\n\\n\`\`\`mermaid\\nflowchart LR\\n  A[開始] --> B[処理] --> C[完了]\\n\`\`\`\\n',
  sequence: '\\n\\n\`\`\`mermaid\\nsequenceDiagram\\n  participant U as 利用者\\n  participant S as システム\\n  U->>S: リクエスト\\n  S-->>U: レスポンス\\n\`\`\`\\n',
  gantt:    '\\n\\n\`\`\`mermaid\\ngantt\\n  title マスタースケジュール\\n  dateFormat YYYY-MM-DD\\n  section フェーズ1\\n  要件定義 :a1, 2026-01-01, 14d\\n  設計     :a2, after a1, 21d\\n  section フェーズ2\\n  実装     :b1, after a2, 30d\\n\`\`\`\\n',
  state:    '\\n\\n\`\`\`mermaid\\nstateDiagram-v2\\n  [*] --> 受付\\n  受付 --> 処理中\\n  処理中 --> 完了\\n  完了 --> [*]\\n\`\`\`\\n',
  class:    '\\n\\n\`\`\`mermaid\\nclassDiagram\\n  class 利用者 {\\n    +氏名\\n    +申込()\\n  }\\n  利用者 --> 申込書\\n\`\`\`\\n',
  er:       '\\n\\n\`\`\`mermaid\\nerDiagram\\n  顧客 ||--o{ 注文 : 行う\\n  注文 ||--|{ 注文明細 : 含む\\n  商品 ||--o{ 注文明細 : 対象\\n\`\`\`\\n',
  mindmap:  '\\n\\n\`\`\`mermaid\\nmindmap\\n  root((プロジェクト))\\n    計画\\n      スケジュール\\n      体制\\n    実行\\n      開発\\n      テスト\\n\`\`\`\\n',
  timeline: '\\n\\n\`\`\`mermaid\\ntimeline\\n  title プロジェクト年表\\n  2026-Q1 : 要件定義\\n  2026-Q2 : 設計 : 実装\\n  2026-Q3 : テスト\\n\`\`\`\\n',
  journey:  '\\n\\n\`\`\`mermaid\\njourney\\n  title 申込のユーザージャーニー\\n  section 申込\\n    フォーム入力: 3: 利用者\\n    送信: 4: 利用者\\n  section 審査\\n    確認: 2: 担当者\\n\`\`\`\\n',
  pie:      '\\n\\n\`\`\`mermaid\\npie title 構成比\\n  \"区分A\" : 40\\n  \"区分B\" : 35\\n  \"区分C\" : 25\\n\`\`\`\\n',
  bar:      '\\n\\n\`\`\`mermaid\\nxychart-beta\\n  title \"月別売上\"\\n  x-axis [\"1月\", \"2月\", \"3月\", \"4月\"]\\n  y-axis \"売上(百万円)\" 0 --> 100\\n  bar [40, 55, 60, 80]\\n\`\`\`\\n',
  line:     '\\n\\n\`\`\`mermaid\\nxychart-beta\\n  title \"推移\"\\n  x-axis [\"1月\", \"2月\", \"3月\", \"4月\"]\\n  y-axis \"件数\" 0 --> 100\\n  line [20, 45, 50, 75]\\n\`\`\`\\n',
  quadrant: '\\n\\n\`\`\`mermaid\\nquadrantChart\\n  title 重要度と緊急度\\n  x-axis 低い --> 高い\\n  y-axis 低い --> 高い\\n  quadrant-1 すぐ対応\\n  quadrant-2 計画\\n  quadrant-3 様子見\\n  quadrant-4 委任\\n  施策A: [0.3, 0.6]\\n  施策B: [0.7, 0.8]\\n\`\`\`\\n',
};
document.querySelectorAll('.ins').forEach((btn)=>{
  btn.onclick=()=>{
    const k=btn.dataset.k;
    if(k==='image'){ document.getElementById('file').click(); return; }
    if(k==='table'){ togglePanel('tblPanel'); return; }
    if(k==='fusen'){ togglePanel('fzPanel'); return; }
    if(k==='mermaid'){ togglePanel('mmPanel'); return; }
    if(k==='dupSlide'){ duplicateCurrentSlide(); return; }
    if(k==='slide'){ togglePanel('newPanel'); newCountToggle(); return; }   // 種類選択パネルを開く
    insertAtCursor(SNIP[k]);
  };
});
// 付箋パネル: 位置プリセット選択
let fzTop=320, fzLeft=515;
document.querySelectorAll('#fzGrid .fz').forEach((b)=>{
  b.onclick=()=>{ document.querySelectorAll('#fzGrid .fz').forEach((x)=>x.classList.remove('sel'));
    b.classList.add('sel'); fzTop=b.dataset.t; fzLeft=b.dataset.l; };
});
document.getElementById('fzClose').onclick=()=>{ document.getElementById('fzPanel').style.display='none'; };
document.getElementById('fzInsert').onclick=()=>{
  const text=(document.getElementById('fzText').value||'メモ');
  const color=document.getElementById('fzColor').value;
  const size=document.getElementById('fzSize').value;
  const cls=('fusen '+color+(size?' '+size:'')).trim();
  insertAtCursor('\\n\\n<div class="'+cls+'" style="top:'+fzTop+'px; left:'+fzLeft+'px;">'+text+'</div>\\n');
  document.getElementById('fzPanel').style.display='none';
  msg.textContent='付箋を挿入しました（保存でプレビュー反映）';
};
// 表パネル
document.getElementById('tblClose').onclick=()=>{ document.getElementById('tblPanel').style.display='none'; };
document.getElementById('tblInsert').onclick=()=>{
  const cols=parseInt(document.getElementById('tblCols').value)||3;
  const rows=parseInt(document.getElementById('tblRows').value)||2;
  insertAtCursor(makeTable(cols,rows));
  document.getElementById('tblPanel').style.display='none';
  msg.textContent='表を挿入しました（保存でプレビュー反映）';
};
// Mermaidパネル：種類を選んで雛形を挿入
document.getElementById('mmClose').onclick=()=>{ document.getElementById('mmPanel').style.display='none'; };
document.getElementById('mmInsert').onclick=()=>{
  const sel=document.getElementById('mmType');
  insertAtCursor(MM_SNIP[sel.value]||MM_SNIP.flow);
  document.getElementById('mmPanel').style.display='none';
  msg.textContent='Mermaid図（'+sel.selectedOptions[0].text+'）を挿入しました（保存でプレビュー反映）';
};
// 新規スライド・パネル：種類（表紙/中表紙/背表紙/リード文＋コンテンツ）を選んで雛形を1枚追加
function newCountToggle(){   // 「リード文＋コンテンツ」の時だけコンテンツ数プルダウンを見せる
  const t=document.getElementById('newType').value;
  document.getElementById('newCountWrap').style.display = (t==='lead') ? '' : 'none';
}
function buildContentBoxes(n){   // content-wrapper 内に content-box を n 個（base の2カラム相当の枠）
  let s='';
  for(let i=1;i<=n;i++){ s+='<div class="content-box">\\n\\n### 見出し'+i+'\\n\\n- 項目\\n\\n</div>\\n'; }
  return s;
}
// スライド本文（区切り --- は付けない。挿入側でスライド境界に付ける）
function newSlideBody(type,count){
  if(type==='title')   return '<!-- _class: title -->\\n\\n# タイトル\\n\\n## サブタイトル・日付';
  if(type==='section') return '<!-- _class: section -->\\n\\n# セクション\\n\\n## サブタイトル';
  if(type==='closing') return '<!-- _class: closing -->\\n\\n# ご清聴ありがとうございました';
  // 既定: リード文＋コンテンツ（見出し＋.lead-area＋.content-wrapper に content-box を count 個）
  return '# 見出し\\n\\n<div class="lead-area">\\n\\nここにリード文（要点を1〜2行で）。\\n\\n</div>\\n\\n<div class="content-wrapper">\\n'+buildContentBoxes(count)+'</div>';
}
// カーソルのあるスライドの「直後」に新スライドを1枚挿入（カーソル位置に直挿ししてページを壊さない）。
// 区切りの付け方・カーソル移動は duplicateCurrentSlide と同じ流儀。
function insertSlideAfterCurrent(body){
  const text=src.value;
  const pos=(document.activeElement===src)?src.selectionStart:(lastPos==null?text.length:lastPos);
  const r=findSlideRange(text,pos);
  const pre  = r.isLast ? '\\n\\n---\\n\\n' : '---\\n\\n';   // 区切り＋新本文の前置き
  const post = r.isLast ? '\\n' : '\\n\\n';
  const insert = pre + body + post;
  const insertPos = r.isLast ? text.length : r.sepStart;    // 次の --- の直前（＝現在スライドの末尾）
  src.value = text.slice(0,insertPos) + insert + text.slice(insertPos);
  const cur = insertPos + pre.length;                       // 新スライド本文の先頭へカーソル
  lastPos = cur; src.focus(); src.selectionStart=src.selectionEnd=cur;
  const lh=parseInt(getComputedStyle(src).lineHeight)||20;
  const line=src.value.slice(0,cur).split('\\n').length;
  src.scrollTop=Math.max(0, line*lh - src.clientHeight/2);
  updateStatus(); scheduleAutoPreview();
}
document.getElementById('newType').onchange=newCountToggle;
document.getElementById('newClose').onclick=()=>{ document.getElementById('newPanel').style.display='none'; };
document.getElementById('newInsert').onclick=()=>{
  const t=document.getElementById('newType').value;
  const c=parseInt(document.getElementById('newCount').value)||2;
  insertSlideAfterCurrent(newSlideBody(t,c));   // カーソルのあるスライドの直後に追加
  document.getElementById('newPanel').style.display='none';
  const label={title:'表紙',section:'中表紙',closing:'背表紙',lead:'リード文＋'+c+'コンテンツ'}[t]||'スライド';
  msg.textContent='「'+label+'」スライドを現在のスライドの直後に追加しました（保存でプレビュー反映）';
};
newCountToggle();
// 画像アップロード → assets/ に保存し ![w:1000]() を挿入（既定はほぼ全幅。2カラムは w:520 程度に手で調整）
document.getElementById('file').onchange = async (e)=>{
  const f=e.target.files[0]; if(!f) return;
  msg.textContent='画像をアップロード中…';
  const r= await fetch('/api/upload?deck='+encodeURIComponent(deck)+'&name='+encodeURIComponent(f.name),{method:'POST',body:f});
  const j= await r.json(); e.target.value='';
  if(j.error){ msg.textContent=j.error; return; }
  insertAtCursor('\\n\\n![w:1000]('+j.file+')\\n'); msg.textContent='画像を挿入（幅は ![w:数値] で調整。2カラムは w:520 目安）';
};
document.getElementById('rename').onclick = async ()=>{
  const nn = prompt('新しいデッキ名を入力してください', deck);
  if(!nn || nn.trim()===deck) return;
  msg.textContent='名前を変更中…';
  const r= await fetch('/api/rename',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({deck,newName:nn.trim()})});
  const j= await r.json();
  if(j.error){ msg.textContent=j.error; return; }
  location.href='/edit?deck='+encodeURIComponent(j.name);
};
// Ctrl/Cmd+S で保存
document.addEventListener('keydown',(e)=>{ if((e.metaKey||e.ctrlKey)&&e.key==='s'){e.preventDefault();document.getElementById('save').click();}});
// 未保存のまま「閉じる/リロード」しようとしたら警告（自動プレビューは保存ではないため保存忘れを防ぐ）。
// ただしアプリ内の「← 一覧へ」遷移では、この汎用ダイアログ（「このページから離れますか？」）は出さず、
// 下の toList ハンドラで分かりやすい日本語の確認に置き換える（leaving=true で本ガードを抑止）。
let leaving=false;
window.addEventListener('beforeunload',(e)=>{ if(!leaving && src.value!==savedContent){ e.preventDefault(); e.returnValue=''; } });
// 「← 一覧へ」: 未保存なら確認。未保存でなくても、HTML警告帯が出たまま（＝未対応で×もしていない）なら
// 閉じる前にもう一度気付けるよう確認する（×で消していれば nag しない）。
document.getElementById('toList').addEventListener('click',(e)=>{
  var dirty = src.value!==savedContent;
  var htmlWarnOn = document.getElementById('htmlWarn').style.display!=='none';
  if(dirty || htmlWarnOn){
    e.preventDefault();
    var m2 = dirty
      ? '未保存の変更があります。保存せずに一覧へ戻りますか？\\n（キャンセルして「保存」で確定できます）'
      : 'このデッキには、Markdownで書ける箇所がHTMLで残っています。\\n（上の警告帯「AIへの指示をコピー」で直せます）\\n\\nこのまま一覧へ戻りますか？';
    if(confirm(m2)){ leaving=true; location.href='/'; }
  }
  // 未保存でなく警告も無い（または×で閉じた）なら既定の遷移（何も確認しない）
});
// 「■ 終了」ボタン（QUIT_JS）が終了確認の前に呼ぶフック：未保存なら警告文を前置きする
window.__beforeQuit=function(){ return (src.value!==savedContent) ? '⚠ 未保存の変更があります。保存せずに終了すると、その変更は失われます。\\n\\n' : ''; };
load();
${QUIT_JS}
${HEARTBEAT_JS}
</script></body></html>`;
