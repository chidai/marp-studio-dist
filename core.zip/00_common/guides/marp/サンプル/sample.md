---
marp: true
theme: acme
paginate: true
footer: '© 2026 Sample Co.'
---

<!-- _class: cover -->
<!-- _paginate: false -->
<!-- doc-id: SAMPLE -->
<!-- ↑ 実際の文書では正本マップ decks/_common/doc-map.mmd のノードID に置き換える -->
<!-- 表紙背景はテーマが提供（--title-bg）。MDで ![bg] は指定しない。 -->

# Marp サンプルデッキ
## 共通テーマ（base ＋ 顧客プロファイル）のレイアウト見本
### Marp Studio の「テーマ」を切り替えて acme / globex / initech を見比べてください

---

<!-- _class: section -->

# 本書について

---

# 本書の位置づけ

<div class="lead-area">標準の前付け①：ドキュメント群の中での位置（<b style="color:#198038">緑＝本書</b>）。実際の文書では <code>docmap</code> コマンドが正本から自動生成します。</div>

![doc-map](assets/doc-map.svg)

---

# 本書の役割（目的・ゴール）

<div class="lead-area">標準の前付け②：この文書が<strong>定義すること</strong>／読了後の<strong>ゴール</strong>／<strong>スコープ外</strong>。</div>

<div class="columns">
<div>

**定義する**
- （例）共通テーマのレイアウトと標準の立て付け

</div>
<div>

**読み終えると（ゴール）**
- （例）標準構成と使えるレイアウトが分かる

</div>
</div>

> **スコープ外**：（例）個別文書の内容そのもの

---

# 目次

<div class="lead-area">標準の前付け③：章とテーマを表で示す。</div>

| 章 | テーマ |
|---|---|
| 1. レイアウト基本 | 表紙・中扉・カラム・リード・付箋・強調 |
| 2. 図はコードで | Mermaid／draw.io SVG |
| 補足 | なぜ Mermaid / SVG か |

> 本文スライドはロゴが右上・ページ番号が左下に自動表示されます。

---

# 用語・凡例

<div class="lead-area">標準の前付け④：頻出用語と凡例を先に押さえる。</div>

| 用語 | 意味 |
|---|---|
| レイアウトマスター | テーマが提供するスライドの型（`_class` で指定） |
| Mermaid | テキストで書く図（ビルド時に自動でSVG化） |

> **凡例**：<span class="good">good</span>＝推奨 ／ <span class="bad">bad</span>＝非推奨。

---

<!-- _class: section -->

# セクション 1
## レイアウトマスターの基本

---

# タイトルとコンテンツ（標準レイアウト）

- 最も標準的なレイアウト。`# 見出し` ＋ 箇条書きだけで成立します
- 共通テーマが見出し下の罫線・余白・フォントを自動で整えます
- **HTMLを書かなくても崩れない**よう調整済み（プレーンMarkdownでOK）

ポイント:

- 1スライドに詰め込みすぎない（固定 1280×720・はみ出しは隠れる）
- 図や表は次ページに分割する

---

# 2カラム / 比較（`.columns`）

<div class="columns">
<div>

### As-Is（現行業務）
- 手作業中心の運用
- 部門ごとに分散したデータ
- 紙・表計算での管理

</div>
<div>

### To-Be（新基幹システム）
- 業務プロセスを標準化
- データを一元管理
- 自動化・可視化を推進

</div>
</div>

> `<div class="columns">` の中に2つの `<div>` を置くと左右2カラムになります（HTML有効時）。

---

# リード文 + コンテンツボックス

<div class="lead-area">
要件定義工程のゴールは「業務要件の確定」と「リスクの早期可視化」です。
</div>

<div class="content-wrapper">
<div class="content-box">

### インプット
- 現行業務ヒアリング
- 既存ドキュメント
- 先行事例の知見

</div>
<div class="content-box">

### アウトプット
- 要件定義書
- 課題・リスク一覧
- 構築計画ドラフト

</div>
</div>

---

# 付箋ブレスト（`.fusen`）

<div class="fusen" style="top:120px; left:60px;">業務要件の確定が肝</div>
<div class="fusen blue" style="top:160px; left:340px;">既存データの移行方針</div>
<div class="fusen pink" style="top:240px; left:120px;">テストデータ確保</div>
<div class="fusen green" style="top:300px; left:420px;">権限・セキュリティ設計</div>
<div class="fusen yellow small" style="top:380px; left:200px;">拠点間の業務差異</div>

> `.fusen` は絶対配置の付箋。`blue` / `pink` / `green` / `yellow`、`small` / `large` / `wide` などのバリエーションあり。

---

# 強調と表（`.good` / `.bad` / table）

構築方式の比較:

| 方式 | 工数 | リスク | 判定 |
|---|---|---|---|
| フルスクラッチ開発 | 大 | <span class="bad">高</span> | 不採用 |
| パッケージ＋個別開発 | 中 | <span class="good">中</span> | <span class="good">採用</span> |
| 現行踏襲のみ | 小 | <span class="bad">高（課題が残存）</span> | 不採用 |

- <span class="good">good</span>：緑の強調 / <span class="bad">bad</span>：赤の強調

---

<!-- _class: section -->

# セクション 2
## 図はコードで描く（Mermaid / SVG）

---

# 図：Mermaid（テキスト → 図を自動生成）

![構築フロー](assets/flow-build.svg)

ソース（`assets/flow-build.mmd`）:

```mermaid
flowchart LR
  A[要件定義] --> B{設計レビュー}
  B -->|指摘あり| C[設計修正] --> B
  B -->|OK| D[実装] --> E[テスト]
  E -->|不具合| F[修正] --> E
  E -->|合格| G[受入テスト] --> H[本番リリース]
```

> Marp標準はMermaidを描画しないため、`mmdc` で **SVGに事前変換**して貼っています（ガイド 5-2 の方式A）。

---

# 図：Mermaid の種類（シーケンス / 状態遷移）

<div class="lead-area">「Mermaid図」ボタンから種類を選んで挿入できます（フローチャートは前ページ）。</div>

<div class="columns">
<div>

### シーケンス図
```mermaid h:240
sequenceDiagram
  participant U as 利用者
  participant S as システム
  U->>S: リクエスト
  S-->>U: レスポンス
```

</div>
<div>

### 状態遷移図
```mermaid h:240
stateDiagram-v2
  [*] --> 受付
  受付 --> 処理中
  処理中 --> 完了
  完了 --> [*]
```

</div>
</div>

---

# 図：ガントチャート（マスタースケジュール）

```mermaid h:300
gantt
  title マスタースケジュール
  dateFormat YYYY-MM-DD
  section フェーズ1
  要件定義 :a1, 2026-01-01, 14d
  設計     :a2, after a1, 21d
  section フェーズ2
  実装     :b1, after a2, 30d
```

> スケジュール調整は、このスライドを**複製**してから日付を直すと安全です（複製時に図が編集可能な状態へ戻ります）。

---

# 図：クラス図 / 円グラフ

<div class="columns">
<div>

### クラス図
```mermaid h:240
classDiagram
  class 利用者 {
    +氏名
    +申込()
  }
  利用者 --> 申込書
```

</div>
<div>

### 円グラフ
```mermaid h:240
pie title 構成比
  "区分A" : 40
  "区分B" : 35
  "区分C" : 25
```

</div>
</div>

---

# 図：draw.io SVG（ベクター）

![システム構成図](assets/architecture.drawio.svg)

> draw.io から **SVGエクスポート**した図を `![]()` で貼り付け。ベクターなので拡大しても劣化しません。

---

<!-- _class: section -->

# 補足
## なぜ Mermaid / SVG なのか

---

# Mermaid / SVG を主流にする理由

<div class="columns">
<div>

### 運用面
- **差分管理しやすい**（テキスト＝Git差分が読める）
- 修正が速い（図形を手で動かさない）
- 体裁がテーマで揃う

</div>
<div>

### gen AI 連携
- 図の中身が**テキストとして機械可読**
- AIが構造を解釈・要約・検証できる
- PNGスクショと違い**OCR不要**で正確

</div>
</div>

<div class="lead-area">
結論: 「絵」はバイナリ画像ではなく、Mermaid / draw.io SVG のような<strong>テキスト由来のベクター</strong>で持つ。
</div>

---

<!-- _class: closing -->
<!-- _paginate: false -->

# まとめ
## レイアウトは class、図はコード

> 作成手順は [Markdown_Marpプレゼン作成ガイド.md](../Markdown_Marpプレゼン作成ガイド.md) を参照。
