# Marp サンプルデッキ（テーマ切替の実物見本）

[作成ガイド](../Markdown_Marpプレゼン作成ガイド.md)の内容を実際にレンダリングした見本です。
各レイアウトマスターと、図のコード化（Mermaid / draw.io SVG）を1デッキで確認できます。
**1つのデッキ（`sample.md`）を、Marp Studio の「テーマ」で `acme` / `globex` / `initech` に
切り替えて**、顧客プロファイル（base 継承＋ロゴ・アクセント色の差し替え）でどう見た目が変わるかを
比較できます。

## ファイル

| パス | 内容 |
|---|---|
| `sample.md` | サンプルのソース（1本）。`theme:` 既定は `acme`。Studioでテーマを切り替えて見比べる |
| `out/sample.pdf` | 既定テーマでPDF出力したもの（**まずこれを開けば全体を確認できます**） |
| `assets/flow-build.mmd` | Mermaid ソース（フローチャート） |
| `assets/flow-build.svg` | 上記を `mmdc` でSVG化したもの（デッキに貼付） |
| `assets/architecture.drawio.svg` | draw.io 風の構成図SVG（手書きサンプル） |
| `assets/mmdc-config.json` | Mermaid レンダリング設定 |

> テーマの違いを並べて見たいときは、Studio でテーマを切り替えるか、`theme:` 行を変えて再出力します。

## 収録レイアウト

- 表紙（`<!-- _class: cover -->` ＋ `![bg]`）— 中立の幾何学カバー。タイトル左下・ロゴ右上
- セクション中扉（`<!-- _class: section -->`）— 薄青背景・アクセント（テーマ色）
- タイトルとコンテンツ（標準・右上に主体ロゴ＋顧客ロゴ）
- 2カラム / 比較（`.columns`）
- リード文 + コンテンツボックス（`.lead-area` / `.content-wrapper` / `.content-box`）
- 付箋ブレスト（`.fusen` 色・サイズ違い）
- 強調と表（`.good` / `.bad` / table）
- 図：Mermaid（テキスト→SVG）／ draw.io SVG（ベクター）
- フッター（frontmatter `footer:`）／まとめページ（`<!-- _class: title -->`）

## 再生成のしかた

### デッキの出力（PDF）

共通エンジンを使うのが簡単です（テーマCSSの登録・Mermaid のSVG化・フェンス画像化を自動で行います）:

```bash
# リポジトリのどこからでも可
node 00_common/tools/marp/marp-deck.mjs export 00_common/guides/marp/サンプル/sample.md
```

- 出力はデッキの `out/sample.pdf` に生成されます。
- 別テーマで出したいときは `sample.md` の `theme:` を `globex` / `initech` などに変えて再実行します。
- Mermaid 図（`assets/*.mmd`）はエクスポート時に自動でSVG化されます（`width="100%"` の高さ潰れも自動補正）。
- draw.io SVG は `<svg>` に `width`/`height` 属性があることを確認してください。

### VSCode で開く場合

`<ワークスペース>.code-workspace` で開けば、`markdown.marp.themes` に登録済みのテーマ
（`base` ＋ 各顧客テーマ）でプレビュー・「Marp: Export Slide Deck...」ができます。
