#!/usr/bin/env node
/* ================================================================
 * build-themes.mjs — ベーステーマと顧客テーマCSSを生成する（Node・依存なし）
 *
 * 役割:
 *   1) base.css の logos:begin/end を ../images/logos/ibm-logo.png から再生成
 *      （--ibm-logo を data URI 埋め込み。--customer-logo: none も併記）。
 *   2) profiles/<name>/ ごとに顧客テーマ <name>.css を生成:
 *        /* @theme <name> *\/  ＋  @import 'base';  ＋ overrides.css ＋
 *        logos:begin/end（--customer-logo を logo.* から data URI 埋め込み）。
 *
 * なぜ data URI 埋め込みか:
 *   marp はテーマCSS内の相対 url() を「参照するMD基準」で解決するため、
 *   CSS基準の相対パスでは画像が解決されない。MDの置き場所に依存せず確実に
 *   表示させるため data URI を採用（旧 build-logo.sh と同方針）。
 *
 * 使い方:
 *   node 00_common/tools/marp/... ではなく、このディレクトリ基準で:
 *     node build-themes.mjs            # base + 全プロファイルを生成
 *     node build-themes.mjs acme       # 指定プロファイルのみ生成（base も更新）
 *
 * プロファイル原本（編集する側）: profiles/<name>/
 *   - brand.json  { name, label, ... }（label は表示名）
 *   - logo.(png|svg|jpg|gif)          顧客ロゴ（従・小スロット）
 *   - overrides.css                   顧客固有の上書きCSS（任意・空可）
 * ================================================================ */
import { readFileSync, writeFileSync, existsSync, readdirSync, statSync } from 'node:fs';
import { resolve, dirname, join, extname } from 'node:path';
import { fileURLToPath } from 'node:url';

const DIR = dirname(fileURLToPath(import.meta.url));           // .../assets/marp
const LOGOS = resolve(DIR, '..', 'images', 'logos');
const PROFILES = join(DIR, 'profiles');

// 顧客レジストリ（customers.json）。internal 顧客テーマは主体ロゴをIBMに上書きする。
const REGISTRY = (() => {
  const p = join(DIR, 'customers.json');
  return existsSync(p) ? (JSON.parse(readFileSync(p, 'utf8')).customers || {}) : {};
})();
const isInternal = (name) => REGISTRY[name]?.kind === 'internal';

const MIME = { '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.svg': 'image/svg+xml' };
function dataUri(file) {
  const ext = extname(file).toLowerCase();
  const mime = MIME[ext];
  if (!mime) throw new Error(`未対応の画像拡張子: ${file}`);
  return `url("data:${mime};base64,${readFileSync(file).toString('base64')}")`;
}

/** logos:begin〜logos:end の中身を decls で置換（センチネルが無ければエラー） */
function replaceLogos(css, decls) {
  const re = /(\/\* logos:begin[^\n]*\*\/\n)[\s\S]*?(\n\/\* logos:end \*\/)/;
  if (!re.test(css)) throw new Error('logos:begin/end センチネルが見つかりません');
  return css.replace(re, `$1:root {\n${decls}}\n$2`);
}

/** base.css の主体ロゴ（中立プレースホルダ）＋中立カバー背景を再生成 */
function buildBase() {
  const p = join(DIR, 'base.css');
  const mark = join(LOGOS, 'neutral-mark.svg');
  if (!existsSync(mark)) throw new Error(`中立マークが見つかりません: ${mark}`);
  // --title-bg は表紙(section.cover)の最前面画像。base は none＝固有画像を持たないテーマは
  // section.cover の下層アクセント淡色グラデが見える（表紙色がアクセントに追従）。
  // 固有の表紙画像を持つ顧客/社内テーマだけが logos ブロックで --title-bg を画像に上書きする。
  const coverDecl = `\n  --title-bg: none;`;
  let css = readFileSync(p, 'utf8');
  // --closing-logo は背表紙(section.closing)に中央大表示するロゴ。base は中立マーク、顧客テーマは自社ロゴで上書き。
  const decls = `  --brand-logo: ${dataUri(mark)};\n  --customer-logo: none;   /* 顧客ロゴ未設定（各顧客テーマが上書き）。none でも主体ロゴ単独表示 */${coverDecl}\n  --closing-logo: ${dataUri(mark)};\n`;
  writeFileSync(p, replaceLogos(css, decls));
  console.log(`OK: base.css（--brand-logo=中立マーク・--title-bg=中立カバー 埋め込み）`);
}

/** profiles/<name>/ から <name>.css を生成 */
function buildProfile(name) {
  const pd = join(PROFILES, name);
  const brandPath = join(pd, 'brand.json');
  const brand = existsSync(brandPath) ? JSON.parse(readFileSync(brandPath, 'utf8')) : { name, label: name };
  const themeName = brand.name || name;
  const label = brand.label || themeName;

  // 顧客ロゴ（右上スロット）。任意: 無い顧客（表紙画像にロゴ内包など）は --customer-logo: none。
  const logo = readdirSync(pd).find((f) => /^logo\.(png|jpg|jpeg|gif|svg)$/i.test(f));
  const logoDecl = logo ? dataUri(join(pd, logo)) : 'none';
  const overrides = existsSync(join(pd, 'overrides.css')) ? readFileSync(join(pd, 'overrides.css'), 'utf8').replace(/\s+$/, '') : '';
  // 任意: 表紙(section.title)の背景画像。あれば --title-bg として data URI 埋め込み（overrides.css から var(--title-bg) で参照）。
  const titleBg = readdirSync(pd).find((f) => /^title-bg\.(png|jpg|jpeg|gif|svg)$/i.test(f));
  const titleBgDecl = titleBg ? `\n  --title-bg: ${dataUri(join(pd, titleBg))};` : '';
  // 背表紙(section.closing)の中央ロゴ。顧客ロゴがあれば上書き（無ければ base の中立マークを継承）。
  const closingDecl = logo ? `\n  --closing-logo: ${logoDecl};` : '';
  // 任意: 背表紙の全面背景画像（profiles/<name>/closing-bg.*）。あれば --closing-bg として埋め込み（顧客が overrides で全面表示）。
  const closingBg = readdirSync(pd).find((f) => /^closing-bg\.(png|jpg|jpeg|gif|svg)$/i.test(f));
  const closingBgDecl = closingBg ? `\n  --closing-bg: ${dataUri(join(pd, closingBg))};` : '';

  // 社内顧客（internal）は主体ロゴをIBMに上書き。base は中立マークなので、ここで自社ブランドを戻す。
  // ダミー顧客（dummy）は上書きせず base の中立マークを継承する。
  const ibm = join(LOGOS, 'ibm-logo.png');
  const brandDecl = isInternal(name) && existsSync(ibm) ? `\n  --brand-logo: ${dataUri(ibm)};` : '';
  const baseNote = isInternal(name) ? 'base（中立レイアウト）を継承し、主体ロゴをIBM・従ロゴを顧客に上書きする。'
                                    : 'base（中立レイアウト＋中立マーク主体）を継承し、顧客ロゴ/色のみ上書きする。';

  const css = `/* @theme ${themeName} */
/* ${label} 顧客プロファイル（自動生成: build-themes.mjs）。
   編集は profiles/${name}/（brand.json / logo.* / overrides.css）側で行い、再生成すること。
   ${baseNote} */
@import 'base';

${overrides}

/* logos:begin — build-themes.mjs が profiles/${name}/ の画像から自動生成（data URI）。手で編集しない。 */
:root {${brandDecl}
  --customer-logo: ${logoDecl};${titleBgDecl}${closingDecl}${closingBgDecl}
}
/* logos:end */
`;
  writeFileSync(join(DIR, `${themeName}.css`), css);
  console.log(`OK: ${themeName}.css（${label} / kind=${REGISTRY[name]?.kind || '?'} / ロゴ=${logo || 'なし'} / 表紙背景=${titleBg || 'なし'}）`);
}

/* IBM社内向けベーステーマ（顧客非依存）。顧客プロファイルとは別系統。
   customers.json には載せない（make-dist が「顧客」として scan/除外しないように）。
   設定（テーマ名・ラベル・背表紙タイル画像）は ibm/themes.json に置く。
   ※ ibm/ ディレクトリは製品版 dist には同梱しない。よって製品版では themes.json が存在せず、
     IBM社内テーマの生成は自動でスキップされる（このスクリプト本体は版権標章を含めない）。
   base を継承し、主体ロゴ=IBM・顧客ロゴ=none・背表紙タイル（全面）を埋め込む。
   色・表紙/背表紙の上書きは ibm/<name>.css（手編集）側。配色だけを変えた2種。 */
const IBM_DIR = join(DIR, 'ibm');
const IBM_MANIFEST = join(IBM_DIR, 'themes.json');
const IBM_THEMES = existsSync(IBM_MANIFEST) ? JSON.parse(readFileSync(IBM_MANIFEST, 'utf8')) : [];

/** ibm/themes.json の1エントリ {name,label,tile} から <name>.css を生成
    （IBMロゴ＋背表紙タイルを data URI 埋め込み、ibm/<name>.css を上書きとして取り込む） */
function buildIbmTheme(t) {
  const ibm = join(LOGOS, 'ibm-logo.png');
  if (!existsSync(ibm)) throw new Error(`IBMロゴが見つかりません: ${ibm}`);
  const tile = join(LOGOS, t.tile);
  if (!existsSync(tile)) throw new Error(`背表紙タイル画像が見つかりません: ${tile}`);
  // 表紙右下のマーク（任意・透過PNG等）。あれば --cover-mark として埋め込む。
  const coverMark = t.covermark ? join(LOGOS, t.covermark) : null;
  if (coverMark && !existsSync(coverMark)) throw new Error(`表紙マーク画像が見つかりません: ${coverMark}`);
  const coverMarkDecl = coverMark ? `\n  --cover-mark: ${dataUri(coverMark)};   /* 表紙右下のマーク */` : '';
  const ovPath = join(IBM_DIR, `${t.name}.css`);
  const overrides = existsSync(ovPath) ? readFileSync(ovPath, 'utf8').replace(/\s+$/, '') : '';

  const css = `/* @theme ${t.name} */
/* ${t.label} — IBM社内向け（顧客ロゴなし）。自動生成: build-themes.mjs。
   編集は ibm/${t.name}.css（色・表紙/背表紙の上書き）側で行い、再生成すること。
   base（中立レイアウト）を継承し、主体ロゴ=IBM・顧客ロゴ=none・背表紙=全面タイルを埋め込む。 */
@import 'base';

${overrides}

/* logos:begin — build-themes.mjs が ../images/logos/ から自動生成（data URI）。手で編集しない。 */
:root {
  --brand-logo: ${dataUri(ibm)};
  --customer-logo: none;   /* IBM社内テーマ＝顧客ロゴなし */
  --closing-logo: ${dataUri(tile)};   /* 背表紙の全面タイル（1920x1080） */${coverMarkDecl}
}
/* logos:end */
`;
  writeFileSync(join(DIR, `${t.name}.css`), css);
  console.log(`OK: ${t.name}.css（${t.label}）`);
}

const only = process.argv[2];
buildBase();
const names = existsSync(PROFILES)
  ? readdirSync(PROFILES).filter((n) => statSync(join(PROFILES, n)).isDirectory())
  : [];
for (const n of names) {
  if (only && n !== only) continue;
  buildProfile(n);
}
for (const t of IBM_THEMES) {
  if (only && t.name !== only) continue;
  buildIbmTheme(t);
}
const ibmCount = only ? (IBM_THEMES.some((t) => t.name === only) ? 1 : 0) : IBM_THEMES.length;
console.log(`完了: base + ${only ? `テーマ ${only}` : `${names.length} プロファイル + ${ibmCount} IBM社内テーマ`}`);
