# 共通 Marp テーマ（`base` ＋ 顧客プロファイル）

プロジェクトの Marp スライド（`marp: true` のMD）で共通利用するスタイルです。
中立ベース `base.css`（`/* @theme base */`）を各顧客テーマが `@import` して継承します。
各MDは `theme: base`（または顧客テーマ名）を指定するだけで使えます。

> 配置: 共通資材として `00_common/assets/` 配下に集約しています
> （テーマ `marp/` と画像 `images/` が同じ階層に並ぶ）。

```
00_common/assets/
├── marp/
│   ├── base.css          ← 中立ベーステーマ（IBMロゴ＋共通レイアウト）
│   ├── acme.css          ← 顧客テーマの例（base を @import し顧客ロゴを上書き／自動生成）
│   ├── ibm_1.css         ← IBM社内テーマ・ティール（顧客ロゴなし／自動生成。製品版には非同梱）
│   ├── ibm_2.css         ← IBM社内テーマ・ブルー（顧客ロゴなし／自動生成。製品版には非同梱）
│   ├── ibm/              ← IBM社内テーマの上書き原本（ibm_1.css・ibm_2.css ＝ 色/表紙/背表紙のみ）
│   ├── profiles/         ← 顧客プロファイル原本（<name>/brand.json・logo.*・overrides.css）
│   ├── build-themes.mjs  ← base のロゴ・各顧客テーマ・IBM社内テーマCSSを再生成（Node）
│   └── README.md         ← このファイル
└── images/
    ├── logos/   (ibm-logo.png, ...)
    ├── photos/
    └── backgrounds/
```

## 構成

| ファイル | 役割 |
|---------|------|
| `base.css` | 中立ベーステーマ。`/* @theme base */`。共通レイアウト＋IBMロゴ（主体）。顧客ロゴは CSS変数 `--customer-logo`（既定 none） |
| `acme.css` ほか顧客テーマ | `/* @theme <顧客名> */` ＋ `@import 'base';` ＋ 顧客ロゴ/色の上書き。**`build-themes.mjs` が自動生成**（編集は `profiles/<顧客名>/` 側で） |
| `ibm_1.css` / `ibm_2.css` | **IBM社内向けテーマ**（部門会議・アセット登録など。顧客ロゴなし）。`@import 'base';` ＋ 主体ロゴ=IBM・背表紙=全面マークタイル・配色のみ差別化（`ibm_1`=Carbon Teal／`ibm_2`=IBM Blue）。**`build-themes.mjs` が自動生成**（編集は `ibm/<name>.css` 側で）。<br>※ IBM標章入りのため**製品版 dist には非同梱**（`--customer` 社内版にのみ同梱） |
| `ibm/<name>.css`・`ibm/themes.json` | IBM社内テーマの原本: `<name>.css`＝色・表紙(cover)・背表紙(closing)・中扉(section)の上書きだけ／`themes.json`＝テーマ名・ラベル・背表紙タイル画像の一覧。`@theme`/`@import`/logos は build-themes が付与 |
| `profiles/<顧客名>/` | 顧客プロファイル原本: `brand.json`（表示名等）・`logo.*`（顧客ロゴ）・`overrides.css`（任意の上書き） |
| `build-themes.mjs` | `base.css` のIBMロゴ・各 `profiles/<顧客名>/` の顧客テーマ・`ibm/<name>.css` のIBM社内テーマCSSを生成（base継承＋ロゴ data URI 埋め込み） |

> 配色は **IBM Carbon Design System** を基調（`90_refs/PPT_template/` の IBM Japan 公式テンプレートに準拠）。
> IBM Blue `#0F62FE` を主アクセント、テキスト `#161616`、フッター/番号 `#6F6F6F`、薄青系 `#E5F6FF`/`#D0E2FF`。
> フォントは `IBM Plex Sans JP` → `Hiragino`/`Meiryo` の順でフォールバック。
> ※ 完全一致ではなくプロジェクト独自テンプレートとしての基調採用です。

## 共通ロゴ（テーマに自動表示）

IBM提示ドキュメントのため、**IBM ロゴを主体**に顧客ロゴを並置し、両方を
**base64 data URI で埋め込み**、全スライドに自動表示します。各MDに `![](...)` は不要です。

- **表紙**（`<!-- _class: title -->`）: 中央上部に IBM（大）＋顧客ロゴ（小）を並置
- **本文スライド**: 右上に IBM（右・大）＋顧客ロゴ（左・小）（ページ番号は左下）
- **このスライドだけロゴを消す**: `<!-- _class: no-logo -->`

## フッター（著作権表記など）

frontmatter の `footer:` で右下に表示します（テーマが位置・色 Gray60 を整えます）。

```yaml
---
marp: true
theme: base
paginate: true
footer: '© 2026 Your Company'
---
```

特定スライドだけ消すには `<!-- _footer: '' -->` を先頭に書きます。

### なぜ data URI 埋め込みなのか（重要）

marp は **テーマCSS内の相対 `url()` を「参照するMDファイル基準」で解決** します。
そのため CSS基準の相対パス（`../images/logos/...`）ではMDの置き場所により解決先が
ずれ、ロゴが表示されません（CLI出力で実測・確認済み）。MDの場所に依存せず確実に
表示させるため、CSSに自己完結する data URI を埋め込んでいます。
副次効果として **`--allow-local-files` 不要**・**VSCodeプレビューでも確実に表示** されます。

### ロゴ画像を差し替えたら

IBMロゴ実体 `00_common/assets/images/logos/ibm-logo.png`、または各顧客ロゴ
`00_common/assets/marp/profiles/<顧客名>/logo.*` を更新した後、再生成スクリプトを実行:

```bash
node 00_common/assets/marp/build-themes.mjs          # base＋全顧客テーマ＋IBM社内テーマを再生成
node 00_common/assets/marp/build-themes.mjs acme     # 指定顧客のみ（base も更新）
node 00_common/assets/marp/build-themes.mjs ibm_1    # IBM社内テーマのみ（色/表紙の編集は ibm/ibm_1.css 側で）
```

各CSSの `logos:begin` 〜 `logos:end` の間（`:root` の data URI）が更新されます。
この範囲は自動生成のため手で編集しないでください。顧客を増やすには `profiles/<新顧客名>/`
（`brand.json`・`logo.*`・`overrides.css`）を用意して再生成します。

## その他の共通画像の使い方

ロゴ以外の画像（`images/photos/`・`images/backgrounds/`・各種ロゴ）は、各MDから
**Markdown相対パス**で参照します（こちらはMD基準で解決されるので相対パスでOK）。

```markdown
![写真の例](../../../../00_common/assets/images/photos/<写真ファイル>.png)
```

> パスの `../` の数は、その**MDファイルの置き場所**から `00_common/` までの距離で決まります。
> PDF/PNG/PPTX へ書き出す際は `--allow-local-files`（CLI）／エクスポート時のローカル許可が必要です。
> 画像一覧は [`../images/README.md`](../images/README.md) を参照。

## 各スライドMD側の指定

frontmatter で次のように指定するだけです（CSSの内容を各MDに埋め込む必要はありません）。

```yaml
---
marp: true
theme: base
paginate: true
---
```

## VSCode プレビューでの利用

ワークスペース設定にテーマを登録済みです（追加設定不要）。

- ルート: `.vscode/settings.json`
- ワークスペースファイル: `<ワークスペース>.code-workspace`

```jsonc
"markdown.marp.themes": [
  "00_common/assets/marp/base.css"
],
"markdown.marp.html": "all"
```

> 設定追加・CSS変更を反映するには **VSC ウィンドウの再読み込み**
> (Command Palette → "Developer: Reload Window") が必要です。
> テーマ登録方式のため、従来の `?v=` キャッシュバスターは不要です。

## Marp CLI での出力

CLI では `--theme-set` でCSSを渡します。

```bash
# プロジェクトルート (chidai_work_local) から実行する例
marp "<プロジェクト>/decks/<デッキ>/<デッキ>.md" \
  --theme-set "00_common/assets/marp/base.css" \
  --html --allow-local-files \
  --pdf -o management-plan.pdf
```

mermaid を含むMD は、CLI側の mermaid 対応
（`@marp-team/marp-cli` + mermaid プラグイン等）が別途必要です。

## レイアウトマスター（`_class` で切替）

PowerPoint のレイアウトマスター相当。スライド先頭に `<!-- _class: 名前 -->`（その1枚）を書きます。

| class | 用途 | 見た目 |
|---|---|---|
| `cover` | 表紙 | 幾何学カバー背景の上にタイトルを左下配置。背景は `![bg](.../backgrounds/neutral-cover.svg)` を併用 |
| `title` | 簡易表紙・章末扉 | 明るい背景・中央寄せ・ロゴ中央上部・ページ番号なし |
| `section` | セクション中扉 | 薄青グラデ背景・IBM Blue 左アクセントバー＋濃紺見出し |
| （無指定） | タイトルとコンテンツ | 標準。見出し罫線＋本文＋右上ロゴ＋左下ページ番号 |
| `no-logo` | ロゴを消す | その1枚だけ右上ロゴを非表示 |
| `no-page` | ページ番号を消す | その1枚だけ番号非表示 |
| `start-page` | 採番開始 | そのスライドからページ番号を1にリセット |

## 補助クラス（任意・HTML有効時）

`html: "all"`（旧 `enableHtml: true`／CLIは `--html`）有効時、`<div class="...">` でレイアウト補助が使えます。
`.lead-area` / `.content-wrapper` / `.content-box` / `.columns`（フル幅2カラム） / `.fusen`（`small`/`large`/`wide`/`fit`/`blue`/`pink`/`green`/`yellow`） / `.good` / `.bad`。

> 注: プレーンMarkdownでも崩れないよう調整済みです（`order:` 指定は使っていません）。

## mermaid 図の配色標準（読者フレンドリー）

図は ```` ```mermaid ```` フェンスで書く（ビルド時にSVG化）。読者が迷わないよう、次を守る。

- **色は「意味」に対応**させ、装飾で色数を増やさない。**色を使ったら凡例を添える**（本文に色スパン）。
- **到達点・現在地・完了は緑で強調**。**図形**は 角丸=起点／ひし形=判断／四角=処理・状態。
- 丸数字は使わない（環境依存）。色覚差に配慮しコントラストを確保。

配色（IBM Carbon 準拠・`classDef` で指定）:

| 役割 | fill / stroke | 使いどころ |
|---|---|---|
| 主体・工程・対象 | `#d0e2ff` / `#0f62fe`（青） | 中心の主体・工程・IBM側・対象システム |
| 現行・顧客・DB | `#e8daff` / `#8a3ffc`（紫） | 現行資産(as-is)・顧客・DB |
| 外部・対象外・要調査 | `#ffd9be` / `#ff832b`（橙） | 外部依存・スコープ外・エスカレ／要調査 |
| 新・内製・完了 | `#a7f0ba` / `#198038`（緑） | 新環境(to-be)・内製・成果。到達点は塗り `#198038`＋白字で強調 |
| 判断・保留(TBD) | `#fff8e1` / `#f1c21b`（黄） | 判断ゲート・LLM・TBD（TBDは `stroke-dasharray:4 3`） |
| 中立・補足 | `#f4f4f4` / `#6f6f6f`（灰） | 中立ノード・対象外の終息 |

コピペ用スニペット:

```
classDef obj  fill:#d0e2ff,stroke:#0f62fe,color:#161616;
classDef cur  fill:#e8daff,stroke:#8a3ffc,color:#161616;
classDef ext  fill:#ffd9be,stroke:#ff832b,color:#161616;
classDef new  fill:#a7f0ba,stroke:#198038,color:#161616;
classDef done fill:#198038,stroke:#198038,color:#ffffff,stroke-width:2px;
classDef tbd  fill:#fff8e1,stroke:#f1c21b,color:#161616,stroke-dasharray:4 3;
classDef mute fill:#f4f4f4,stroke:#6f6f6f,color:#161616;
```

凡例の書き方（例）: `<span style="background:#d0e2ff;padding:1px 8px;">対象</span>`。
実例: 「課題・変更・リスク管理」「プロジェクト憲章」「現新比較 実施手順書」。

## 作成ガイド・サンプル・ツール

- **かんたん（ブラウザだけで作りたい人）**: `00_common/guides/marp/Marp-Studioの使い方.md`
  - ブラウザだけで作成→編集→PDF。起動は `tools/Marp-Studioを起動.command`（Mac）/`.bat`（Win）をダブルクリック。
- 詳細リファレンス: `00_common/guides/marp/Markdown_Marpプレゼン作成ガイド.md`
- サンプル（実物）: `00_common/guides/marp/サンプル/`（`sample.md`・テーマ切替で3スタイル ＋ PDF `out/`）
- 雛形ツール（Node・Mac/Win共通）: `00_common/tools/marp/marp-deck.mjs`
  - 新規: `node 00_common/tools/marp/marp-deck.mjs new <フォルダ> "タイトル"`
  - 出力: `node 00_common/tools/marp/marp-deck.mjs export <デッキ.md>`（テーマパス自動解決）
