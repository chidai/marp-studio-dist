/* ================================================================
 * tokens.mjs — スライドXML内の {{TOKEN}} を段落(<a:p>)単位で検出・置換する。
 *
 * PowerPointは書式境界(太字/リンク/スペルチェック等)でテキストを複数の
 * <a:r><a:t>ランに分割することがあるため、1つの<a:t>だけを見て文字列一致
 * させると、ラン境界をまたぐトークンを取り逃す。ここでは<a:br/>で区切られる
 * 「連続ランの並び」ごとにテキストを連結してからトークンを探し、見つかった
 * 範囲を元のラン配置へ書き戻す(最初にマッチしたランの書式(rPr)を残し、
 * 差し替え後の文字列をそこに集約。他のランは食われた分だけ空/短縮する)。
 *
 * XML DOM無し・正規表現+文字列スプライスのみ(依存ゼロ・PowerPoint生成XMLのみを想定)。
 * ================================================================ */

const TOKEN_RE = /\{\{([A-Z][A-Z0-9_]*)\}\}/g;
const PARA_RE = /<a:p(?:\s[^>]*)?>[\s\S]*?<\/a:p>/g;
const SEG_RE = /<a:r>[\s\S]*?<\/a:r>|<a:br\s*\/>/g;
const RUN_INNER_RE = /^<a:r>([\s\S]*?)<a:t((?:\s[^>]*)?)(?:\/>|>([\s\S]*?)<\/a:t>)[\s\S]*?<\/a:r>$/;

function escapeXmlText(str) {
  return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

/** paraXml内のラン列を <a:br/> で区切ったグループへ分割し、各ランを解析する。 */
function parseRunGroups(paraXml) {
  const segments = [];
  let m;
  SEG_RE.lastIndex = 0;
  while ((m = SEG_RE.exec(paraXml))) {
    const raw = m[0];
    if (raw.startsWith('<a:br')) { segments.push({ type: 'br', start: m.index, end: m.index + raw.length }); continue; }
    const inner = RUN_INNER_RE.exec(raw);
    if (!inner) { segments.push({ type: 'run-opaque', start: m.index, end: m.index + raw.length, raw }); continue; }
    segments.push({
      type: 'run', start: m.index, end: m.index + raw.length, raw,
      rPrRaw: inner[1] || '', tAttrs: inner[2] || '', text: inner[3] != null ? inner[3] : '',
    });
  }
  const groups = [];
  let cur = [];
  for (const seg of segments) {
    if (seg.type === 'run') cur.push(seg);
    else { if (cur.length) groups.push(cur); cur = []; }
  }
  if (cur.length) groups.push(cur);
  return groups;
}

/** [{start,end,replacement}] (start昇順・重複無し) を使って str を再構成する。 */
function spliceRanges(str, ranges) {
  let out = '', last = 0;
  for (const r of ranges) { out += str.slice(last, r.start) + r.replacement; last = r.end; }
  out += str.slice(last);
  return out;
}

/** 1つのランのテキストへ、ローカルオフセット指定の編集群(昇順・重複無し)を適用する。 */
function applyLocalEdits(text, edits) {
  if (!edits.length) return text;
  return spliceRanges(text, edits.map((e) => ({ start: e.localStart, end: e.localEnd, replacement: e.insert })));
}

/** スライドXML全体を走査し、runをまたぐ{{TOKEN}}ごとに handler(tokenName) を呼ぶ。
 *  handler が文字列を返せばその場に差し替える(XMLエスケープ済みで渡すこと)。undefinedを返せば
 *  その出現は変更せず元のまま残す(検出専用の利用を想定)。 */
export function forEachToken(xmlString, handler) {
  return xmlString.replace(PARA_RE, (paraXml) => {
    const groups = parseRunGroups(paraXml);
    const runReplacements = [];
    for (const group of groups) {
      const bounds = []; // {run, start, end} = concatenation内オフセット
      let pos = 0;
      for (const run of group) { bounds.push({ run, start: pos, end: pos + run.text.length }); pos += run.text.length; }
      const concat = group.map((r) => r.text).join('');
      const editsByRun = new Map(); // run -> [{localStart, localEnd, insert}]
      let tm;
      TOKEN_RE.lastIndex = 0;
      while ((tm = TOKEN_RE.exec(concat))) {
        const tokenName = tm[1];
        const startOffset = tm.index, endOffset = tm.index + tm[0].length;
        const replacement = handler(tokenName);
        if (replacement === undefined) continue;
        const touched = bounds.filter((b) => b.start < endOffset && b.end > startOffset);
        if (!touched.length) continue;
        touched.forEach((b, i) => {
          const localStart = Math.max(startOffset - b.start, 0);
          const localEnd = Math.min(endOffset - b.start, b.run.text.length);
          const insert = i === 0 ? replacement : '';
          if (!editsByRun.has(b.run)) editsByRun.set(b.run, []);
          editsByRun.get(b.run).push({ localStart, localEnd, insert });
        });
      }
      for (const [run, edits] of editsByRun) {
        edits.sort((a, b) => a.localStart - b.localStart);
        const newText = applyLocalEdits(run.text, edits);
        let attrs = run.tAttrs;
        if (!/xml:space\s*=\s*"preserve"/.test(attrs) && /^\s|\s$/.test(newText)) attrs += ' xml:space="preserve"';
        runReplacements.push({ start: run.start, end: run.end, replacement: `<a:r>${run.rPrRaw}<a:t${attrs}>${newText}</a:t></a:r>` });
      }
    }
    runReplacements.sort((a, b) => a.start - b.start);
    return spliceRanges(paraXml, runReplacements);
  });
}

/** xmlString内で使われている {{TOKEN}} の一覧(重複無し・出現順)を返す。 */
export function discoverTokens(xmlString) {
  const found = [];
  const seen = new Set();
  forEachToken(xmlString, (name) => { if (!seen.has(name)) { seen.add(name); found.push(name); } return undefined; });
  return found;
}

/** tokenMap(={TOKEN: 表示したい文字列})にあるトークンだけを置換したXMLを返す。
 *  tokenMapに無いトークンは元のまま残す(呼び出し側で未提供トークンの検証を行う想定)。 */
export function substituteTokens(xmlString, tokenMap) {
  return forEachToken(xmlString, (name) => (
    Object.prototype.hasOwnProperty.call(tokenMap, name) ? escapeXmlText(tokenMap[name]) : undefined
  ));
}

/** xmlString内に未解決の {{TOKEN}} が残っていないか調べる(自己検証用)。 */
export function hasUnresolvedTokens(xmlString) {
  TOKEN_RE.lastIndex = 0;
  return TOKEN_RE.test(xmlString);
}

/** tokenNamesのいずれかを含む<a:p>段落を丸ごと削除する(optional tokenが未提供の場合に使う)。
 *  空欄(箇条書きの●だけの行等)を残さないよう、置換ではなく段落そのものを取り除く。 */
export function removeParagraphsWithTokens(xmlString, tokenNames) {
  if (!tokenNames || !tokenNames.length) return xmlString;
  const names = new Set(tokenNames);
  return xmlString.replace(PARA_RE, (paraXml) => (
    discoverTokens(paraXml).some((t) => names.has(t)) ? '' : paraXml
  ));
}
