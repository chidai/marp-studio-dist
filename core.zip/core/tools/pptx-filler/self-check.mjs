/* ================================================================
 * self-check.mjs — pptx-filler のラウンドトリップ自己検証。
 * 手動でPowerPointを開かずに、生成結果が構造的に正しいことを確認する。
 * 実行: node core/tools/pptx-filler/self-check.mjs
 * ================================================================ */
import { readFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadPatternLibrary, renderDeck, save } from './pptx-filler.mjs';
import { readZip } from './zip.mjs';
import { discoverTokens, substituteTokens, hasUnresolvedTokens } from './tokens.mjs';

const __dirname = dirname(fileURLToPath(import.meta.url));
const TEMPLATES = join(__dirname, 'templates');
const OUT = join(__dirname, 'out', 'self-check.pptx');
const TOKEN_LEFTOVER_RE = /\{\{[A-Z][A-Z0-9_]*\}\}/;

const spec = {
  slides: [
    { pattern: 'title-bullets', tokens: { TITLE: '進捗サマリー', BODY1: '事前調査は完了', BODY2: '設計フェーズへ移行', BODY3: '次回レビューは来週' } },
    {
      pattern: 'three-cards',
      tokens: {
        TITLE: '検討の柱',
        CARD1_TITLE: 'スコープ', CARD1_BODY: '対象範囲の定義',
        CARD2_TITLE: '体制', CARD2_BODY: '役割分担の確認',
        CARD3_TITLE: 'リスク', CARD3_BODY: '主要リスクの洗い出し',
      },
    },
    { pattern: 'title-bullets', tokens: { TITLE: '次回アクション', BODY1: '資料レビュー依頼', BODY2: '関係者への共有', BODY3: '次回定例の設定' } },
    // BODY2/BODY3は省略(optional token)。該当段落が削除され、空の箇条書きが残らないことを検証する。
    { pattern: 'title-bullets', tokens: { TITLE: '単一項目のみ', BODY1: '唯一の項目' } },
  ],
};

let passed = 0, failed = 0;
function check(name, cond) {
  if (cond) { passed++; console.log(`OK   ${name}`); }
  else { failed++; console.error(`FAIL ${name}`); }
}

const lib = loadPatternLibrary(join(TEMPLATES, 'parts-library.pptx'), join(TEMPLATES, 'manifest.json'));
const srcPkg = lib.__pkg;

const deck = renderDeck(spec, lib);
save(deck, OUT);
const outPkg = readZip(readFileSync(OUT));

// (a) トークン残骸なし + (b) 差し替え文字列が存在する
spec.slides.forEach((s, idx) => {
  const partName = `ppt/slides/slide${idx + 1}.xml`;
  const xml = outPkg.get(partName)?.toString('utf8') || '';
  check(`${partName}: トークン残骸なし`, !TOKEN_LEFTOVER_RE.test(xml));
  for (const [k, v] of Object.entries(s.tokens)) {
    check(`${partName}: {{${k}}} -> "${v}" が反映されている`, xml.includes(v));
  }
});

// optional token(BODY2/BODY3省略)が未提供の段落を削除し、空の箇条書きを残さないことを確認する。
{
  const partName = 'ppt/slides/slide4.xml';
  const xml = outPkg.get(partName).toString('utf8');
  const paraCount = (xml.match(/<a:p(?:\s[^>]*)?>/g) || []).length;
  check('optional token省略: 空段落を残さず削除(段落数=2)', paraCount === 2);
}

// (c) スライド枚数の一致
const presXml = outPkg.get('ppt/presentation.xml').toString('utf8');
const ctXml = outPkg.get('[Content_Types].xml').toString('utf8');
const sldIdCount = (presXml.match(/<p:sldId\s/g) || []).length;
const ctSlideOverrideCount = (ctXml.match(/PartName="\/ppt\/slides\/slide\d+\.xml"/g) || []).length;
const slidePartCount = [...outPkg.keys()].filter((k) => /^ppt\/slides\/slide\d+\.xml$/.test(k)).length;
check('presentation.xml: sldIdLst件数が一致', sldIdCount === spec.slides.length);
check('[Content_Types].xml: slide Override件数が一致', ctSlideOverrideCount === spec.slides.length);
check('ppt/slides/: slideN.xmlの数が一致', slidePartCount === spec.slides.length);

// (d) 共有パーツ(theme/master/layout)がソースと完全に同一バイト列
const usedPatterns = [...new Set(spec.slides.map((s) => s.pattern))];
const sharedNames = new Set();
for (const key of usedPatterns) {
  const c = lib[key].closure;
  for (const name of [c.layoutPartName, c.masterPartName, c.themePartName]) if (name) sharedNames.add(name);
}
for (const name of sharedNames) {
  check(`共有パーツがソースと同一バイト列: ${name}`, !!outPkg.get(name)?.equals(srcPkg.get(name)));
}

// (e) ラン分割耐性(単体): 起点テンプレートはpptxgenjs生成のため各トークンが単一ランに収まって
// おり、上のラウンドトリップ検証では「PowerPointの手編集でトークンがラン境界を挟んで分断された」
// ケースを一度も通っていない。tokens.mjsの安全網(段落単位のラン結合)を直接叩いて確認する。
{
  // <a:t>...</a:t> の内容だけを連結し、ラン境界のタグを除いた「可視テキスト」を取り出す
  // (置換後もランは複数に分かれたままなので、生XML文字列上では地続きにならない点に注意)。
  const visibleText = (xml) => (xml.match(/<a:t[^>]*>([\s\S]*?)<\/a:t>/g) || [])
    .map((t) => t.replace(/<a:t[^>]*>|<\/a:t>/g, '')).join('');

  // 2ランに分断: 最初のラン(b="1")の書式が差し替え後も残ることを確認。
  const para2 = '<a:p><a:r><a:rPr lang="en-US" b="1"/><a:t>見出し: {{TIT</a:t></a:r>'
    + '<a:r><a:rPr lang="en-US"/><a:t>LE}}にする</a:t></a:r></a:p>';
  check('ラン分割(2ラン)検出: TITLE', discoverTokens(para2).includes('TITLE'));
  const out2 = substituteTokens(para2, { TITLE: 'テスト' });
  check('ラン分割(2ラン)可視テキストに反映', visibleText(out2) === '見出し: テストにする');
  check('ラン分割(2ラン)トークン残骸なし', !hasUnresolvedTokens(out2));
  check('ラン分割(2ラン)先頭ランの書式(b="1")保持', /<a:rPr lang="en-US" b="1"\/><a:t[^>]*>見出し: テスト<\/a:t>/.test(out2));

  // 3ランに分断・中間ランが完全に消費されるケース。
  const para3 = '<a:p><a:r><a:rPr/><a:t>pre{{TI</a:t></a:r>'
    + '<a:r><a:rPr/><a:t>TLE</a:t></a:r>'
    + '<a:r><a:rPr/><a:t>}}post</a:t></a:r></a:p>';
  const out3 = substituteTokens(para3, { TITLE: 'X' });
  check('ラン分割(3ラン・中間消費)可視テキスト', visibleText(out3) === 'preXpost' && !hasUnresolvedTokens(out3));

  // tokenMapに無いトークンは元のまま残す(未提供トークンの検証は呼び出し側=ooxml.mjsの責務)。
  const out4 = substituteTokens('<a:p><a:r><a:rPr/><a:t>{{UNKNOWN}}</a:t></a:r></a:p>', {});
  check('未提供トークンは変更せず残す', out4.includes('{{UNKNOWN}}'));
}

// (f) renderDeckのトークン検証(エラーパス): 不足・未知トークンで例外になることを確認。
{
  let threw = false;
  try { renderDeck({ slides: [{ pattern: 'title-bullets', tokens: { TITLE: 'x' } }] }, lib); }
  catch (e) { threw = /不足/.test(e.message); }
  check('renderDeck: 必要トークン不足で例外', threw);

  threw = false;
  try {
    renderDeck({ slides: [{ pattern: 'title-bullets', tokens: {
      TITLE: 'x', BODY1: 'a', BODY2: 'b', BODY3: 'c', EXTRA: 'd',
    } }] }, lib);
  } catch (e) { threw = /存在しない/.test(e.message); }
  check('renderDeck: 未知トークンで例外', threw);
}

console.log(`\n${passed} passed, ${failed} failed -> ${OUT}`);
if (failed > 0) process.exit(1);
