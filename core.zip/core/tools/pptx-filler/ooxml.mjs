/* ================================================================
 * ooxml.mjs — .pptx(OOXMLパッケージ)のパーツ解決と出力パッケージの組み立て。
 *
 * 方針: 部品ライブラリ(parts-library.pptx)のコピーを編集するのではなく、
 * 「使うパターンだけ」を都度新規パッケージへ組み立てる(build-fresh)。
 * これにより「使われなかった部品スライドの削除」という問題自体が発生しない
 * (最初から取り込まないため)。スライドは常に slide1.xml から採番し直す。
 * ================================================================ */
import { substituteTokens, removeParagraphsWithTokens } from './tokens.mjs';

const REL_TYPE_SLIDE = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide';

/** xml内のRelationshipのうち、Typeが指定suffixで終わるものを取り除く。
 *  ノート(notesSlide/notesMaster)は今回のパターンでは追随しない(取り込んでいないため)。 */
function stripRelsByTypeSuffix(xml, suffix) {
  return xml.replace(/<Relationship\s+[^>]*?\/>/g, (m) => {
    const type = (m.match(/Type="([^"]*)"/) || [])[1] || '';
    return type.endsWith('/' + suffix) ? '' : m;
  });
}

/** partNameの「ディレクトリ」部分(rels内Targetの相対パス解決の基点)。 */
function partDir(partName) {
  const i = partName.lastIndexOf('/');
  return i < 0 ? '' : partName.slice(0, i);
}

/** OPCの相対パス解決(../ を含む target を basePartName の場所を基点に正規化する)。 */
export function resolveTarget(basePartName, target) {
  if (/^https?:\/\//i.test(target)) return target; // 外部URL(処理対象外)
  const clean = target.replace(/^\.\//, '');
  const baseDir = partDir(basePartName);
  const combined = clean.startsWith('/') ? clean.slice(1) : (baseDir ? `${baseDir}/${clean}` : clean);
  const stack = [];
  for (const seg of combined.split('/')) {
    if (seg === '' || seg === '.') continue;
    if (seg === '..') stack.pop(); else stack.push(seg);
  }
  return stack.join('/');
}

/** partNameに対応する _rels/*.rels パーツ名を返す(例: ppt/slides/slide2.xml -> ppt/slides/_rels/slide2.xml.rels)。 */
export function relsPartName(partName) {
  const dir = partDir(partName);
  const file = partName.slice(dir.length ? dir.length + 1 : 0);
  return (dir ? `${dir}/_rels/` : '_rels/') + `${file}.rels`;
}

/** Relationships XML(Buffer|undefined) を [{id,type,target}] へ変換する。 */
export function parseRelsXml(buffer) {
  if (!buffer) return [];
  const xml = buffer.toString('utf8');
  const rels = [];
  const re = /<Relationship\s+([^>]*?)\/>/g;
  let m;
  while ((m = re.exec(xml))) {
    const attrs = m[1];
    rels.push({
      id: (attrs.match(/Id="([^"]*)"/) || [])[1],
      type: (attrs.match(/Type="([^"]*)"/) || [])[1],
      target: (attrs.match(/Target="([^"]*)"/) || [])[1],
    });
  }
  return rels;
}

function findRelByTypeSuffix(rels, suffix) {
  return rels.find((r) => r.type && r.type.endsWith('/' + suffix));
}

/** 1パターン(部品スライド)を成立させるために必要な共有パーツ(layout/master/theme/media)を解決する。 */
export function collectPatternClosure(pkg, sourceSlidePartName) {
  const slideRelsPartName = relsPartName(sourceSlidePartName);
  const slideRels = parseRelsXml(pkg.get(slideRelsPartName));

  const layoutRel = findRelByTypeSuffix(slideRels, 'slideLayout');
  if (!layoutRel) throw new Error(`pptx-filler: ${sourceSlidePartName} に slideLayout への関連付けが見つかりません`);
  const layoutPartName = resolveTarget(sourceSlidePartName, layoutRel.target);
  const layoutRelsPartName = relsPartName(layoutPartName);
  const layoutRels = parseRelsXml(pkg.get(layoutRelsPartName));

  const masterRel = findRelByTypeSuffix(layoutRels, 'slideMaster');
  if (!masterRel) throw new Error(`pptx-filler: ${layoutPartName} に slideMaster への関連付けが見つかりません`);
  const masterPartName = resolveTarget(layoutPartName, masterRel.target);
  const masterRelsPartName = relsPartName(masterPartName);
  const masterRels = parseRelsXml(pkg.get(masterRelsPartName));

  const themeRel = findRelByTypeSuffix(masterRels, 'theme');
  const themePartName = themeRel ? resolveTarget(masterPartName, themeRel.target) : null;

  const mediaPartNames = slideRels
    .filter((r) => r.type && /\/relationships\/(image|media|video|audio)$/.test(r.type))
    .map((r) => resolveTarget(sourceSlidePartName, r.target));

  return {
    slideRelsPartName, layoutPartName, layoutRelsPartName, masterPartName, masterRelsPartName,
    themePartName, mediaPartNames,
  };
}

/** 不足/未知トークンを検証し、optional指定で未提供だったトークン名の一覧を返す
 *  (呼び出し側でその段落を削除するために使う)。 */
function validateTokens(patternKey, tokensRequired, optionalTokens, tokensProvided) {
  const provided = new Set(Object.keys(tokensProvided || {}));
  const missing = tokensRequired.filter((t) => !provided.has(t) && !optionalTokens.has(t));
  const unknown = [...provided].filter((t) => !tokensRequired.includes(t));
  if (missing.length) throw new Error(`pptx-filler: パターン"${patternKey}"に必要なトークンが不足しています: ${missing.join(', ')}`);
  if (unknown.length) throw new Error(`pptx-filler: パターン"${patternKey}"に存在しないトークンが指定されました: ${unknown.join(', ')}`);
  return tokensRequired.filter((t) => optionalTokens.has(t) && !provided.has(t));
}

/** patternLibrary(loadPatternLibraryの戻り値)とspecから、出力.pptxのパーツ一式(Map<partName,Buffer>)を組み立てる。
 *  pkgは部品ライブラリを readZip した Map<partName,Buffer>。 */
export function buildOutputPackage(pkg, patternLibrary, spec) {
  const instances = spec.slides || [];
  if (!instances.length) throw new Error('pptx-filler: spec.slides が空です');

  const outParts = new Map();
  const ALWAYS_COPY = ['_rels/.rels', 'docProps/core.xml', 'docProps/app.xml', 'ppt/presProps.xml', 'ppt/viewProps.xml', 'ppt/tableStyles.xml'];
  for (const name of ALWAYS_COPY) if (pkg.has(name)) outParts.set(name, pkg.get(name));

  const usedPatternKeys = [...new Set(instances.map((s) => s.pattern))];
  const sharedPartNames = new Set();
  for (const key of usedPatternKeys) {
    const pattern = patternLibrary[key];
    if (!pattern) throw new Error(`pptx-filler: 未知のパターンです: ${key}`);
    const c = pattern.closure;
    for (const name of [c.layoutPartName, c.layoutRelsPartName, c.masterPartName, c.masterRelsPartName, c.themePartName, ...c.mediaPartNames]) {
      if (name) sharedPartNames.add(name);
    }
  }
  for (const name of sharedPartNames) {
    if (!pkg.has(name)) throw new Error(`pptx-filler: 想定パーツが見つかりません: ${name}`);
    outParts.set(name, pkg.get(name));
  }

  const slideTargets = [];
  instances.forEach((inst, idx) => {
    const i = idx + 1;
    const pattern = patternLibrary[inst.pattern];
    if (!pattern) throw new Error(`pptx-filler: 未知のパターンです: ${inst.pattern}`);
    const missingOptional = validateTokens(inst.pattern, pattern.tokens, pattern.optionalTokens, inst.tokens);
    const trimmed = removeParagraphsWithTokens(pattern.slideXml.toString('utf8'), missingOptional);
    const xml = substituteTokens(trimmed, inst.tokens);
    outParts.set(`ppt/slides/slide${i}.xml`, Buffer.from(xml, 'utf8'));
    if (pattern.slideRelsXml != null) {
      // ノート(notesSlide)は取り込んでいない→参照だけ残るダングリング関連付けを避けるため削除。
      const rels = stripRelsByTypeSuffix(pattern.slideRelsXml.toString('utf8'), 'notesSlide');
      outParts.set(`ppt/slides/_rels/slide${i}.xml.rels`, Buffer.from(rels, 'utf8'));
    }
    slideTargets.push(`slides/slide${i}.xml`);
  });

  // [Content_Types].xml: 旧slide用Overrideを全削除し、新しい採番で作り直す。他のOverrideも
  // 「対応するパーツをoutPartsへ実際にコピーした場合のみ」残す(Defaultはextension単位なので無条件で残す)。
  let ct = pkg.get('[Content_Types].xml').toString('utf8');
  ct = ct.replace(/<Override PartName="\/ppt\/slides\/slide\d+\.xml"[^>]*\/>/g, '');
  ct = ct.replace(/<Override PartName="([^"]+)"[^>]*\/>/g, (m, partName) => {
    const name = partName.replace(/^\//, '');
    // ppt/presentation.xml自体は必ず後段で書き出すので、この時点でoutPartsに未登録でも残す。
    if (name === 'ppt/presentation.xml') return m;
    return outParts.has(name) ? m : '';
  });
  const overrides = slideTargets.map((_, idx) =>
    `<Override PartName="/ppt/slides/slide${idx + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>`
  ).join('');
  ct = ct.replace('</Types>', overrides + '</Types>');
  outParts.set('[Content_Types].xml', Buffer.from(ct, 'utf8'));

  // ppt/_rels/presentation.xml.rels: slide関連付けは作り直すため除外。他は「参照先パーツを実際に
  // outPartsへコピーした場合のみ」残す(notesMaster/handoutMaster/commentAuthors等、取り込んでいない
  // パーツへのダングリング関連付けを型ごとに個別列挙せず一般化して防ぐ)。
  const relsXml = pkg.get('ppt/_rels/presentation.xml.rels').toString('utf8');
  const keptRels = [];
  let maxRid = 0;
  relsXml.replace(/<Relationship\s+([^>]*?)\/>/g, (m, attrs) => {
    const idNum = Number((attrs.match(/Id="rId(\d+)"/) || [])[1] || 0);
    if (idNum > maxRid) maxRid = idNum;
    const type = (attrs.match(/Type="([^"]*)"/) || [])[1] || '';
    const target = (attrs.match(/Target="([^"]*)"/) || [])[1] || '';
    if (type === REL_TYPE_SLIDE) return '';
    if (outParts.has(resolveTarget('ppt/presentation.xml', target))) keptRels.push(m);
    return '';
  });
  const newRelEntries = slideTargets.map((target, idx) => ({ rId: `rId${maxRid + 1 + idx}`, target }));
  const newRelTags = newRelEntries.map((e) => `<Relationship Id="${e.rId}" Type="${REL_TYPE_SLIDE}" Target="${e.target}"/>`);
  const newRelsXml = relsXml.replace(
    /(<Relationships[^>]*>)[\s\S]*(<\/Relationships>)/,
    (m0, open, close) => open + keptRels.join('') + newRelTags.join('') + close
  );
  outParts.set('ppt/_rels/presentation.xml.rels', Buffer.from(newRelsXml, 'utf8'));

  // ppt/presentation.xml: <p:sldIdLst> を新しいスライド一覧で作り直し、
  // <p:notesMasterIdLst> は取り込んでいないnotesMasterへの参照なので削除する(他は素通し)。
  const presXml = pkg.get('ppt/presentation.xml').toString('utf8');
  const sldIdTags = newRelEntries.map((e, idx) => `<p:sldId id="${256 + idx}" r:id="${e.rId}"/>`).join('');
  const newPresXml = presXml
    .replace(/<p:sldIdLst>[\s\S]*?<\/p:sldIdLst>/, `<p:sldIdLst>${sldIdTags}</p:sldIdLst>`)
    .replace(/<p:notesMasterIdLst>[\s\S]*?<\/p:notesMasterIdLst>/, '');
  outParts.set('ppt/presentation.xml', Buffer.from(newPresXml, 'utf8'));

  return outParts;
}
