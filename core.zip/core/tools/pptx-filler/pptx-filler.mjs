/* ================================================================
 * pptx-filler.mjs — 汎用PPTXテンプレート差し込みエンジン(公開API)。
 *
 * 使い方:
 *   const lib = loadPatternLibrary('templates/parts-library.pptx', 'templates/manifest.json');
 *   const deck = renderDeck({ slides: [{ pattern: 'title-bullets', tokens: {...} }, ...] }, lib);
 *   save(deck, 'out/result.pptx');
 *
 * Marp Studioを含む他ツールへの依存は一切無い(core/tools/marp/* を import しない)。
 * 新規npm依存も無い(zip.mjsは依存ゼロの手書き実装)。
 * ================================================================ */
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { dirname } from 'node:path';
import { readZip, writeZip } from './zip.mjs';
import { collectPatternClosure, buildOutputPackage } from './ooxml.mjs';
import { discoverTokens } from './tokens.mjs';

/** 部品ライブラリ(.pptx)とmanifest(パターン名→スライド番号)を読み込み、
 *  パターン名→PatternTemplate の辞書を返す。
 *  戻り値には `__pkg`(readZipしたMap<partName,Buffer>そのもの)も併せて載せてある。 */
export function loadPatternLibrary(pptxPath, manifestPath) {
  const pkg = readZip(readFileSync(pptxPath));
  const manifest = JSON.parse(readFileSync(manifestPath, 'utf8'));

  const library = {};
  for (const [key, entry] of Object.entries(manifest)) {
    const sourceSlidePartName = `ppt/slides/slide${entry.slideIndex}.xml`;
    const slideXml = pkg.get(sourceSlidePartName);
    if (!slideXml) throw new Error(`pptx-filler: パターン"${key}"のスライドが見つかりません(${sourceSlidePartName})`);
    const closure = collectPatternClosure(pkg, sourceSlidePartName);
    const slideRelsXml = pkg.get(closure.slideRelsPartName) || null;
    library[key] = {
      key,
      sourceSlidePartName,
      slideXml,
      slideRelsXml,
      tokens: discoverTokens(slideXml.toString('utf8')),
      optionalTokens: new Set(entry.optional || []),
      closure,
    };
  }
  Object.defineProperty(library, '__pkg', { value: pkg, enumerable: false });
  return library;
}

/** specに従い、patternLibraryのパターンを差し込んだ出力パッケージ(Map<partName,Buffer>)を返す。
 *  まだZIP化していない(save()でZIP化してファイルへ書き出す)。 */
export function renderDeck(spec, patternLibrary) {
  const pkg = patternLibrary.__pkg;
  if (!pkg) throw new Error('pptx-filler: patternLibraryはloadPatternLibrary()の戻り値を渡してください');
  return buildOutputPackage(pkg, patternLibrary, spec);
}

/** renderDeck()の戻り値をZIP化して.pptxとして書き出す。 */
export function save(deckParts, outPath) {
  const entries = [...deckParts.entries()].map(([name, data]) => ({ name, data }));
  const buf = writeZip(entries);
  mkdirSync(dirname(outPath), { recursive: true });
  writeFileSync(outPath, buf);
}
