# pptx-filler

人間がPowerPointで作った「部品テンプレート」に、プログラムから`{{TOKEN}}`を差し込んで
編集可能な.pptxを組み立てる、汎用の(Marp Studioに依存しない)PPTX差し込みエンジン。

見た目の作り込みは人間(PowerPoint)、構成とテキストの差し込みはプログラムが担当する
役割分担を前提にしている。新規npm依存は無い(ZIP読み書きは手書き実装)。

## 使い方

```js
import { loadPatternLibrary, renderDeck, save } from './pptx-filler.mjs';

const lib = loadPatternLibrary('templates/parts-library.pptx', 'templates/manifest.json');

const deck = renderDeck({
  slides: [
    { pattern: 'title-bullets', tokens: { TITLE: '進捗サマリー', BODY1: '…', BODY2: '…', BODY3: '…' } },
    { pattern: 'three-cards', tokens: {
        TITLE: '検討の柱',
        CARD1_TITLE: '…', CARD1_BODY: '…',
        CARD2_TITLE: '…', CARD2_BODY: '…',
        CARD3_TITLE: '…', CARD3_BODY: '…' } },
  ],
}, lib);

save(deck, 'out/result.pptx');
```

- `loadPatternLibrary(pptxPath, manifestPath)` — 部品ライブラリ(.pptx)とmanifest(パターン名→スライド番号)を読み込み、パターン名→PatternTemplateの辞書を返す。
- `renderDeck(spec, patternLibrary)` — specの各スライドが指定するパターンを複製・トークン差し替えし、出力パッケージ(未ZIP化)を返す。未提供・未知のトークンがあれば例外を投げる(誤字ガード)。
- `save(deckParts, outPath)` — 出力パッケージをZIP化して.pptxとして書き出す。

## 部品テンプレートの著作ガイドライン

- 1つの`parts-library.pptx`に全パターンをまとめる(テーマ/マスタを共有させ、パターン間の見た目の食い違いを防ぐ)。
- プレースホルダは通常のテキストボックスに`{{TOKEN}}`という**リテラル文字列**を直接入力する(PowerPointのプレースホルダ機能ではない)。トークン名は英大文字・数字・アンダースコアのみ。
- `{{TOKEN}}`を入力したら、以下のいずれかを行うとプログラム側の置換が確実になる:
  - 一息に(訂正やオートコレクトを挟まず)入力する
  - 入力後にテキストボックス全体を選択して「書式のクリア」→ 意図した書式を再適用する
  
  (PowerPointは書式境界やスペルチェックの都合でテキストを複数の内部ランに分割することがあり、
  訂正を挟むとトークン文字列がラン境界で分断されやすくなる。エンジン側にも分断への対応(段落単位の
  ラン結合スキャン)はあるが、保険であり主対策ではない。)
- 新しいパターンを追加したら、`templates/manifest.json`に1行(`"パターン名": {"slideIndex": N}`)追加するだけでよい。トークン名は自動検出される。

## この版の既知の制約

- ノート(発表者メモ)は差し込み対象外(notesSlide/notesMasterへの関連付けは出力時に取り除く)。
- `docProps/app.xml`のスライド枚数等のメタデータは元テンプレートの値のまま(PowerPointが次回保存時に再計算するため実害は無い)。
- Marp Studioへの組み込み(Markdownのdiv語彙からパターンへのマッピング)は別作業として扱う。

## `templates/parts-library.pptx` の出典

IBM Consulting公式PPTテンプレート(`202203 PPT template 正式版/IBM Consulting_JP_Template_Arial_202203.pptx`)の
レイアウト「title, text」「title, text (four columns)」(4列中3列を使用)を、pptx-filler自身の
`loadPatternLibrary`/`renderDeck`で該当2スライドの閉包(テーマ/マスタ/レイアウト)だけを刈り込んで
作成した。見た目(配色・タイポグラフィの階層)はIBM公式デザインをそのまま継承しており、pptxgenjsで
ゼロから組んだ簡易版より本来の品質に近い。

**配布時の注意**: これはIBM社内の公式テンプレート資産の一部を切り出したものなので、このリポジトリの
外(Marp Studioの配布zip・共有リポジトリ・お客様共有領域等)へ持ち出す前には、その配布先が
IBM社内限定か、お客様/社外にも渡るのかを確認すること。ローカルのみでの利用・検証はこの限りでない。
