/* ================================================================
 * zip.mjs — 依存ゼロの手書きZIPリーダー/ライター。
 *
 * 入力(readZip)は「自分たちが作るPowerPoint製.pptx」のみを想定し、敵対的な入力を
 * 想定しない（ZIP64/暗号化/分割アーカイブ/LZMA等は扱わない）。
 * ライター(writeZip)は core/tools/marp/marp-deck.mjs の writeZipFile と対で、
 * ファイル書き出しをしない版（Buffer を返すだけ）。
 * ================================================================ */
import { deflateRawSync, inflateRawSync } from 'node:zlib';

const EOCD_SIG = 0x06054b50;
const CD_SIG = 0x02014b50;
const LFH_SIG = 0x04034b50;
const UTF8_FLAG = 0x0800;

/** .pptx等のZIPバッファを展開し、Map<partName, Buffer> を返す。 */
export function readZip(buffer) {
  const eocdOffset = findEocd(buffer);
  if (eocdOffset < 0) throw new Error('zip: End Of Central Directory が見つかりません');
  const totalEntries = buffer.readUInt16LE(eocdOffset + 10);
  const cdSize = buffer.readUInt32LE(eocdOffset + 12);
  const cdOffset = buffer.readUInt32LE(eocdOffset + 16);
  if (cdOffset + cdSize > eocdOffset) throw new Error('zip: central directory の範囲が不正です');

  const out = new Map();
  let p = cdOffset;
  for (let i = 0; i < totalEntries; i++) {
    if (buffer.readUInt32LE(p) !== CD_SIG) throw new Error(`zip: central directory署名が不正です(entry ${i})`);
    const flags = buffer.readUInt16LE(p + 8);
    const method = buffer.readUInt16LE(p + 10);
    const compSize = buffer.readUInt32LE(p + 20);
    const nameLen = buffer.readUInt16LE(p + 28);
    const extraLen = buffer.readUInt16LE(p + 30);
    const commentLen = buffer.readUInt16LE(p + 32);
    const localOffset = buffer.readUInt32LE(p + 42);
    const nameBuf = buffer.subarray(p + 46, p + 46 + nameLen);
    const name = (flags & UTF8_FLAG) ? nameBuf.toString('utf8') : nameBuf.toString('latin1');

    const data = readLocalEntryData(buffer, localOffset, method, compSize);
    out.set(name, data);
    p += 46 + nameLen + extraLen + commentLen;
  }
  return out;
}

function findEocd(buffer) {
  const minScan = Math.max(0, buffer.length - 22 - 0xffff);
  for (let i = buffer.length - 22; i >= minScan; i--) {
    if (buffer.readUInt32LE(i) === EOCD_SIG) return i;
  }
  return -1;
}

function readLocalEntryData(buffer, localOffset, method, compSize) {
  if (buffer.readUInt32LE(localOffset) !== LFH_SIG) throw new Error('zip: local file header 署名が不正です');
  const nameLen = buffer.readUInt16LE(localOffset + 26);
  const extraLen = buffer.readUInt16LE(localOffset + 28);
  const dataStart = localOffset + 30 + nameLen + extraLen;
  const compressed = buffer.subarray(dataStart, dataStart + compSize);
  if (method === 0) return Buffer.from(compressed);
  if (method === 8) return inflateRawSync(compressed);
  throw new Error(`zip: 未対応の圧縮方式です(method=${method})`);
}

/** entries=[{name, data:Buffer}] からZIPバッファを組み立てる（UTF-8フラグ付き / deflate）。
 *  core/tools/marp/marp-deck.mjs の writeZipFile と同じ手書きZIP実装（ファイル書き出しはしない版）。 */
export function writeZip(entries) {
  const CRCT = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
  const crc32 = (b) => { let c = 0xFFFFFFFF; for (let i = 0; i < b.length; i++) c = CRCT[(c ^ b[i]) & 0xff] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; };
  const FLAG = 0x0800, METHOD = 8, DOSDATE = 0x0021, DOSTIME = 0;
  const parts = [], central = []; let offset = 0;
  for (const e of entries) {
    const nameBuf = Buffer.from(e.name, 'utf8');
    const comp = deflateRawSync(e.data); const crc = crc32(e.data);
    const lh = Buffer.alloc(30);
    lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(FLAG, 6); lh.writeUInt16LE(METHOD, 8);
    lh.writeUInt16LE(DOSTIME, 10); lh.writeUInt16LE(DOSDATE, 12); lh.writeUInt32LE(crc, 14);
    lh.writeUInt32LE(comp.length, 18); lh.writeUInt32LE(e.data.length, 22); lh.writeUInt16LE(nameBuf.length, 26); lh.writeUInt16LE(0, 28);
    parts.push(lh, nameBuf, comp);
    const cd = Buffer.alloc(46);
    cd.writeUInt32LE(0x02014b50, 0); cd.writeUInt16LE((3 << 8) | 20, 4); cd.writeUInt16LE(20, 6); cd.writeUInt16LE(FLAG, 8);
    cd.writeUInt16LE(METHOD, 10); cd.writeUInt16LE(DOSTIME, 12); cd.writeUInt16LE(DOSDATE, 14); cd.writeUInt32LE(crc, 16);
    cd.writeUInt32LE(comp.length, 20); cd.writeUInt32LE(e.data.length, 24); cd.writeUInt16LE(nameBuf.length, 28);
    cd.writeUInt16LE(0, 30); cd.writeUInt16LE(0, 32); cd.writeUInt16LE(0, 34); cd.writeUInt16LE(0, 36);
    cd.writeUInt32LE(((0o100644) << 16) >>> 0, 38); cd.writeUInt32LE(offset, 42);
    central.push(cd, nameBuf); offset += lh.length + nameBuf.length + comp.length;
  }
  const cdBuf = Buffer.concat(central); const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0); eocd.writeUInt16LE(entries.length, 8); eocd.writeUInt16LE(entries.length, 10);
  eocd.writeUInt32LE(cdBuf.length, 12); eocd.writeUInt32LE(offset, 16);
  return Buffer.concat([...parts, cdBuf, eocd]);
}
