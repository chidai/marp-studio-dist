/* ================================================================
 * pptx-export.mjs — Marp デッキ(.md) を「できる限り編集可能な」PowerPoint(.pptx) へ変換（β）
 *
 * 方針（最優先＝編集可能性）:
 *   - 原則すべてネイティブ要素で組む（選択・編集できる）。スライドを丸ごと画像に落とすことはしない。
 *   - テーマの語彙 div（lead-area / columns / content-wrapper / content-box / fusen）→ テキストボックス/図形。
 *   - 表（Markdown表 / 生HTML表 / catalog生成表）→ ネイティブの編集可能な表（色は失うが編集を優先）。
 *   - 見出し・箇条書き・段落 → 編集可能テキスト。表紙/中表紙/背表紙も文字はネイティブ。
 *   - 図（画像 / Mermaid）→ その図だけを画像として埋め込む（周囲の文字は編集可能のまま）。
 *   - 依存 PptxGenJS(MIT) は同梱せず、初回に自動インストール。
 *
 * 座標系: base.css は 1280x720(=96dpi) 設計 → in = px/96、pt = px*0.75。
 * ================================================================ */
import { existsSync, readFileSync, mkdirSync, writeFileSync } from 'node:fs';
import { join, dirname, basename, resolve, isAbsolute } from 'node:path';
import { execSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { loadBrand, mermaidCodeToSvgFile } from './marp-deck.mjs';
import { classifyDeck } from './pptx-filler-classify.mjs';
import { loadPatternLibrary, renderDeck, save as saveFillerDeck } from '../pptx-filler/pptx-filler.mjs';

const __dirname = dirname(fileURLToPath(import.meta.url));
const DEPS_DIR = join(__dirname, '.deps');   // 自動インストール先（.gitignore / make-dist で除外）
const FILLER_TEMPLATES_DIR = join(__dirname, '..', 'pptx-filler', 'templates');

const PAGE_W = 13.333, PAGE_H = 7.5;
const MX = 0.55, TOP = 0.4;
const FONT = 'Yu Gothic';   // 游ゴシック（Win/Mac 両方に存在）。Mac専用フォント依存を回避。
const C = { accent: '0F62FE', ink: '161616', sub: '4A4A4A', leadBg: 'E5F6FF', boxLine: '858484', subtle: '6F6F6F', head: 'F4F4F4' };
const LAYOUT_CLASSES = ['cover', 'section', 'closing', 'title'];
const FUSEN_FILL = { yellow: 'FFF176', blue: '81D4FA', pink: 'F48FB1', green: 'A5D6A7' };
const FUSEN_BAR  = { yellow: 'FBC02D', blue: '0288D1', pink: 'C2185B', green: '388E3C' };
const FUSEN_W = { small: 150, large: 450, wide: 600 };

/* -------- PptxGenJS の自動インストール＆読込 -------- */
export function isPptxReady({ depsDir = DEPS_DIR } = {}) {
  try { pptxRequire(depsDir)('pptxgenjs'); return true; } catch { return false; }
}
function pptxRequire(depsDir) {
  const pkg = join(depsDir, 'package.json');
  if (!existsSync(depsDir)) mkdirSync(depsDir, { recursive: true });
  if (!existsSync(pkg)) writeFileSync(pkg, JSON.stringify({ name: 'marp-studio-deps', private: true, version: '1.0.0' }, null, 2));
  return createRequire(pkg);
}
export function ensurePptxGenJS({ depsDir = DEPS_DIR, log = console.log } = {}) {
  const req = pptxRequire(depsDir);
  try { return req('pptxgenjs'); } catch { /* 未取得 → インストールへ */ }
  log('PPTX部品(pptxgenjs)を初回インストールしています…（ネット接続が必要です）');
  try {
    execSync('npm install pptxgenjs@3 --no-audit --no-fund --loglevel=error', { cwd: depsDir, stdio: 'pipe', windowsHide: true });
  } catch (e) {
    const detail = ((e && (e.stderr || e.stdout))?.toString() || e.message || '').slice(0, 500);
    const err = new Error('PPTX部品の取得に失敗しました。ネット接続をご確認ください（PDFは引き続き利用できます）。\n' + detail);
    err.code = 'PPTX_INSTALL_FAILED';
    throw err;
  }
  return req('pptxgenjs');
}

/* -------- 変換本体 -------- */
export async function exportPptx(mdPath, { log = console.log, depsDir = DEPS_DIR } = {}) {
  mdPath = resolve(mdPath);
  if (!existsSync(mdPath)) throw new Error('not found: ' + mdPath);
  const deckDir = dirname(mdPath);
  const out = join(deckDir, 'out', basename(mdPath).replace(/\.md$/, '.pptx'));
  mkdirSync(dirname(out), { recursive: true });

  // デッキ全体がpptx-fillerの既存パターン(title-bullets/three-cards)だけで表現できるなら、
  // IBM公式テンプレート由来の美麗な出力を使う。1枚でも非対応(表紙・fusen・表・画像等)が
  // あれば null が返るので、その場合は以下の既存ネイティブ描画へそのままフォールバックする。
  const fillerSpec = classifyDeck(readFileSync(mdPath, 'utf8'));
  if (fillerSpec) {
    try {
      const lib = loadPatternLibrary(join(FILLER_TEMPLATES_DIR, 'parts-library.pptx'), join(FILLER_TEMPLATES_DIR, 'manifest.json'));
      const deck = renderDeck(fillerSpec, lib);
      saveFillerDeck(deck, out);
      return { out };
    } catch (e) {
      log('pptx-filler経路に失敗（既存の描画方式にフォールバックします）: ' + e.message);
    }
  }

  const brand = loadBrand(deckDir);
  const PptxGenJS = ensurePptxGenJS({ depsDir, log });

  // 図の前処理: ```mermaid フェンスを htmlLabels無効のSVG化し ![](svg) 参照へ置換。
  // SVGにすると PowerPoint でグループ解除→「矢印＋テキスト入りBox」に分解でき、編集可能な図になる。
  let content = readFileSync(mdPath, 'utf8');
  try { content = preprocessMermaid(mdPath, deckDir, log); } catch (e) { log('mermaid前処理スキップ: ' + e.message); }

  const slides = splitSlides(content);
  const pptx = new PptxGenJS();
  pptx.defineLayout({ name: 'MARP', width: PAGE_W, height: PAGE_H });
  pptx.layout = 'MARP';
  // 既定フォント: Win/Mac 両方にある「游ゴシック」。Mac専用フォント依存を避ける（Winで別物にならないように）。
  // 本格的な体裁は「スライドマスタ入りPPTXに貼り付け」で継承させるのが最善（ガイド参照）。
  try { pptx.theme = { headFontFace: FONT, bodyFontFace: FONT }; } catch {}

  for (const s of slides) {
    const slide = pptx.addSlide();
    try {
      if (LAYOUT_CLASSES.includes(s.cls)) renderTitleSlide(pptx, slide, s, brand);
      else renderContentSlide(pptx, slide, s, brand, deckDir);
    } catch (e) {
      log('スライド描画に失敗（簡易表示にします）: ' + e.message);
      slide.addText('(この内容はβ変換で表示できませんでした。編集元のMarkdownをご確認ください)',
        { x: 0.6, y: 0.6, w: PAGE_W - 1.2, h: 1, fontSize: 12, color: 'DA1E28' });
    }
  }
  await pptx.writeFile({ fileName: out });
  return { out };
}

/* ```mermaid フェンスを PNG 化して ![](png) 参照へ置換した md文字列を返す（コード内容のハッシュでキャッシュ）。 */
function preprocessMermaid(mdPath, deckDir, log) {
  const src = readFileSync(mdPath, 'utf8');
  const re = /^([ \t]*)```mermaid[ \t]*([^\n]*)\n([\s\S]*?)\n[ \t]*```[ \t]*$/gm;
  if (!re.test(src)) return src;
  re.lastIndex = 0;
  const fdir = join(deckDir, 'assets', '.fences');
  mkdirSync(fdir, { recursive: true });
  return src.replace(re, (m, indent, opts, code) => {
    const hash = createHash('sha1').update(code).digest('hex').slice(0, 16);
    const rel = `assets/.fences/fence-pptx-${hash}.svg`, svg = join(deckDir, rel);
    if (!existsSync(svg)) {
      try { mermaidCodeToSvgFile(code, svg); }
      catch (e) { log('Mermaid SVG化に失敗（該当図はコードのまま）: ' + (e.detail || e.message)); return m; }
    }
    return `${indent}![](${rel})`;
  });
}

/* -------- スライド分割 -------- */
export function splitSlides(raw) {
  let body = raw.replace(/^﻿/, '');
  const fm = body.match(/^---\r?\n[\s\S]*?\r?\n---\r?\n/);
  if (fm) body = body.slice(fm[0].length);
  return body.split(/^---[ \t]*$/m).map((text) => {
    const cls = (text.match(/<!--\s*_class:\s*([a-zA-Z0-9_-]+)/) || [])[1] || '';
    return { body: text, cls };
  });
}

/* -------- 表紙/中表紙/背表紙/タイトル（文字はネイティブで中央寄せ）-------- */
function renderTitleSlide(pptx, slide, s, brand) {
  if (s.cls === 'section' || s.cls === 'title') slide.background = { color: 'F2F4F8' };
  const blocks = parseBlocks(stripDivTags(s.body.replace(/<!--[\s\S]*?-->/g, '')), '');
  const h1 = blocks.find((b) => b.type === 'heading' && b.level === 1);
  const h2 = blocks.find((b) => b.type === 'heading' && b.level === 2);
  const h3 = blocks.find((b) => b.type === 'heading' && b.level === 3);
  const cy = s.cls === 'cover' ? 2.5 : 2.8;
  if (h1) slide.addText(inlineRuns(h1.text), { x: 0.8, y: cy, w: PAGE_W - 1.6, h: 1.0, fontSize: s.cls === 'cover' ? 34 : 30, bold: true, color: C.ink, align: 'center', valign: 'middle' });
  if (s.cls === 'cover') slide.addShape(pptx.ShapeType.line, { x: PAGE_W / 2 - 2, y: cy + 1.02, w: 4, h: 0, line: { color: C.accent, width: 3 } });
  if (h2) slide.addText(inlineRuns(h2.text), { x: 0.8, y: cy + 1.1, w: PAGE_W - 1.6, h: 0.6, fontSize: 18, color: C.sub, align: 'center' });
  if (h3) slide.addText(inlineRuns(h3.text), { x: 0.8, y: cy + 1.75, w: PAGE_W - 1.6, h: 0.5, fontSize: 13, color: C.subtle, align: 'center' });
  // 表紙/中表紙にも付箋(注記)が置かれることがある＝落とさずネイティブ図形で描く。
  for (const tok of extractDivs(s.body.replace(/<!--[\s\S]*?-->/g, ''))) {
    if (tok.kind === 'div' && /\bfusen\b/.test(tok.cls || '')) {
      renderFusen(pptx, slide, { cls: tok.cls, styleRaw: (tok.attrs.match(/style\s*=\s*"([^"]*)"/i) || [])[1] || '', text: mdText(tok.inner) });
    }
  }
  if (brand && brand.footer) slide.addText(brand.footer, { x: 0.8, y: PAGE_H - 0.4, w: PAGE_W - 1.6, h: 0.3, fontSize: 8, color: C.subtle, align: 'right' });
}

/* -------- コンテンツスライド -------- */
function renderContentSlide(pptx, slide, s, brand, deckDir) {
  const body = s.body.replace(/<!--[\s\S]*?-->/g, '');
  const { title, segments, fusens } = parseSegments(body);
  const cw = PAGE_W - 2 * MX;
  let y = TOP;
  if (title) {
    slide.addText(inlineRuns(title), { x: MX, y, w: cw, h: 0.6, fontSize: 24, bold: true, color: C.ink, valign: 'middle' });
    slide.addShape(pptx.ShapeType.line, { x: MX, y: y + 0.62, w: cw, h: 0, line: { color: C.accent, width: 2 } });
    y += 0.82;
  }
  const footerY = PAGE_H - 0.4;
  for (const seg of segments) {
    if (y > footerY - 0.3) break;
    const avail = footerY - y - 0.1;
    if (seg.type === 'lead') {
      const h = Math.min(1.6, 0.35 + estTextH(seg.text, cw));
      // 箱＋中のテキストを1オブジェクトに（shapeにテキストを持たせる）。アクセントバーは付けない。
      slide.addText(inlineRuns(seg.text), { shape: pptx.ShapeType.rect, x: MX, y, w: cw, h, fill: { color: C.leadBg }, fontSize: 12, color: C.ink, valign: 'middle', align: 'left', margin: [4, 10, 4, 10] });
      y += h + 0.12;
    } else if (seg.type === 'cols') {
      const n = seg.cols.length || 1;
      const gap = 0.2, colW = (cw - gap * (n - 1)) / n, h = avail;
      seg.cols.forEach((blocks, k) => {
        const cx = MX + k * (colW + gap);
        if (seg.boxed) slide.addShape(pptx.ShapeType.rect, { x: cx, y, w: colW, h, line: { color: C.boxLine, width: 1.5 }, fill: { color: 'FFFFFF' } });
        renderBlocks(pptx, slide, blocks, cx + 0.15, y + 0.12, colW - 0.3, 11, deckDir);
      });
      y += h;
    } else { // md
      y = renderBlocks(pptx, slide, seg.blocks, MX, y, cw, 12, deckDir);
    }
  }
  fusens.forEach((f) => renderFusen(pptx, slide, f));
  if (brand && brand.footer) slide.addText(brand.footer, { x: MX, y: footerY, w: cw, h: 0.3, fontSize: 8, color: C.subtle, align: 'right' });
}

/* body を title / 語彙div / markdown断片へ分解 */
export function parseSegments(body) {
  let title = '';
  const segments = [], fusens = [];
  for (const tok of extractDivs(body)) {
    if (tok.kind === 'div') {
      const cls = tok.cls || '';
      if (/\bfusen\b/.test(cls)) { fusens.push({ cls, styleRaw: (tok.attrs.match(/style\s*=\s*"([^"]*)"/i) || [])[1] || '', text: mdText(tok.inner) }); continue; }
      if (/\blead-area\b/.test(cls)) { segments.push({ type: 'lead', text: mdText(tok.inner) }); continue; }
      if (/\bcolumns\b|\bcontent-wrapper\b/.test(cls)) {
        const children = extractDivs(tok.inner).filter((c) => c.kind === 'div');
        const cols = (children.length ? children : [{ inner: tok.inner }]).map((c) => parseBlocks(mdText(c.inner), ''));
        segments.push({ type: 'cols', cols, boxed: /content-wrapper|content-box/.test(cls + children.map((c) => c.cls).join(' ')) });
        continue;
      }
      segments.push({ type: 'md', blocks: parseBlocks(mdText(tok.inner), '') });
    } else {
      for (const b of parseBlocks(tok.text, '')) {
        if (!title && b.type === 'heading' && b.level === 1) { title = b.text; continue; }
        segments.push({ type: 'md', blocks: [b] });
      }
    }
  }
  return { title, segments, fusens };
}

/* <div>…</div> を釣り合いを取って抽出 */
function extractDivs(text) {
  const tokens = [];
  let i = 0;
  while (i < text.length) {
    const m = text.slice(i).match(/<div\b([^>]*)>/i);
    if (!m) { tokens.push({ kind: 'text', text: text.slice(i) }); break; }
    const start = i + m.index;
    if (start > i) tokens.push({ kind: 'text', text: text.slice(i, start) });
    const cls = (m[1].match(/class\s*=\s*"([^"]*)"/i) || [])[1] || '';
    const contentStart = start + m[0].length;
    const tagRe = /<(\/?)div\b[^>]*>/ig; tagRe.lastIndex = start;
    let depth = 0, innerEnd = -1, end = -1, mm;
    while ((mm = tagRe.exec(text))) {
      if (mm[1] === '') depth++;
      else { depth--; if (depth === 0) { innerEnd = mm.index; end = tagRe.lastIndex; break; } }
    }
    if (end === -1) { tokens.push({ kind: 'text', text: text.slice(start) }); break; }
    tokens.push({ kind: 'div', cls, attrs: m[1] || '', inner: text.slice(contentStart, innerEnd) });
    i = end;
  }
  return tokens;
}

/* markdown断片 → ブロック列（heading / list / mdtable / htmltable / image / para） */
function parseBlocks(md) {
  const lines = md.replace(/\r/g, '').split('\n');
  const blocks = [];
  for (let i = 0; i < lines.length; i++) {
    const ln = lines[i];
    if (ln.trim() === '') continue;
    let m;
    // 生HTML表（catalog含む）: <table>..</table> をまとめてネイティブ表へ
    if (/<table\b/i.test(ln)) {
      let chunk = ln, j = i;
      while (j < lines.length && !/<\/table>/i.test(chunk)) { j++; chunk += '\n' + (lines[j] || ''); }
      i = j;
      const rows = parseHtmlTable(chunk);
      if (rows.length) blocks.push({ type: 'table', rows });
      continue;
    }
    if ((m = ln.match(/^\s*(#{1,6})\s+(.*)$/))) { blocks.push({ type: 'heading', level: m[1].length, text: m[2] }); continue; }
    if ((m = ln.match(/^\s*!\[[^\]]*\]\(([^)\s]+)/))) { blocks.push({ type: 'image', path: m[1], bg: /!\[[^\]]*bg/i.test(ln) }); continue; }
    if (/^\s*\|.*\|\s*$/.test(ln)) {
      const rows = [];
      while (i < lines.length && /^\s*\|.*\|\s*$/.test(lines[i])) { rows.push(lines[i]); i++; }
      i--;
      blocks.push({ type: 'table', rows: parseMdTable(rows) });
      continue;
    }
    if (/^\s*([-*+]|\d+[.)])\s+/.test(ln)) {
      const items = [];
      while (i < lines.length && /^\s*([-*+]|\d+[.)])\s+/.test(lines[i])) {
        const im = lines[i].match(/^(\s*)([-*+]|\d+[.)])\s+(.*)$/);
        items.push({ indent: Math.min(4, Math.floor(im[1].length / 2)), text: im[3] });
        i++;
      }
      i--;
      blocks.push({ type: 'list', items });
      continue;
    }
    blocks.push({ type: 'para', text: ln.trim() });
  }
  return blocks;
}
function parseMdTable(rows) {
  return rows
    .filter((r) => !/^\s*\|?[\s:|-]+\|?\s*$/.test(r))
    .map((r) => r.replace(/^\s*\|/, '').replace(/\|\s*$/, '').split('|').map((c) => c.trim()));
}
function parseHtmlTable(chunk) {
  const rows = [];
  const trs = chunk.match(/<tr\b[\s\S]*?<\/tr>/gi) || [];
  for (const tr of trs) {
    const cells = (tr.match(/<t[dh]\b[\s\S]*?<\/t[dh]>/gi) || []).map((c) => stripTags(c));
    if (cells.length) rows.push(cells);
  }
  return rows;
}

/* ブロック列を y から縦に描画し、次の y(推定) を返す */
function renderBlocks(pptx, slide, blocks, x, y, w, baseFont, deckDir) {
  for (const b of blocks) {
    if (y > PAGE_H - 0.5) break;
    if (b.type === 'heading') {
      slide.addText(inlineRuns(b.text), { x, y, w, h: 0.3, fontSize: b.level <= 2 ? baseFont + 2 : baseFont, bold: true, color: C.ink, valign: 'top' });
      y += 0.34;
    } else if (b.type === 'para') {
      const h = estTextH(b.text, w);
      slide.addText(inlineRuns(b.text), { x, y, w, h, fontSize: baseFont, color: C.ink, valign: 'top' });
      y += h + 0.04;
    } else if (b.type === 'list') {
      const items = b.items.map((it) => ({ text: stripInlineHtml(it.text).replace(/[*_`]/g, ''), options: { bullet: true, indentLevel: it.indent, fontSize: baseFont, color: C.ink, breakLine: true } }));
      const h = Math.max(0.3, b.items.length * 0.26);
      slide.addText(items, { x, y, w, h, valign: 'top' });
      y += h + 0.04;
    } else if (b.type === 'table') {
      const rows = b.rows.map((r, ri) => r.map((c) => ({ text: String(c).replace(/\*\*/g, ''), options: { bold: ri === 0, fill: { color: ri === 0 ? C.head : 'FFFFFF' }, color: C.ink, fontSize: Math.max(8, baseFont - 2) } })));
      slide.addTable(rows, { x, y, w, border: { pt: 0.5, color: C.boxLine }, valign: 'middle', autoPage: false });
      y += Math.max(0.3, rows.length * 0.3) + 0.08;
    } else if (b.type === 'image') {
      const abs = isAbsolute(b.path) ? b.path : join(deckDir, b.path);
      if (existsSync(abs)) {
        if (b.bg) { try { slide.background = { path: abs }; } catch {} continue; }
        const h = Math.min(3.4, PAGE_H - 0.6 - y);
        try { slide.addImage({ path: abs, x, y, w: Math.min(w, 9), h, sizing: { type: 'contain', w: Math.min(w, 9), h } }); }
        catch (e) { slide.addText('[図: ' + basename(b.path) + '（埋め込めませんでした）]', { x, y, w, h: 0.3, fontSize: baseFont - 1, color: C.subtle }); }
        y += h + 0.1;
      }
    }
  }
  return y;
}

function renderFusen(pptx, slide, f) {
  const color = ['blue', 'pink', 'green', 'yellow'].find((c) => new RegExp('\\b' + c + '\\b').test(f.cls)) || 'yellow';
  const sizeKey = ['small', 'large', 'wide'].find((s) => new RegExp('\\b' + s + '\\b').test(f.cls));
  const w = (FUSEN_W[sizeKey] || 250) / 96, h = Math.max(0.7, estTextH(f.text, w) + 0.3);
  const style = f.styleRaw || '';
  const topPx = num(style.match(/top:\s*(\d+)/)), rightPx = num(style.match(/right:\s*(\d+)/)), leftPx = num(style.match(/left:\s*(\d+)/));
  const y = topPx != null ? topPx / 96 : 0.7;
  let x = PAGE_W - w - 0.5;
  if (rightPx != null) x = PAGE_W - rightPx / 96 - w;
  else if (leftPx != null) x = leftPx / 96;
  // 箱＋中のテキストを1オブジェクトに（付箋＝色付き矩形にテキストを持たせる）。アクセントバーは付けない。
  slide.addText(inlineRuns(f.text), { shape: pptx.ShapeType.rect, x, y, w, h, fill: { color: FUSEN_FILL[color] }, line: { color: FUSEN_FILL[color] }, shadow: { type: 'outer', blur: 4, offset: 2, angle: 90, color: '999999', opacity: 0.4 }, fontSize: 11, color: '3B2F00', valign: 'middle', align: 'center', margin: [4, 8, 4, 8] });
}

/* -------- テキスト小道具 -------- */
function stripDivTags(s) { return s.replace(/<\/?div[^>]*>/gi, ''); }
function stripTags(s) {
  return String(s).replace(/<br\s*\/?>/gi, ' ').replace(/<[^>]+>/g, '')
    .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&nbsp;/g, ' ').trim();
}
function stripInlineHtml(s) { return String(s).replace(/<br\s*\/?>/gi, '\n').replace(/<\/?(b|strong)>/gi, '**').replace(/<\/?(i|em)>/gi, '*').replace(/<[^>]+>/g, ''); }
function inlineRuns(str) {
  str = stripInlineHtml(String(str)).trim();
  const runs = [];
  const re = /\*\*(.+?)\*\*|`(.+?)`|\*(.+?)\*/g;
  let last = 0, m;
  while ((m = re.exec(str))) {
    if (m.index > last) runs.push({ text: str.slice(last, m.index) });
    if (m[1] != null) runs.push({ text: m[1], options: { bold: true } });
    else if (m[2] != null) runs.push({ text: m[2], options: { fontFace: 'Consolas' } });
    else runs.push({ text: m[3], options: { italic: true } });
    last = re.lastIndex;
  }
  if (last < str.length) runs.push({ text: str.slice(last) });
  return runs.length ? runs : [{ text: str }];
}
function mdText(inner) { return stripDivTags(inner).trim(); }
function estTextH(text, w = 6) { const lines = String(text).split('\n').reduce((a, l) => a + Math.max(1, Math.ceil((l.length * 0.09) / Math.max(1, w))), 0); return Math.max(0.3, lines * 0.26); }
function num(m) { return m ? Number(m[1]) : null; }
