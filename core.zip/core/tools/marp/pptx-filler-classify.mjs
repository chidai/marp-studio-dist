/* ================================================================
 * pptx-filler-classify.mjs — Marpデッキ全体が pptx-filler の既存パターン
 * (title-bullets / three-cards)だけで構成できるか判定する。
 *
 * 方針: スライド単位ではなく「デッキ全体」で判定する(all-or-nothing)。
 * 1枚でも非対応(表紙/区切り/クロージング・fusen・表・画像・列数≠3・
 * 箇条書き4個以上・ネスト箇条書き・混在レイアウト等)があれば null を返し、
 * 呼び出し側は既存のネイティブ描画(pptxgenjs)にデッキ全体をフォールバックする。
 * これにより、pptx-fillerが未対応のパターンに出会っても既存動作は一切変わらない。
 *
 * pptx-filler側にcover/section/closing用のパターンが増えたら、この判定を
 * 緩めて対応範囲を広げていく想定(段階的な拡張)。
 * ================================================================ */
import { splitSlides, parseSegments } from './pptx-export.mjs';

const HTML_TAG_RE = /<[a-zA-Z][^>]*>/;

/** インライン記法(**強調**・`code`・*斜体*)を素のテキストへ落とす。
 *  生HTMLが混在している場合は非対応と判断してnullを返す(呼び出し側で分類失敗として扱う)。 */
function plainText(text) {
  const s = String(text).trim();
  if (HTML_TAG_RE.test(s)) return null;
  return s.replace(/\*\*(.+?)\*\*/g, '$1').replace(/`(.+?)`/g, '$1').replace(/\*(.+?)\*/g, '$1').trim();
}

function classifyContentSlide(body) {
  const { title, segments, fusens } = parseSegments(body);
  if (!title || fusens.length || segments.length !== 1) return null;
  const titleText = plainText(title);
  if (titleText == null) return null;
  const seg = segments[0];

  if (seg.type === 'md') {
    const blocks = seg.blocks;
    if (blocks.length !== 1 || blocks[0].type !== 'list') return null;
    const items = blocks[0].items;
    if (items.length < 1 || items.length > 3 || !items.every((it) => it.indent === 0)) return null;
    const tokens = { TITLE: titleText };
    for (let i = 0; i < items.length; i++) {
      const t = plainText(items[i].text);
      if (t == null) return null;
      tokens[`BODY${i + 1}`] = t;
    }
    return { pattern: 'title-bullets', tokens };
  }

  if (seg.type === 'cols' && seg.cols.length === 3) {
    const tokens = { TITLE: titleText };
    for (let i = 0; i < 3; i++) {
      const colBlocks = seg.cols[i];
      if (colBlocks.length !== 2 || colBlocks[0].type !== 'heading' || colBlocks[1].type !== 'para') return null;
      const cardTitle = plainText(colBlocks[0].text);
      const cardBody = plainText(colBlocks[1].text);
      if (cardTitle == null || cardBody == null) return null;
      tokens[`CARD${i + 1}_TITLE`] = cardTitle;
      tokens[`CARD${i + 1}_BODY`] = cardBody;
    }
    return { pattern: 'three-cards', tokens };
  }

  return null;
}

/** Markdown全文を判定し、デッキ全体がpptx-fillerで表現できるならspec({slides:[...]})を、
 *  1枚でも非対応ならnullを返す。 */
export function classifyDeck(content) {
  const slides = splitSlides(content);
  if (!slides.length) return null;
  const result = [];
  for (const s of slides) {
    // cover/section/title/closingや未知の_classはpptx-filler側にパターンが無いため未対応。
    if (s.cls) return null;
    const body = s.body.replace(/<!--[\s\S]*?-->/g, '');
    const matched = classifyContentSlide(body);
    if (!matched) return null;
    result.push(matched);
  }
  return { slides: result };
}
