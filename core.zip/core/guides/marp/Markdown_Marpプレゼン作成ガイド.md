# Markdown(Marp) プレゼンテーション作成ガイド

> v1.0（2026-06-19）
> 対象: 本プロジェクトのメンバー（**仕組み・記法を詳しく知りたい人向け**の詳細リファレンス）

> 🟢 **まず簡単に作りたい人へ**: ターミナルもVSCodeも使わず、ブラウザだけで
> 「作成→編集→PDF」ができる **[Marp Studio の使い方](Marp-Studioの使い方.md)** から始めてください。
> 本ガイドは、その裏側の仕組み・記法・テーマ詳細を知りたい人向けです。
>
> 🛠 **ふだんの編集の流れ**（Marp Studio と AIアシスタント〔Claude Code・Cline など〕の使い分け）は、かんたん版の「道具の使い分けと、ふだんの編集の流れ」にまとめています。

---

## はじめに（なぜMarpか・用語）

本プロジェクトでは、プレゼンを **PowerPoint ではなくテキスト（Markdown）ベース**で作ります。理由は3つ:

1. **gitで差分管理できる**（誰がどこを直したか追える・履歴が残る）
2. **共通テーマで体裁が自動で揃う**（配色・ロゴ・レイアウトが全員同じ）
3. **生成AIフレンドリー**（本文も図(Mermaid/SVG)も"テキスト"＝AIが読める・直せる・要約できる）

道具立ては **Marp（MD→スライド化）＋ 共通テーマ `base`（体裁）＋ プレビュー手段（Marp Studio または VSCode）**。

用語: **デッキ** … 1つのプレゼン資料（スライド一式）のこと。

## 0. このガイドで分かること（なぜ必要か付き）

1. **Markdown と Marp の違い** … 普通の文章とスライドの何が違うかを掴む
2. **共通テーマ `base` の指定** … 体裁を全員で揃え、配色・ロゴを自動適用するため
3. **VSCode のセットアップ** … Studioを使わず手元で編集・プレビューしたい人向け（任意）
4. **プレビューの仕方** … 書いた内容がスライドでどう見えるか即確認するため
5. **画像 と Mermaid の表示・出力** … 図を確実にPDFへ出すため（一番ハマる所）
6. **よくあるハマりどころ**
7. **新しいデッキの作り方** … 置き場所・画像参照・雛形ツール

> 📑 **実物サンプル**: [`サンプル/`](サンプル/) の `sample.md`（出力 `out/sample.pdf`）。Marp Studio でテーマを acme/globex/initech に切り替えると同じ内容の見た目が変わります。
> 各レイアウトと Mermaid/SVG の実際の見え方は、まずこれを開くのが早いです。

---

## 1. Markdown と Marp の違い

| | Markdown | Marp |
|---|---|---|
| 位置づけ | 文章を書くための軽量記法 | Markdown を**スライド化**する仕組み（Marp = Markdown Presentation） |
| 出力 | HTML文書 / 1枚の長い文書 | スライド（PPT的な複数ページ） |
| ページ区切り | なし | `---`（水平線）で**1スライド区切り** |
| スタイル | エディタ/ビューア依存 | `theme` やCSSで**スライド全体の体裁を統制** |
| 有効化 | 何もしなくてよい | 先頭の frontmatter に `marp: true` が必要 |

### 最小の例

```markdown
---
marp: true
theme: base
paginate: true
---

# 1枚目のタイトル

- 箇条書き

---

# 2枚目のタイトル

本文
```

ポイント:
- 先頭 `---` 〜 `---` の **frontmatter** で Marp の動作とテーマを指定する
- スライドの区切りは本文中の `---`（前後に空行を入れる）
- `marp: true` が無いと、ただのMarkdownとして扱われる（＝スライドにならない）

---

## 2. スタイルの指定（プロジェクト共通テーマ `base`）

本プロジェクトでは、スライドのCSSを各MDに**埋め込まず**、共通テーマ 1ファイルを**外部参照**します。
テーマ・画像などの共通資材は `core/assets/` 配下に集約しています（`marp/` と `images/` が並ぶ）。

- 共通テーマ本体: [`core/assets/marp/base.css`](../../assets/marp/base.css)
  （先頭に `/* @theme base */`。`theme: base` で参照。顧客テーマは base を継承）
- テーマ詳細・補助クラス: [`core/assets/marp/README.md`](../../assets/marp/README.md)
- 共通画像素材: [`core/assets/images/`](../../assets/images/)（ロゴ・写真・背景。一覧は同フォルダの README）

> **顧客ロゴは共通テーマが自動表示します**（顧客プロファイル `profiles/<顧客>/` のロゴ）。 表紙(`<!-- _class: title -->`)は中央上部、本文は右上に出ます。
> 各MDに `![](logo...)` を書く必要はありません。ロゴを消したい1枚には `<!-- _class: no-logo -->`。

### MD側の書き方

frontmatter に `theme: base` と書くだけです。

```yaml
---
marp: true
theme: base
paginate: true
---
```

> 旧来の `style: @import "style.css?v=5";`（CSSをMDから直接importしてキャッシュ番号で更新する方式）は**不要**です。テーマ登録方式にしたため、CSSを直せば全スライドに反映されます。

### テーマの切り替え・追加

- テーマは各デッキ先頭の frontmatter `theme: <名前>` で指定します（Studioで新規作成すると、設定の既定テーマ＝未設定なら `base` が自動で入ります）。
- **標準テーマは `base`（中立ベース：共通レイアウト＋IBMロゴ）**。顧客テーマ（同梱サンプルの `acme` / `globex` / `initech` など）は base を `@import` して**顧客ロゴ・アクセント色だけを上書き**します。`theme:` に未登録の名前を書くとエラー（`theme "..." is not recognized`）になります。
- **顧客テーマ（プロファイル）を増やすには**: `core/assets/marp/profiles/<顧客名>/` に `brand.json`・`logo.*`・`overrides.css`（任意）を置き、`node core/assets/marp/build-themes.mjs` を実行すると `<顧客名>.css`（`@theme <顧客名>`）が生成されます。
- 純粋な別レイアウトを足したい場合は `core/assets/marp/` に `/* @theme 別名 */` で始まる CSS を直接追加してもOK（`base.css` をベースにすると楽）。
- VSCodeで使うテーマは `markdown.marp.themes` に追加します（`base.css` と使う顧客テーマCSS）。Marp Studio は出力時に `marp/` 配下の全CSSを自動登録するため設定不要です。

### 別リポジトリに分かれても、テーマ資産はコピーしない

デッキ一式を別のGitリポジトリ（共有ドキュメントリポ等）へ移す場合でも、`base.css`等の共通テーマ資材はそのリポジトリへコピーしないでください。

- **コピーすると起きること**: コピーした側のCSSと元のCSSが少しずつ食い違っていき、デッキごとに見た目がズレていきます（各リポジトリで個別に直し始めるとさらに進行し、気づきにくい形で広がります）。
- **代わりにやること**: 移動先のリポジトリを、Marp Studioの設定（`.marp-studio.json` の `roots`）に**参照として追加**してください。テーマの実体は1箇所（`core/assets/marp/`）のままで、複数の場所にあるデッキを同じテーマで描画できます。
- 移動先のリポジトリを他の人が単独でclone・単独で開く可能性がある場合は、「テーマ解決にはこのワークスペース経由で開く必要がある」旨を移動先リポジトリのREADME等に明記しておくと安全です。

### レイアウトマスター一覧（`_class` で切替）

PowerPoint のレイアウトマスター相当。スライド先頭に `<!-- _class: 名前 -->` を書きます。

| `_class` | 用途 | 見た目 |
|---|---|---|
| `cover` | 表紙 | IBM公式Covers slide6ベースの幾何学背景＋左下タイトル（`![bg](assets/cover.png)` 併用） |
| `title` | 簡易表紙・章末扉 | 明るい背景・中央寄せ・ロゴ中央上部・ページ番号なし |
| `section` | セクション中扉 | 薄青背景・IBM Blue 左アクセント＋濃紺見出し |
| （無指定） | タイトルとコンテンツ | 標準。右上に IBM主体＋顧客ロゴ・左下ページ番号 |
| `no-logo` | ロゴを消す | その1枚だけ右上ロゴ非表示 |
| `no-page` | 番号を消す | その1枚だけページ番号非表示 |

> 実際の見え方は [`サンプル/`](サンプル/) の `out/sample.pdf`（Studioでテーマ切替）で確認できます。

> 配色は Carbon 系のニュートラルなパレットを基調にしています。
> 著作権フッターは frontmatter に `footer: '© 2026 自社名'` を書くと右下に出ます。

### 補助クラス（任意・HTML有効時のみ）

`html: "all"`（旧 `enableHtml: true`／後述・CLIは `--html`）が有効なとき、`<div class="...">` でレイアウト補助が使えます。
`.lead-area` / `.content-wrapper` / `.content-box` / `.columns`（フル幅2カラム） / 付箋 `.fusen`(色・サイズ・半透明違いあり) / 図形 `.shape`(丸・四角・矢印等・強調注釈用) / 強調 `.good` `.bad` など。詳細は [`core/assets/marp/README.md`](../../assets/marp/README.md) を参照。

> 注: 共通テーマは**プレーンMarkdownでも崩れない**よう調整済み。divを使わず普通に書いてOKです。

---

## 3. VSCode のセットアップと設定（配布方法）

### 3-1. 拡張機能のインストール

VSCode拡張 **「Marp for VS Code」**（marp-team.marp-vscode）をインストール。

### 3-2. ワークスペースを開く（配布の肝）

> `.code-workspace` とは: VSCode の**共有設定ファイル**で、**リポジトリに同梱**されています（`Projects/<ワークスペース>.code-workspace`）。
> clone / pull すれば手元に揃うので、別途インストールや配布作業は不要です（"配布"＝リポジトリ同梱、という意味）。
> これを開くと、共通テーマの登録が**自動で**効きます。

テーマ `base` は **`<ワークスペース>.code-workspace` 経由で開いたときに自動で有効**になります。

- ファイル: `<ワークスペース>.code-workspace`
- VSCodeで「ファイル → ファイルでワークスペースを開く」からこの `.code-workspace` を選択

この `.code-workspace` に、共通テーマ登録が含まれています:

```jsonc
"settings": {
  "markdown.marp.themes": [
    "Projects/<リポジトリ>/core/assets/marp/base.css"
  ],
  "markdown.marp.html": "all"
}
```

→ **新メンバーは「Marp拡張を入れる」「<ワークスペース>.code-workspace で開く」だけ**で共通スタイルが効きます。個別のCSSコピーや設定は不要です。

### 3-3. 設定変更・CSS変更を反映するには

`markdown.marp.themes` の追加やCSS編集の直後は、拡張がテーマを読み直すまで反映されません。

> コマンドパレット (`Cmd+Shift+P` / Win: `Ctrl+Shift+P`) → **「Developer: Reload Window」** を実行

`theme "base" is not recognized` という警告が出る場合も、たいていこのリロードで解消します。

### 3-4. （補足）`.code-workspace` を使わずフォルダを直接開く場合

ルートとして開いたフォルダ直下の `.vscode/settings.json` に同じ設定を置けば有効になります（テーマパスは**そのフォルダからの相対パス**にする）。配布の標準は `.code-workspace` 方式なので、基本はそちらを使ってください。

---

## 4. プレビューの仕方

1. 対象の `.md` を開く（frontmatter に `marp: true` があること）
2. エディタ右上の **プレビューアイコン**（横並びプレビュー）をクリック、または `Cmd+K V`（Win: `Ctrl+K V`）
3. Marpスライドとしてレンダリングされる（`theme: base` で共通体裁）
4. スライド送りはプレビュー内のスクロール。`---` ごとに改ページ

---

## 5. 画像(PNG) と Mermaid の表示・出力

ここが一番ハマりやすいポイントです。**「プレビューで見える」=「PDF/PNGで出る」ではない**ことに注意。

### 5-1. 画像(PNG) の埋め込み

- 記法: `![alt](相対パス/figure.png)` または `<img>`（HTML有効時）
- VSCodeプレビューでは相対パスの画像はそのまま表示される
- **PDF/PNG/PPTX に書き出すときはローカル画像の読み込み許可が必要** → `--allow-local-files`（CLI）/ 拡張のエクスポート設定で許可
- 画像は共通テーマで `max-width/height:100%` に収まるよう調整済み

#### 共通画像素材（ロゴ・写真・背景）の参照

再利用する画像は `core/assets/images/`（`logos/` `photos/` `backgrounds/`）にまとまっています。
各MDからは**Markdown相対パス**で参照します（`![]()` はMDファイル基準で解決される）。

```markdown
![写真の例](../../assets/images/photos/<写真ファイル>.png)
```

> `../` の数はMDの置き場所から `core/` までの距離で決まります。画像一覧は
> [`core/assets/images/README.md`](../../assets/images/README.md) を参照。

> **ロゴは例外**: 顧客ロゴは共通テーマが **data URI 埋め込み**で自動表示するため、MD側の記述は不要です。
> （marp はテーマCSS内の相対 `url()` を「MD基準」で解決しMDの場所によりズレるため、テーマ側は
> 相対パスではなく data URI を採用しています。差し替えは `core/assets/marp/build-themes.mjs`。）

### 5-2. Mermaid（テキストから図を描く）

**Marp 標準では Mermaid コードブロックは描画されません**が、本プロジェクトは**出力ツールがビルド時に Mermaid を画像化して埋め込む**ため、**md に Mermaid のコードブロック（3連バッククォート＋mermaid で開始）を直接書くだけ**でOKです（手動変換も SVG 参照も不要）。

**推奨: md に直接書く（Studio の「Mermaid図」ボタンが雛形を挿入）**
- 本文に Mermaid のコードブロックで図を記述する。
- `export`／プレビュー時に出力ツールが各フェンスを SVG 化し、デッキ内の `assets/.fences/fence-N.svg`（自動生成・gitignore）へ書き出して、その**ファイルを参照する `![](…)` に差し替えた一時mdを Marp に渡す**（元のmdは変更しない）。HTMLプレビューはこのSVGファイルを参照し、PDF出力では画像として埋め込まれます（`width="100%"` の高さ潰れも自動補正）。
- **md に図のソースが残る**＝後から直せば次の出力に反映され、**生成AIも図の構造（mermaid記法）を直接読める**。
- サイズ調整は開始行に続けて指定可（例: 高さ440なら `h:440`）→ 生成画像にそのオプションが付く。

**別法（位置・サイズを細かく詰めたい図向け）**: 図のソースを `assets/<名前>.mmd` に置き、本文で `![](assets/<名前>.svg)` 参照（従来方式・**併用可**。`export` 時に `.mmd`→`.svg` を自動再生成）。doc-map など自動生成図はこの方式のまま。

> 仕組み: 出力ツール（`tools/marp-deck.mjs` / Studio）が内部で `mmdc`（mermaid-cli）を呼びます。
> 初回のみ自動取得で時間がかかり、変換できないときはコードブロック／既存 `.svg` のまま続行します。

> 図が主体で**スライド化が不要**な文書は、`marp: false` のまま通常のMarkdown(Mermaid拡張)プレビューで見るのも可。

### 5-2b. draw.io（Mermaidで描けない絵を自由に描く）

Mermaidはフローチャートやシーケンス図のような**構造化された図**が対象で、自由な配置のイラスト・概念図は表現できません。そういう絵を描きたいときは **draw.io** を使います。

- draw.io は無料で使えるベクター描画ツールで、描いた図をそのまま **SVG（テキストベースのベクター形式）として書き出せます**。この「SVGへの書き出しが手軽」という点が、Mermaidで描けない絵の受け皿に draw.io を勧める理由です（テキストベース＝gitで差分管理でき、拡大しても劣化しません）。
- 書き出し方: draw.io（[app.diagrams.net](https://app.diagrams.net) またはデスクトップ版）で「ファイル」→「エクスポート」→「SVG」を選ぶだけ。
- 保存場所: 図のソース（`.drawio`）と書き出した画像（`.svg`）を**両方、そのデッキの `assets/` に置きます**（5-2の `.mmd`＋`.svg` と同じ考え方）。ソースだけ／SVGだけの片方保管はしない（片方だけだと、後から図を直せなくなるか、mdから参照できなくなるため）。

  ```
  assets/
    zu.drawio   ← draw.io で開いて編集するソース
    zu.svg      ← 書き出したSVG。mdからはこちらを参照
  ```

- 参照方法は通常の画像と同じです: `![](assets/zu.svg)`
- 共通画像（5-1）のような「共通置き場に上げるかどうか」の判断は不要です。デッキに紐づく図なので、常にそのデッキの `assets/` に置けば十分です。

> 補足: PPTX出力ではSVGを直接埋め込みますが、SVG非対応の古いPowerPointでは代替の画像に切り替わり、正しく表示されないことがあります。見た目が気になる場合は draw.io から**PNGでも書き出しておき**、PPTX用にはPNGを使う手もあります。

### 5-3. HTML / PDF / PPTX への出力

#### VSCode から
- コマンドパレット → **「Marp: Export Slide Deck...」** → 形式(PDF/PPTX/HTML/PNG)を選択
- ローカル画像を含む場合は、設定 `markdown.marp.exportType` やローカルファイル許可を確認

#### Marp CLI から（自動化向け）
```bash
# プロジェクトルート (chidai_work_local) から実行する例
marp "Projects/<リポジトリ>/<プロジェクト>/decks/<デッキ名>/<デッキ名>.md" \
  --theme-set "Projects/<リポジトリ>/core/assets/marp/base.css" \
  --html --allow-local-files \
  --pdf -o out/management-plan.pdf
```
- `--theme-set` で共通CSSを渡す（CLIは `.code-workspace` 設定を読まないため明示が必要）
- `--allow-local-files` でローカル画像を許可
- HTML出力 `--html` は、ブラウザ表示やMermaidプラグインHTML出力時に使用

---

## 6. よくあるハマりどころ

- **スライドにならない** → frontmatter 先頭に `marp: true` があるか確認
- **テーマが効かない / 警告** → Marp拡張未導入、`.code-workspace` で開いていない、リロード未実施
- **`---` が改ページにならない** → 前後に空行があるか確認。frontmatterの `---` と混同しない
- **画像がPDFで消える** → `--allow-local-files`／エクスポート時のローカルファイル許可
- **Mermaidが出ない** → 5-2参照（標準Marpは非対応。画像化が確実）
- **1枚に詰め込みすぎて見切れる** → 共通テーマはスライド固定サイズ(1280×720)・はみ出しは隠れる。内容を分割する

---

## 7. 新しいデッキの作り方（フォルダ配置・画像参照・雛形ツール）

### 7-1. 考え方：デッキは「自己完結フォルダ」にする

スライドのMDは git 管理のため、**置き場所はあとから自由に動かせます**。重要なのは
「**どこに置いても壊れない**」状態にすること。次の3点でほぼ場所非依存になります。

| 参照 | パス依存 | 理由 |
|---|---|---|
| テーマ `theme: base` | なし | VSCodeはワークスペース登録、CLIはツールが自動付与（後述） |
| ロゴ（IBM/顧客） | なし | テーマに data URI 埋め込み済み |
| デッキ固有の図（mermaid/SVG/PNG） | なし | **デッキ内 `assets/`** に置き `![](assets/xxx)` で参照 |

> つまり **1デッキ = 1フォルダ**（`デッキ.md` ＋ `assets/` ＋ `out/`）にまとめ、図は
> 必ず `assets/` に入れる。これでフォルダを移動してもリンクは無傷です。

### 7-2. 画像参照のルール

- **デッキ固有の画像**: `assets/` に置く → `![](assets/zu.svg)`（場所に依存しない・推奨）
- **共通画像**（`core/assets/images/` のロゴ以外の写真・背景）を使うときだけ、MDからの
  相対パスになります。`../` の数は **MDの置き場所から `core/` までの距離**で変わるので、
  自信がなければ**そのデッキの `assets/` にコピー**して使うのが安全です（雛形ツールはカバー画像を
  自動コピーします）。

### 7-3. ツール（雛形生成・出力）

> **ブラウザだけで作りたい場合は、この先（コマンド操作）は読み飛ばしてOK** → [Marp Studio の使い方](Marp-Studioの使い方.md)。
> 以下は、コマンド（CLI）で動かしたい・仕組みを把握したい場合の説明です。
> 以下はCLIで動かしたい人向け。Studioも内部で同じエンジン（`marp-deck.mjs`）を使っています。

Marp は Node 製でメンバー全員が導入済みのため、ツールも **Node**（Mac/Windows共通・追加導入不要）。

```bash
# 新規デッキを作る（自己完結フォルダ＋カバー画像コピー＋正しい設定入りの雛形）
node core/tools/marp/marp-deck.mjs new <作成先フォルダ> "タイトル" ["サブタイトル"]

# PDFに出力する（テーマパスは自動解決。--theme-set を手打ちしなくてよい）
node core/tools/marp/marp-deck.mjs export <デッキ.md>
```

- `new` … `デッキ.md`（frontmatter・カバー・章構成入り）、`assets/`（cover.png をコピー）、`out/` を生成
- `export` … (1) `assets/*.mmd` を SVG 自動生成（5-2）→ (2) 親をたどって共通テーマを自動発見し
  `--html --allow-local-files --pdf` で `out/` に出力。**手動の mmdc / --theme-set は不要**。

### 7-4. 作成物の置き場所

**作成物は `out/` に出る PDF**（画像は埋め込まれ自己完結・配布可）。これを各フェーズ／作成物の
フォルダ（`<プロジェクト>/XX_…/`）に置けばOK。MDソースはデッキフォルダに残し、PDFだけを
作成物として扱う運用でも、ソースをPDFの隣に併置する運用でも、**git管理なので後から自由**です。

---

## 参考

- 共通テーマ: [`core/assets/marp/base.css`](../../assets/marp/base.css) / [`core/assets/marp/README.md`](../../assets/marp/README.md)
- ベースにした参考資料: 過去案件の Marp 資材（フロー定義・スタイル）
- Marp公式: https://marp.app/ / Marp for VS Code: https://marketplace.visualstudio.com/items?itemName=marp-team.marp-vscode
